# -*- coding: utf-8 -*-
"""提交 3 套现代涂装 + 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """feat(canvas): 形象包 v4 —— 新增 3 套现代风格涂装（同一拾岚的替换外观）

「涂装」＝同一角色的替换外观（skin），不是新角色。
因此锁死 4 项不变（比例 / 面部 / 狐耳狐尾 / 背景语汇），只换服装与动作细节。

新增 3 条：
· mascot-005 现代涂装①知性通勤 —— 深蓝羊毛风衣 + 青绿(#2dd4bf)真丝围巾 + 抱笔记本
  适用：关于页 / 资料卡
· mascot-006 现代涂装②居家舒适 —— 针织开衫 + 浅灰围巾 + 绒袜 + 捧热茶
  适用：帮助页 / 空状态 / 夜间插图（氛围最暖，暖橙灯为主光）
· mascot-007 现代涂装③机能创客 —— 立领机能夹克 + 耳机 + 指节轻点悬浮节点卡
  适用：启动页 / 技术场景

比例沿用已锁定的成年参数（7.5头身 / 眼裂1/3 / 卵形脸 / 修长颈肩），
防止出现新图漂回幼态。

三套均已肉眼核验。已知偏差（已在提示词中加约束，供下轮复验）：
· ③ 裤腿仍出现侧口袋（提示词已明确「无侧袋的简约直筒款」）—— 轻微回潮到"行动派"
· ③ 环境比预期"乱"（工业感偏重），离"温柔"最远，作为技术场景图可用

产出图：assets/mascot/shilan-涂装0{1,2,3}-*.png
双库同步：4 处 JSON 一致（7 条）；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psC.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "assets/mascot/shilan-涂装01-知性通勤.png\n"
    "assets/mascot/shilan-涂装02-居家舒适.png\n"
    "assets/mascot/shilan-涂装03-机能创客.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgC.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("② 提交副库")
print("=" * 74)
gt("add", "-A", "--", "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M5.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "feat(libtv): 同步形象包 v4（新增 3 套现代风格涂装）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v4：3 套现代风格涂装（01:36 - 01:50）

用户：「再给我几张现代风格的涂装的设计」
→ 我把「涂装」理解为**同一角色的替换外观（skin）**，不是新角色。

### 关键方法：锁 4 项、只换 1 项
**锁死不变**（保证是"同一个拾岚"）：比例段（7.5头身/眼裂1/3/卵形脸/修长颈肩）、
面部、狐耳狐尾参数、背景语汇（拱形窗/浅月/城市剪影/时间线光带/暖橙灯/边缘光）。
**只换**：服装 + 动作细节 + 场景侧重。

⇒ 这套「锁参数段复用」是保证多图一致性的关键手法：
把 RATIO / CHAR / BG 抽成常量在 4 条 prompt 里复用，比每条重写更不容易漂。

### 三套产出（均已肉眼核验）
| id | 涂装 | 适用场景 | 核验 |
|---|---|---|---|
| mascot-005 | 知性通勤（深蓝羊毛风衣 + **青绿 `#2dd4bf` 真丝围巾** + 抱笔记本） | 关于页/资料卡 | ✅ 7头身、风衣挺括、狐尾垂落不翘 |
| mascot-006 | 居家舒适（针织开衫 + 浅灰围巾 + 绒袜 + 捧热茶） | 帮助页/空状态/夜间插图 | ✅ 暖橙灯成主光，**氛围最暖** |
| mascot-007 | 机能创客（立领夹克 + 耳机 + 指节轻点悬浮节点卡） | 启动页/技术场景 | ✅ 悬浮卡上有节点连线图，极贴画布；⚠️ 两处偏差见下 |

### 已知偏差（已写进提示词约束，供下轮复验）
1. **③ 裤腿仍出现侧口袋** —— 我明确写了「剪裁干净、无过多口袋」，模型仍加了 cargo pocket
   ⇒ 轻微回潮到"行动派"。提示词已改为更硬的措辞「裤子为无侧袋的简约直筒款」
2. **③ 环境偏"乱"**（工业感、地面反光、线缆）—— 与我写的"科技感但不冷硬"有偏差，
   偏"黑客工作室"。它是三套里**离"温柔"最远**的，作为技术场景图可用
3. ② 的坐姿使头身比不易直读，但整体不幼态 ✓

### 沉淀：多图一致性的实操手法
**把「比例 / 角色特征 / 背景语汇」抽成可复用常量段，跨条 prompt 逐字复用。**
本次 7 条 prompt 共用同一段 RATIO（含"禁止Q版、禁止短身、禁止大头"等负向约束），
这是 v3 之后新图没有漂回幼态的主要原因。
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v4" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
