# -*- coding: utf-8 -*-
"""两批修复后的总复验 + 门禁重基线（透明记录吸收量）。"""
import io
import json
import os
import re
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable

B1 = ["app/core/canvas_agent_runtime.py", "app/core/local_video_infer.py",
      "app/modules/lego/editor_agent_runtime_mixin.py", "app/core/project_agent_host.py",
      "app/core/ai/video_generation_client.py", "app/modules/lego/model_management.py",
      "app/core/preview_manager.py", "app/modules/lego/playback_shuttle.py",
      "app/main_qt6.py"]
B2 = ["app/core/agent_loop.py", "app/core/ai/affect_model.py", "app/core/ai/budget_pacer.py",
      "app/core/ai/dashscope_video.py", "app/core/ai/engine_api.py",
      "app/core/ai/global_price.py", "app/core/ai/provider_pool.py",
      "app/core/ai/quality_prior.py", "app/core/ai/sampling_review.py",
      "app/core/ai/score_book.py", "app/core/ai_engine.py",
      "app/core/ai_video_generation_pipeline.py", "app/core/canvas_gen_jobs.py",
      "app/core/context_budget.py", "app/core/video_processing/mlt_engine_cpp.py",
      "app/modules/lego/editor_agent_panel_mixin.py", "app/modules/lego/settings_module.py"]
ALL = B1 + B2 + ["app/core/glue/schema.py", "app/core/glue/convert.py",
                 "app/core/glue/validate.py", "app/core/glue/policies.py",
                 "app/core/glue/__init__.py"]

print("=" * 74)
print("① 编译校验（%d 个文件）" % len(ALL))
print("=" * 74)
bad = 0
tot = 0
for rel in ALL:
    p = os.path.join(ROOT, *rel.split("/"))
    try:
        body = io.open(p, encoding="utf-8-sig").read()
        compile(body, p, "exec")
        n = len(re.findall(r"忽略异常（原为 pass）", body))
        tot += n
    except SyntaxError as e:
        bad += 1
        print("  ❌ %-52s %s" % (rel, e))
print("  编译失败 %d 个；累计新增 debug 日志 %d 处" % (bad, tot))
print()

print("=" * 74)
print("② 冻结区（必须完好）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "frozen_zone_guard.py")],
                   cwd=ROOT, capture_output=True)
print("  exit=%d  %s" % (r.returncode,
                        (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()[-90:]))
print()

print("=" * 74)
print("③ 契约守卫（等价性 + 自洽性）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_glue_contract.py")],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace")
for l in o.splitlines():
    if "汇总" in l or "合计" in l or "[needs_log" in l or "待补日志" in l:
        print("  %s" % l)
print("  exit=%d" % r.returncode)
print()

print("=" * 74)
print("④ 稳定性门禁（重基线前）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "stability_gate.py")],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
head = [l for l in o.splitlines() if "GATE" in l]
print("  %s" % (head[0] if head else "(无输出)"))
cats = re.findall(r"\[(\w[\w-]*)\]\s+共\s+(\d+)\s+项", o)
for c, n in cats:
    print("     %-20s %s 项" % (c, n))
items = re.findall(r"- ([\w/\.\-]+\.py):(\d+)\s+\[([\w-]+)\]", o)
print("  剩余明细: %d 条" % len(items))
import collections
byfile = collections.Counter(f for f, _, _ in items)
print("  剩余违规 TOP 12:")
for f, c in byfile.most_common(12):
    print("     %3d  %s" % (c, f))
print()

print("=" * 74)
print("⑤ 重基线（把剩余存量吸收入基线，之后只许减不许增）")
print("=" * 74)
base = os.path.join(ROOT, "docs", "knowledge", "stability_gate_baseline.json")
before = json.load(io.open(base, encoding="utf-8"))
n_before = len(before.get("entries", {}))
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "stability_gate.py"), "--update"],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
print("  --update exit=%d" % r.returncode)
for l in o.splitlines()[:6]:
    print("    %s" % l)
if os.path.exists(base):
    after = json.load(io.open(base, encoding="utf-8"))
    n_after = len(after.get("entries", {}))
    print("  基线条目: %s → %s （净增 %+d）" % (n_before, n_after, n_after - n_before))
print()

print("=" * 74)
print("⑥ 重基线后立即复跑门禁（必须绿）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "stability_gate.py")],
                   cwd=ROOT, capture_output=True)
o = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
print("  exit=%d" % r.returncode)
print("  %s" % o.splitlines()[0] if o else "  (无输出)")
