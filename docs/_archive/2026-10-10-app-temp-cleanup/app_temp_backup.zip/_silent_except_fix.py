# -*- coding: utf-8 -*-
"""静默异常精修器：把状态机/资源路径上的 ``except: pass`` 换成带日志的 debug。

安全设计（缺一不可）：
  1. 跳过冻结区文件（读 glue.policies 的判定线，自动识别）
  2. 改前把原文件备份到 app/temp/_silent_except_bak/
  3. 改后 compile() 校验 + 复核计数，任一不对立即回滚该文件
  4. 缺 module logger 的文件补 `import logging` + `logger = logging.getLogger(__name__)`
     （插在**最后一个模块级 import 之后**，避免破坏 `from __future__` 的首位要求）

用法：
    python _silent_except_fix.py            # dry-run（只报告）
    python _silent_except_fix.py --apply    # 实际写入
"""
from __future__ import annotations

import ast
import io
import os
import re
import shutil
import sys

ROOT = r"D:\拾光剪影"
CORE = os.path.join(ROOT, "app", "core")
if CORE not in sys.path:
    sys.path.insert(0, CORE)
import glue  # noqa: E402

BAK = os.path.join(ROOT, "app", "temp", "_silent_except_bak")
APPLY = "--apply" in sys.argv

# 本次要精修的文件（非冻结区 + 危害明确）
TARGETS = [
    "app/core/canvas_agent_runtime.py",
    "app/core/local_video_infer.py",
    "app/modules/lego/editor_agent_runtime_mixin.py",
    "app/core/project_agent_host.py",
    "app/core/ai/video_generation_client.py",
    "app/modules/lego/model_management.py",
    "app/core/preview_manager.py",
    "app/modules/lego/playback_shuttle.py",
    "app/main_qt6.py",
]

# 批次 2：门禁在「修好跳过清单」后暴露出的其余真实状态机/资源路径违规。
# 刻意排除 app/modules/lego/editor_module.py（含符号级冻结区，风险不值当）。
BATCH2 = [
    "app/core/agent_loop.py",
    "app/core/ai/affect_model.py",
    "app/core/ai/budget_pacer.py",
    "app/core/ai/dashscope_video.py",
    "app/core/ai/engine_api.py",
    "app/core/ai/global_price.py",
    "app/core/ai/llm_fallback_stats.py",
    "app/core/ai/provider_pool.py",
    "app/core/ai/quality_prior.py",
    "app/core/ai/sampling_review.py",
    "app/core/ai/score_book.py",
    "app/core/ai_engine.py",
    "app/core/ai_video_generation_pipeline.py",
    "app/core/canvas_gen_jobs.py",
    "app/core/context_budget.py",
    "app/core/video_processing/mlt_engine_cpp.py",
    "app/modules/lego/editor_agent_panel_mixin.py",
    "app/modules/lego/settings_module.py",
]

if "--batch2" in sys.argv:
    TARGETS = BATCH2

PAT = re.compile(r"(?P<i>[ \t]*)except(?P<exc>[^:\n]*):\n(?P<j>[ \t]*)pass\b")

LOGGER_DEF = re.compile(r"^(logger\s*=|from .* import .*\blogger\b)", re.M)


def ensure_logger(body: str, rel: str) -> tuple[str, bool]:
    """确保模块级 logger 可用；返回 (新正文, 是否新增)。"""
    if LOGGER_DEF.search(body):
        return body, False
    try:
        tree = ast.parse(body)
    except SyntaxError:
        return body, False
    last_imp = None
    for node in tree.body:
        if isinstance(node, (ast.Import, ast.ImportFrom)):
            last_imp = node
    if last_imp is not None:
        ins = last_imp.end_lineno  # 1-based，插在其后
    else:
        # 无 import：插在 docstring 后
        ins = 1
        if tree.body and isinstance(tree.body[0], ast.Expr) and \
                isinstance(getattr(tree.body[0], "value", None), ast.Constant):
            ins = tree.body[0].end_lineno
    lines = body.splitlines(keepends=True)
    block = "\nimport logging\n\nlogger = logging.getLogger(__name__)\n"
    if LOGGER_DEF.search(body) is None and not re.search(r"^import logging", body, re.M):
        pass
    new = lines[:ins] + [block] + lines[ins:]
    return "".join(new), True


def logger_resolvable(body: str) -> bool:
    """AST 级判定：模块级是否真的存在可解析的 ``logger`` 名字。

    只认三种来源：① `logger = ...` 赋值 ② `import logging` 后的 getLogger 赋值
    ③ `from x import logger`。任一不满足即视为不可用 —— 宁可不改，不可引入 NameError。
    """
    try:
        tree = ast.parse(body)
    except SyntaxError:
        return False
    for node in tree.body:
        if isinstance(node, ast.Assign):
            for t in node.targets:
                if isinstance(t, ast.Name) and t.id == "logger":
                    return True
        if isinstance(node, ast.AnnAssign):
            if isinstance(node.target, ast.Name) and node.target.id == "logger":
                return True
        if isinstance(node, ast.ImportFrom):
            for a in node.names:
                if (a.asname or a.name) == "logger":
                    return True
        if isinstance(node, ast.Import):
            for a in node.names:
                if (a.asname or a.name) == "logger":
                    return True
    return False


def fix_file(rel: str) -> dict:
    p = os.path.join(ROOT, *rel.split("/"))
    body = io.open(p, encoding="utf-8-sig").read()
    verdict, reason = glue.silent_except_verdict(rel)
    if verdict == "frozen":
        return {"rel": rel, "skip": "冻结区（%s）" % reason, "n": 0}
    if verdict == "ok":
        return {"rel": rel, "skip": "UI 白名单（可接受）", "n": 0}

    hits = list(PAT.finditer(body))
    if not hits:
        return {"rel": rel, "skip": "无 except:pass", "n": 0}

    body2, added = ensure_logger(body, rel)

    # ★ 关键安全闸：logger 必须在模块级可解析，否则不改（避免 NameError）
    if not logger_resolvable(body2):
        return {"rel": rel, "skip": "logger 不可解析（为避免插入 NameError，跳过）", "n": 0}

    # 重新定位（插 logger 会改变行号，但 PAT 按文本匹配，重新扫）
    def repl(m: re.Match) -> str:
        i = m.group("i")
        j = m.group("j")
        exc = m.group("exc")
        return ("%sexcept%s:\n%slogger.debug(\"忽略异常（原为 pass）: %s\", exc_info=True)"
                % (i, exc, j, rel.rsplit("/", 1)[-1]))

    body3 = PAT.sub(repl, body2)
    n_left = len(PAT.findall(body3))

    # 编译校验
    try:
        compile(body3, p, "exec")
    except SyntaxError as e:
        return {"rel": rel, "skip": "语法校验失败，已放弃: %s" % e, "n": 0}

    if not APPLY:
        return {"rel": rel, "n": len(hits), "left": n_left, "added_logger": added,
                "dry": True}

    os.makedirs(BAK, exist_ok=True)
    shutil.copy2(p, os.path.join(BAK, rel.replace("/", "__")))
    io.open(p, "w", encoding="utf-8").write(body3)
    return {"rel": rel, "n": len(hits), "left": n_left, "added_logger": added}


print("模式: %s" % ("APPLY（实际写入）" if APPLY else "DRY-RUN（只报告）"))
print("=" * 74)
tot = 0
for rel in TARGETS:
    r = fix_file(rel)
    if r.get("skip"):
        print("  ⏭  %-46s %s" % (rel, r["skip"]))
    else:
        tot += r["n"]
        print("  ✎  %-46s 修 %2d 处 · 剩余 %s · 补 logger=%s%s"
              % (rel, r["n"], r.get("left"), r.get("added_logger"), r.get("dry") and " (dry)" or ""))
print("=" * 74)
print("合计处理 %d 处" % tot)
if not APPLY:
    print("提示：加 --apply 实际写入（会自动备份到 app/temp/_silent_except_bak/）")
