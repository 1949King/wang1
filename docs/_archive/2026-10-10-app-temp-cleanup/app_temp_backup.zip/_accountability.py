# -*- coding: utf-8 -*-
"""对账：技术债报告里的每一项，现在的真实状态是什么。"""
import hashlib
import io
import os
import re
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable


def sh(*a, cwd=ROOT):
    r = subprocess.run(list(a), cwd=cwd, capture_output=True)
    return r.returncode, r.stdout.decode("utf-8", "replace").strip()


print("=" * 74)
print("【关键核对】S1 的核心是「装卡点防复漂」—— 双库校验进 pre-commit 了吗？")
print("=" * 74)
pc = io.open(os.path.join(ROOT, ".pre-commit-config.yaml"), encoding="utf-8").read()
hooks = re.findall(r"- id: ([\w\-]+)", pc)
print("  已接入的钩子: %s" % hooks)
print("  含双库校验? %s" % ("✅ 有" if "canvas-dual-repo" in pc or "dual_repo" in pc else "❌ 没有"))
print()

print("=" * 74)
print("S 级")
print("=" * 74)
# S1 双库分叉
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace")
m = re.search(r"一致 (\d+) · 分叉 (\d+) · 副库缺失 (\d+)", o)
print("  S1 双库分叉: %s（报告基线 24 → 目标 ≤10）" % (m.group(0) if m else "?"))
print("     ⇒ 漂移本身已收敛；但**卡点未接入 pre-commit** ⇒ 会再漂")
print()
# S2 editor_module 行数
p = os.path.join(ROOT, "app", "modules", "lego", "editor_module.py")
n = sum(1 for _ in io.open(p, encoding="utf-8-sig", errors="replace"))
print("  S2 editor_module.py: %d 行（报告 9,717 → 目标 ≤6,500）⇒ 未动" % n)
print()
# S3 副库回滚
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
rc, out = sh("git", "ls-files", "src/libtv", cwd=T)
print("  S3 副库 src/libtv 已跟踪: %d 文件 ⇒ %s" % (
    len([l for l in out.splitlines() if l.strip()]),
    "✅ 已解决" if out.strip() else "❌ 未解决"))
print()

print("=" * 74)
print("A 级")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_glue_contract.py"), "--scan"],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace")
for l in o.splitlines():
    if "合计" in l or "待补日志" in l or "[needs_log" in l or "[frozen" in l:
        print("  A1 %s" % l.strip())
print("     ⇒ 从 98 处降到 30 处（含冻结区 9 处必须解冻才能动）")
print()
ENG = {
    "engine_api.py": "get_engine_api",
    "module_scheduler.py": "get_scheduler",
    "simulator.py": "Simulator(",
}
print("  A2 未接线模块:")
for f, sym in ENG.items():
    hits = []
    for dp, dns, fns in os.walk(os.path.join(ROOT, "app")):
        dns[:] = [d for d in dns if d not in ("__pycache__", "temp", "logs")]
        for fn in fns:
            if not fn.endswith(".py"):
                continue
            fp = os.path.join(dp, fn)
            rel = os.path.relpath(fp, ROOT).replace("\\", "/")
            try:
                b = io.open(fp, encoding="utf-8-sig", errors="replace").read()
            except Exception:
                continue
            if sym in b:
                hits.append(rel)
    prod = [h for h in hits if not h.endswith(f) and "/ai/" not in h]
    print("     %-24s 生产引用(非自身) %d ⇒ %s" % (f, len(prod), "未接线" if not prod else prod[:2]))
print()
print("  A3 测试真实通过率: 未测 ⇒ 未动")
b = io.open(os.path.join(ROOT, "docs", "knowledge", "stability_gate_baseline.json"),
            encoding="utf-8").read()
print("  A4 内联 setStyleSheet: 未动（938 处 / 45 文件）")
print()

print("=" * 74)
print("B 级")
print("=" * 74)
print("  B1 同名类 52 组 ⇒ 未动")
print("  B2 重复体系 4 组 ⇒ 未动")
p1 = os.path.join(ROOT, "integrations", "__init__.py")
print("  B3 悬空引用 integrations/olive.py: 目标模块存在=%s ⇒ 未动"
      % os.path.exists(os.path.join(ROOT, "app", "integrations", "olive.py")))
tot = 0
for dp, dns, fns in os.walk(os.path.join(ROOT, ".git")):
    for f in fns:
        try:
            tot += os.path.getsize(os.path.join(dp, f))
        except OSError:
            pass
print("  B4 .git 体积: %.0f MB（报告 2,897）⇒ 未动" % (tot / 1048576.0))
print()

print("=" * 74)
print("验收指标表（报告 §4）逐项对账")
print("=" * 74)
CH = [
    ("双库分叉文件数", "23", m.group(2) if m else "?", "≤10"),
    ("双库校验进 pre-commit", "无", "有" if ("dual_repo" in pc or "canvas-dual-repo" in pc) else "无", "有"),
    ("副库可回滚性", "无", "有", "有"),
    (">2000 行文件数", "12", "12", "≤9"),
    ("editor_module 行数", "9717", str(n), "≤6500"),
    ("状态机静默异常", "~41", "30（含冻结 9）", "0"),
    ("未接线模块", "5", "5", "0"),
    ("pre-commit 守卫数", "0", str(len(hooks)), "3+"),
    ("测试真实通过率", "未知", "未知", "有数字"),
    (".git 体积", "2897MB", "%.0fMB" % (tot / 1048576.0), "≤1000MB"),
    ("生产侧 print", "217", "217（基线含 29 项）", "不强求"),
]
print("  %-22s %-10s %-16s %s" % ("指标", "报告基线", "现在", "30天目标"))
print("  " + "-" * 70)
for a, b_, c, d in CH:
    mark = "✅" if str(c) == str(d) or c not in ("无", "未知", "12", "5", "30（含冻结 9）", "217（基线含 29 项）") else "⬜"
    print("  %-22s %-10s %-16s %s" % (a, b_, c, d))
