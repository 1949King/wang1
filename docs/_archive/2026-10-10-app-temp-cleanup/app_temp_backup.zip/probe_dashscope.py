# -*- coding: utf-8 -*-
"""渠道探测：DashScope 万相连通性（零成本，不生成视频）。"""
import io
import json
import sys
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "app" / "core" / "ai"))

import dashscope_video as dsv

key = dsv.get_api_key()
print("== key 探测 ==")
print("key_present:", bool(key), "key_prefix:", key[:8] + "..." if key else "(无)")
if not key:
    sys.exit(1)

print("\n== 端点探测（非法模型触发 400，不花钱）==")
result = dsv.probe()
print(json.dumps(result, ensure_ascii=False, indent=2))

print("\n== 结论 ==")
if result.get("ok"):
    print("云端渠道：可用 ✅（认证通过 + 端点可达）")
else:
    print("云端渠道：不可用 ❌ 原因:", result.get("reason"))
