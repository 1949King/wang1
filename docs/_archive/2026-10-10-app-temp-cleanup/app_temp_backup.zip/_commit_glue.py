# -*- coding: utf-8 -*-
"""把本轮成果提交到主仓（本地，不 push）。

刻意只提交「代码 + 守卫 + 配置 + 文档」，不碰：
  · assets/avatar/*.png（用户侧生成资产，非本轮改动）
  · 其他会话产出的 docs/_reports/*.md
"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"

PATHS = [
    "app/core/glue",
    "_verify/check_glue_contract.py",
    # 静默异常精修：批次 1
    "app/core/canvas_agent_runtime.py",
    "app/core/local_video_infer.py",
    "app/modules/lego/editor_agent_runtime_mixin.py",
    "app/core/project_agent_host.py",
    "app/core/ai/video_generation_client.py",
    "app/modules/lego/model_management.py",
    "app/core/preview_manager.py",
    "app/modules/lego/playback_shuttle.py",
    "app/main_qt6.py",
    # 静默异常精修：批次 2
    "app/core/agent_loop.py",
    "app/core/ai/affect_model.py",
    "app/core/ai/budget_pacer.py",
    "app/core/ai/dashscope_video.py",
    "app/core/ai/engine_api.py",
    "app/core/ai/global_price.py",
    "app/core/ai/provider_pool.py",
    "app/core/ai/quality_prior.py",
    "app/core/ai/sampling_review.py",
    "app/core/ai/score_book.py",
    "app/core/ai_engine.py",
    "app/core/ai_video_generation_pipeline.py",
    "app/core/canvas_gen_jobs.py",
    "app/core/context_budget.py",
    "app/core/video_processing/mlt_engine_cpp.py",
    "app/modules/lego/editor_agent_panel_mixin.py",
    "app/modules/lego/settings_module.py",
    # 守卫与配置
    ".pre-commit-config.yaml",
    "scripts/stability_gate.py",
    "docs/knowledge/stability_gate_baseline.json",
    "_verify/check_canvas_dual_repo.py",
    "docs/现行技术文档.md",
    "docs/_reports/2026-09-25-项目本质与技术债分析及优化方案.md",
]

MSG = """feat(glue): 粘合层共享数据模型 + 增速守卫 + 双库零分叉收敛

按技术债报告（docs/_reports/2026-09-25）的方案执行，四项成果：

## 1. 粘合层共享数据模型（新，app/core/glue/）
解决「三层之间没有共享数据模型」的根本问题。三条主线（剪辑/生成/画布）
世界观不同，原本靠散落的字段字面量互相看见 —— canvas_node_id 等在三处硬编码，
无 schema 版本、无校验、无溯源，任一改名都静默失效。

新增契约层（纯标准库、零项目依赖）：
  schema.py   跨线字段集合单一来源 · 别名表 · GlueProvenance 溯源 · GLUE_SCHEMA_VERSION
  convert.py  三向转换（clip/outbox/payload/patch/row）
  validate.py 桥边界校验（信封/载荷/快照行）
  policies.py 三条世界观冲突的显式策略

铁律：字段名保持原样（前端与既有工程文件依赖）；只新增不改行为。
由 _verify/check_glue_contract.py 的【等价性断言】保证 ——
契约层输出必须与 editor_canvas_link 既有实现逐字段一致，18/18 通过。

## 2. 三条主线世界观冲突 → 显式策略（不是重构）
  ① 失败观：静默异常判定线变成可执行数据（UI 白名单/待整改/冻结待解冻）
  ② 时间观：TIMELINE_WRITE_ENTRYPOINTS 声明唯一合法写入入口
  ③ 一致性观：默认只收完整交付，降级产物须显式 ack，准入后自动打标

## 3. 增速守卫（堵复利口）
.pre-commit-config.yaml 接入四道本地卡点：冻结区 / 稳定性棘轮 / 粘合层契约 / 架构。
顺带修两个「守卫失效」真问题：
  · stability_gate 的 SKIP_DIRS 漏了 app/temp 等 gitignore 草稿目录，
    导致临时脚本的 print 把门禁顶红（631 项里 564 项来自草稿）⇒ 门禁长期红、无人执行
  · arch_guard 无参时空转（exit=0 但没扫）⇒ 钩子固定为 --scan app

## 4. 静默异常精修 67 处（批次 1+2）
状态机/资源路径上的 except: pass → logger.debug(exc_info=True)。
覆盖 27 个文件，全部 compile 通过、等价性守卫仍全绿、冻结区 85 锁点完好。
needs_log 存量 98 → 30 处；稳定性基线 386 → 279 项（净减 107）。
刻意跳过：UI 绘制白名单（判定线允许）、冻结区文件（须先解冻）。

## 5. 双库零分叉收敛（副库三次本地提交）
  ed3ea53 把 src/libtv（89 文件）纳入副库跟踪，建立回滚能力
  b628661 同步 24 个分叉文件（tsc 54 → 48）
  1ada7ef 精准补齐 12 个缺失源文件（tsc 48 → 38）
结果：双库分叉 24 → 0 · 副库缺失 19 → 7 · 副库 tsc 错误 54 → 38。
即「向主库收敛本身就是修复」。
排除项（经实测，勿盲目补回）：tauri-api-shim.d.ts（会覆盖宿主真实 Tauri 类型）、
*.test.ts ×5（避免与宿主 166 个自有测试冲突）。

## 验证
  冻结区      OK frozen zones intact (85 locks)
  稳定性门禁  OK clean（279 项存量，无新增）
  粘合层契约  18/18 通过
  架构守护    0 违规
  文件规模    通过
  双库校验    无新增漂移（分叉 0 / 缺失 7）

WARNING: 仅本地提交，未 push。副库 origin 为第三方仓库，亦未 push。
"""


def git(*a, **kw):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True, **kw)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


print("=" * 74)
print("① 暂存（精确路径清单，不用 git add .）")
print("=" * 74)
td = tempfile.gettempdir()
ps = os.path.join(td, "_glue_commit_ps.txt")
io.open(ps, "w", encoding="utf-8").write("\n".join(PATHS) + "\n")
git("reset")
rc, out, err = git("add", "-A", "--pathspec-from-file=" + ps)
print("  add exit=%d" % rc)
if err.strip():
    print("  stderr: %s" % err.strip()[:300])

rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
staged = [l for l in out.splitlines() if l.strip()]
print("  暂存 %d 个文件" % len(staged))
import collections
c = collections.Counter(p.split("/")[0] for p in staged)
print("  顶层分布: %s" % dict(c))
print()

print("=" * 74)
print("② 提交")
print("=" * 74)
mf = os.path.join(td, "_glue_commit_msg.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d" % rc)
print("  %s" % (out.splitlines()[0] if out else err[:400]))
print()

print("=" * 74)
print("③ 结果")
print("=" * 74)
for l in git("log", "--oneline", "-4")[1].splitlines():
    print("     %s" % l)
print()
rc, out, _ = git("status", "--porcelain", "-uall")
left = [l for l in out.splitlines() if l.strip()]
print("  工作区剩余 %d 项:" % len(left))
for l in left[:12]:
    print("     %s" % l[:100])
