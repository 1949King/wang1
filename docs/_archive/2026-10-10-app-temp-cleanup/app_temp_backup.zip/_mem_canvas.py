# -*- coding: utf-8 -*-
"""追加记忆。"""
import io
import os

MEM = r"D:\拾光剪影\.workbuddy\memory\2026-09-26.md"
NOTE = """
## 画布引擎与架构现状 + 待改进项（00:18 - 00:45）· 主仓 2ffa8fd

用户问：「画布使用的引擎和架构是怎么样的，还需要改进吗？」

### 关键认知：画布有**三种「引擎」**，极易混为一谈

| 层 | 是什么 | 实测现状 |
|---|---|---|
| ① **宿主引擎** | `engine=shiguang`（WebEngine 内嵌 Qt6，**默认**）／ `engine=tauri`（独立桌面进程） | **只有 shiguang 在服役**；`src-tauri/target/release` **不存在** ⇒ 宿主 B「有源码、未构建」 |
| ② **渲染/交互引擎** | React 19 + `@xyflow/react` 12（图）+ three 0.185（3D）+ zustand 5（状态）+ vite 6 | 版本 **0.3.1**，`canvasVersion.ts` == `package.json` ✅ 三件套一致 |
| ③ **生成引擎** | ComfyUI（本地，§2e 刚修）／云端 provider／Ollama（本机 :11434 在跑） | ComfyUI `engine_valid=true` |

### 架构（数据流）
```
EditorModule._clips（真相源）
 └ canvas_bridge（业务，冻结区）→ canvas_server(:18765 · ~45 端点 + SSE)
      ├ 宿主A WebEngine：canvas_runtime :3011 → vendor/shiguang-canvas/dist
      └ 宿主B Tauri：读 vendor/AI-Canvas-tauri/src/libtv（未构建，暂不可用）
真源 src 106 文件/43,210 行  ·  副库 libtv 99 文件/42,533 行
```

### ⚠️ 必须订正的错误（我自己上轮写错的）

§2c.4 我写过「主库侧由 shiguang-canvas 自己的 eslint 负责」—— **实测不成立**：
真源 `vendor/shiguang-canvas` **没有 eslint 配置**（无 `eslint.config.js`/`.eslintrc*`），
`package.json` 也**没有 lint 脚本**。⇒ **画布真源目前根本没有 lint 门禁**。
已订正 §2c.4 并在 §2f 记录。

### 待改进项（结论：需要改进，但不在"画布画得好不好"，而在四处）

**P0-a 门禁层（最该修）**：`_verify` 下前端校验多数**未挂载** ——
`check_canvas_frontend_quality.mjs` 既不在 pre-commit 也不在 run_all_checks（**纯摆设**）；
`_run_tsc.cjs` / `_run_vitest.cjs` 未挂载。
⇒ **画布改动目前只有「双库一致性」一道卡点**，类型检查与 lint 都没强制。
建议：接进 pre-commit（零新增代码，只接线）。

**P0-b**：`prompt-image` 失败无负缓存（§2d.3 同项）。

**P1 双宿主双份维护**：`libtv` 42,533 行是为 Tauri 宿主而存在的，而该宿主从未构建
⇒ 该副本**没有实际服役价值**，却要跟着真源同步（**这就是双库漂移复漂的根源**）。
建议二选一：① 做完抽包 Phase 1-2 只留一份；② 明确「tauri 暂缓」并冻结 libtv、停止同步。

**P2**：画布 5 个最大文件**全在冻结区**（Stage3D 4,660 · riggedHumanoid 3,707 · styles.css 3,550 ·
CanvasShell 3,199 · store.ts 2,452）⇒ 想拆必须先解冻。

**P3**：dist 11.6MB/32 文件里 **63%（7.3MB）是 prompts JSON + GLB 模型** ⇒
每次前端构建都复制运行时数据，更适合按需从 public/ 或宿主提供。

### 方法学（第 4 次印证）
本轮又出现一次「口径误判」：我一度把「副库 libtv/canvasVersion.ts=0.3.1 vs 副库 package.json=0.8.5」
判为不一致 —— 实际那是**移植画布版本 vs 宿主自身版本**，两者本就该不同（同主程序 4.39.x vs 画布 0.3.x）。
⇒ **报"不一致"之前必须先确认两者是否是同一套版本号体系。**
"""
if os.path.exists(MEM):
    b = io.open(MEM, encoding="utf-8").read()
else:
    b = "# 2026-09-26 工作记录\n"
if "画布引擎与架构现状" in b:
    print("已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("已写入 -> %d bytes" % os.path.getsize(MEM))
