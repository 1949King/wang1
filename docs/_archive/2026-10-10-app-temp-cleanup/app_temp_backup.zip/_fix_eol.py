# -*- coding: utf-8 -*-
"""修「副库永远报分叉」的真因：autocrlf 把 LF 改写成 CRLF。

机制（实测）：
  副库 core.autocrlf=true ⇒ git checkout 时把索引里的 LF 写成工作区 CRLF；
  而 git status 因归一化仍显示「干净」⇒ 双库字节校验永远报分叉、且看不出原因。
  ⇒ 这类「守卫常红但归因不明」正是守卫被忽视的成因。

修法（三步，顺序不能反）：
  1) 副库本仓设 core.autocrlf=false（字节忠实）
  2) 加 .gitattributes：src/libtv/** -text（永不转换，供其它机器/克隆同样生效）
  3) 用索引内容重建工作区（此时才写回 LF）
"""
import hashlib
import io
import os
import subprocess
import sys

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
MAIN = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
SUB = os.path.join(ROOT, "src", "libtv")
PY = sys.executable


def gt(*a):
    name = subprocess.run(["git", "config", "user.name"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "1949King"
    mail = subprocess.run(["git", "config", "user.email"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "x@y.z"
    r = subprocess.run(["git", "-c", "user.name=" + name, "-c", "user.email=" + mail] + list(a),
                       cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


def diff_count():
    """统计主库 vs 副库副本的字节级分叉数。"""
    n = 0
    bad = []
    for dp, dns, fns in os.walk(MAIN):
        dns[:] = [d for d in dns if d not in ("node_modules", "dist", "__pycache__")]
        for f in fns:
            if not f.endswith((".ts", ".tsx", ".css", ".json")):
                continue
            ap = os.path.join(dp, f)
            rel = os.path.relpath(ap, MAIN).replace("\\", "/")
            bp = os.path.join(T, "src", "libtv", *rel.split("/"))
            if not os.path.exists(bp):
                continue
            if io.open(ap, "rb").read() != io.open(bp, "rb").read():
                n += 1
                bad.append(rel)
    return n, bad


print("=" * 74)
print("① 修复前")
print("=" * 74)
n0, bad0 = diff_count()
print("  字节级分叉: %d" % n0)
for b in bad0[:10]:
    print("     %s" % b)
print()

print("=" * 74)
print("② 步骤 1：副库设 core.autocrlf=false")
print("=" * 74)
rc, out, err = gt("config", "core.autocrlf", "false")
print("  exit=%d %s" % (rc, err[:120]))
r = subprocess.run(["git", "config", "core.autocrlf"], cwd=T, capture_output=True)
print("  现值: %s" % r.stdout.decode().strip())
print()

print("=" * 74)
print("③ 步骤 2：加 .gitattributes（src/libtv 永不转换行尾）")
print("=" * 74)
ga = os.path.join(T, ".gitattributes")
content = (
    "# ── libtv 是「从主库同步过来的画布副本」──────────────────────\n"
    "# 它必须与 vendor/shiguang-canvas/src 保持**字节级一致**（含行尾），\n"
    "# 因为 _verify/check_canvas_dual_repo.py 按字节比对、数据契约文件要求\n"
    "# 字节相同。若走 autocrlf 转换，checkout 会把 LF 写成 CRLF ⇒\n"
    "# 双库校验永远报分叉，而 git status 却显示「干净」（比较前已归一化）——\n"
    "# 这种「守卫常红且归因不明」正是守卫被忽视的成因（2026-09-25 实测）。\n"
    "# ⇒ 对本目录关闭一切行尾转换。\n"
    "src/libtv/** -text\n"
)
if os.path.exists(ga) and "src/libtv/**  -text" in io.open(ga, encoding="utf-8").read():
    print("  已存在，跳过")
else:
    mode = "a" if os.path.exists(ga) else "w"
    with io.open(ga, mode, encoding="utf-8") as fh:
        if mode == "a":
            fh.write("\n")
        fh.write(content)
    print("  已写入 .gitattributes（%d 字节）" % os.path.getsize(ga))
print()

print("=" * 74)
print("④ 步骤 3：用索引内容强制重建工作区（此时写回 LF）")
print("=" * 74)
# 改 autocrlf 后，git 会把工作区的 CRLF 视为「已修改」，故用 -f 强制以索引内容覆盖。
# ⚠️ 不要用 git rm --cached：那会把索引条目删掉、使文件变未跟踪。
rc, out, err = gt("checkout", "-f", "--", "src/libtv")
print("  checkout -f exit=%d %s" % (rc, err[:150]))
print()

print("=" * 74)
print("⑤ 修复后复测")
print("=" * 74)
n1, bad1 = diff_count()
print("  字节级分叉: %d（修复前 %d）" % (n1, n0))
for b in bad1[:10]:
    print("     %s" % b)
print()
rc, out, err = gt("status", "--porcelain", "--", "src/libtv")
chg = [l for l in out.splitlines() if l.strip()]
print("  副库 src/libtv 工作区变更: %d 项" % len(chg))
for l in chg[:5]:
    print("     %s" % l[:100])
print()

print("=" * 74)
print("⑥ 提交 .gitattributes + 归位后的副本")
print("=" * 74)
gt("add", "-A", "--", ".gitattributes", "src/libtv")
rc, out, _ = gt("diff", "--cached", "--name-only")
staged = [l for l in out.splitlines() if l.strip()]
print("  暂存 %d 项" % len(staged))
msg = ("chore(eol): 副库 src/libtv 关闭行尾转换，修「永远报分叉」\n\n"
       "根因：副库 core.autocrlf=true，git checkout 把索引里的 LF 写成工作区 CRLF，\n"
       "而 git status 因归一化仍显示「干净」⇒ 双库字节校验永远报分叉且归因不明。\n\n"
       "修复：① core.autocrlf=false ② .gitattributes 对 src/libtv/** 设 -text\n"
       "      ③ 用索引内容重建工作区\n\n"
       "效果：字节级分叉 %d → %d。\n\n"
       "WARNING: 本仓库 origin 为第三方仓库，请勿 push。" % (n0, n1))
mf = os.path.join(T, ".git", "_MSG.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = gt("commit", "-F", mf)
os.remove(mf)
print("  commit exit=%d %s" % (rc, (out.splitlines()[0] if out else err[:250])))
print()

print("=" * 74)
print("⑦ 主仓双库校验（应转绿）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
o = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
print("  exit=%d" % r.returncode)
for l in o.splitlines()[:8]:
    print("     %s" % l[:100])
