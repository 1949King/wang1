# -*- coding: utf-8 -*-
"""侦察：项目主题色 / 品牌元素 / 已有虚拟形象提示词包格式与惯例。"""
import io
import json
import os
import re

ROOT = r"D:\拾光剪影"

print("=" * 74)
print("① 项目主题色（theme_manager / styles.css）")
print("=" * 74)
tm = os.path.join(ROOT, "app", "modules", "lego", "theme_manager.py")
b = io.open(tm, encoding="utf-8-sig", errors="replace").read()
colors = re.findall(r"#[0-9a-fA-F]{6}", b)
from collections import Counter
c = Counter(colors)
print("  theme_manager 里的色值（TOP 18）:")
for k, v in c.most_common(18):
    print("     %s  ×%d" % (k, v))
print()

css = os.path.join(ROOT, "vendor", "shiguang-canvas", "src", "styles.css")
if os.path.exists(css):
    cb = io.open(css, encoding="utf-8", errors="replace").read()
    # 取 CSS 变量定义
    vars_ = re.findall(r"(--[\w-]+)\s*:\s*([^;]+);", cb)
    print("  画布 styles.css 的 CSS 变量（前 30 个）:")
    for k, v in vars_[:30]:
        if any(t in k for t in ("color", "accent", "bg", "primary", "brand", "highlight")):
            print("     %-26s %s" % (k, v.strip()[:50]))
print()

print("=" * 74)
print("② 已有虚拟形象提示词包（V4.39.5 产出）格式与惯例")
print("=" * 74)
pack = os.path.join(ROOT, "vendor", "shiguang-canvas", "public", "prompts",
                    "shiguang-avatar.json")
if os.path.exists(pack):
    data = json.load(io.open(pack, encoding="utf-8"))
    print("  文件: shiguang-avatar.json")
    print("  条目数: %d" % len(data) if isinstance(data, list) else "  结构: %s" % type(data))
    if isinstance(data, list) and data:
        print("  字段集合: %s" % list(data[0].keys()))
        print()
        for i, it in enumerate(data[:4], 1):
            print("  --- 条目 %d ---" % i)
            for k, v in it.items():
                v = str(v)
                print("     %-10s %s" % (k, v[:150] + ("..." if len(v) > 150 else "")))
    print()
    # 统计 category 与 tags 惯例
    if isinstance(data, list):
        cats = {}
        for it in data:
            cats[it.get("category", "?")] = cats.get(it.get("category", "?"), 0) + 1
        print("  category 分布: %s" % cats)
else:
    print("  ❌ 未找到，列 public/prompts 下有什么：")
    d = os.path.join(ROOT, "vendor", "shiguang-canvas", "public", "prompts")
    if os.path.isdir(d):
        for e in sorted(os.listdir(d))[:20]:
            print("     %s" % e)
print()

print("=" * 74)
print("③ 品牌元素线索（Agent 人格定位 / 数字人轨）")
print("=" * 74)
ap = os.path.join(ROOT, "app", "core", "agent_persona.py")
if os.path.exists(ap):
    pb = io.open(ap, encoding="utf-8-sig", errors="replace").read()
    print("  agent_persona.py 开头（定位描述）:")
    for l in pb.splitlines()[:26]:
        if l.strip():
            print("     %s" % l[:104])
