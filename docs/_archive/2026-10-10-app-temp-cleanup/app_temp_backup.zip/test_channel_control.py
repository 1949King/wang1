# -*- coding: utf-8 -*-
"""渠道掌控端到端测试（V4.37.3 接线验证）。

测四层掌控：
  A. 能力声明路由：dashscope 进表 → auto 首选 dashscope → quote 报价正确
  B. 客户端加载：_get_provider("dashscope") 非 None（key 存在）
  C. 额度池记账：失败上报 → 冷却退避 → 健康报表（临时 store，不碰真账号库）
  D. 端到端回退：generate() 在真实 403 下 → 自动降级 seedance/cogvideo（缺模块跳过）
     → local 占位兜底出片 —— 完整掌控链不中断
"""
import io
import json
import sys
import tempfile
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))

PASS, FAIL = 0, 0


def check(cond, msg):
    global PASS, FAIL
    if cond:
        PASS += 1
        print(f"  [PASS] {msg}")
    else:
        FAIL += 1
        print(f"  [FAIL] {msg}")


print("== A. 能力声明路由 ==")
from app.core.ai import provider_caps

caps = provider_caps.get_caps("dashscope")
check(caps is not None, "dashscope 已进能力声明表")
check(caps and caps.get("text_to_video") is True, "声明文生视频能力")
check("dashscope" in provider_caps.DEFAULT_REAL_ORDER, "进 auto 默认顺序")
order = provider_caps.resolve_order("auto", spec={"text_to_video": True})
check(order[0] == "dashscope", f"auto 文生视频首选 dashscope（实际 {order}）")
check(order[-1] == "local", "local 永远兜底在最后")
q = provider_caps.quote("auto", count=3, spec={"text_to_video": True})
check(q["provider"] == "dashscope", f"报价首选 dashscope（实际 {q['provider']}）")
check(q["cost_estimate"] == 4.5, f"3 段估价 4.5 元（实际 {q['cost_estimate']}）")
dropped = provider_caps.filter_by_caps(["dashscope", "local"], spec={"image_to_video": True})
check("dashscope" in [d[0] for d in dropped["dropped"]],
      f"图生视频请求会正确筛掉 dashscope（未接线 i2v）：{dropped['dropped']}")

print("\n== B. 客户端延迟加载 ==")
from app.core.ai.video_generation_client import VideoGenerationClient

client = VideoGenerationClient()
handler = client._get_provider("dashscope")
check(handler is not None, "dashscope handler 加载成功（key 存在）")
check(callable(handler), "handler 可调用")
rows = client.list_providers()
ds_row = next((r for r in rows if r["id"] == "dashscope"), None)
check(ds_row is not None, "list_providers 含 dashscope")
check(ds_row and ds_row.get("available") is True, "dashscope 状态 available=True")
check(ds_row and ds_row.get("price_per_clip") == 1.5, "UI 行带单价 1.5")

print("\n== C. 额度池记账（临时 store） ==")
from app.core.ai.provider_pool import ProviderPool

tmp = Path(tempfile.mkdtemp(prefix="pool_test_")) / "accounts.json"
pool = ProviderPool(store_path=str(tmp))
acct = pool.add_account("dashscope", credential="API Keys.env:DASHSCOPE",
                        daily_quota=10, quality_tier=1, account_id="dashscope_free_01")
check(acct["account_id"] == "dashscope_free_01", "添加 dashscope 账号（引用名，不存明文）")
listed = pool.list_accounts("dashscope")[0]
check("sk-" not in str(listed["credential"]), f"credential 已掩码: {listed['credential']}")
picked = pool.pick("dashscope")
check(picked and picked["account_id"] == "dashscope_free_01", "健康账号可被选中接单")
# 失败上报 → 连败退避
for i in range(3):
    pool.report_failure("dashscope", error="403 AccessDenied")
health = pool.health("dashscope")
check(health.get("healthy") == 0, f"连续失败后账号进冷却（health={health.get('healthy')}）")
picked_after = pool.pick("dashscope")
check(picked_after is None, "冷却期内账号不再被选中（退避生效）")

print("\n== D. 端到端回退（真实 403 → 本地兜底出片） ==")
# 用临时池替换单例的池行为不可行（generate 内部 get_pool），直接走真池（无 dashscope
# 账号 → 透传顺序），验证：真实 403 被记录 + 不中断 + local 占位出片
paths = client.generate(prompt="测试：江南古镇晨雾", duration=3.0, count=1)
check(len(paths) == 1, f"端到端出片 1 段（实际 {len(paths)} 段）")
check(Path(paths[0]).exists() and Path(paths[0]).stat().st_size > 0,
      f"占位片段落盘非空: {paths[0]}")

print(f"\n== 结果：{PASS} PASS / {FAIL} FAIL ==")
sys.exit(1 if FAIL else 0)
