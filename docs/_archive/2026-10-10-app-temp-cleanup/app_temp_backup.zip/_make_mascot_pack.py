# -*- coding: utf-8 -*-
"""产出「拾光·Q版兽耳娘形象包」并注册进画布提示词库。

角色名：小拾（拾光的「拾」，也是「拾起」的动作 —— 点题她拾起光点）
设计依据（全部取自项目实测）：
  · 品牌蓝 #3b82f6（画布 --accent）/ 青色 #2dd4bf / 深夜底 #0a0e14 · #1c2638
  · Agent 定位「知心秘书」：语气可暖，但不说假拟人话 ⇒ 安静专业，不夸张卖萌
  · 功能元素：时间线轨道、画布节点卡、剪辑耳机、胶片徽章
  · 点题动作：手「拾起」一束光点（拾光）
"""
import io
import json
import os
import re
import shutil
import subprocess

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"

# ---------------------------------------------------------------- 提示词包内容
ENTRIES = [
    {
        "id": "mascot-001",
        "title": "小拾·主形象卡（Q版兽耳娘）",
        "category": "portrait",
        "tags": ["企划形象", "Q版", "兽耳娘", "狐耳", "形象主卡", "品牌色", "竖版"],
        "prompt": (
            "Q版二次元兽耳娘角色立绘，2.5头身的大头小身比例，成年女性，完全着装、非性化。"
            "角色设定：一对狐狸兽耳（耳内侧浅色绒毛），一条蓬松狐尾（末端浅色）；"
            "深蓝黑中短发，刘海有一撮品牌蓝(#3b82f6)挑染；青蓝色大眼睛，瞳孔里有细小的星芒光点；"
            "神态安静专注、带温和的职业秘书感，不夸张卖萌。"
            "服装配饰：深色连帽工装短外套(#1c2638)配青色(#2dd4bf)滚边，内搭浅灰高领，"
            "深色工装长裤与白色厚底短靴；头戴式剪辑耳机挂在颈上；胸前一枚小胶片/剪影形状的徽章。"
            "场景道具：深夜工作室，暗蓝背景(#0a0e14)，屏幕蓝光从左侧照来；"
            "她右手轻轻拾起一束悬浮的小光点（点题「拾光」）；"
            "身旁悬浮细长的时间线轨道条与两三张纸片状的画布节点卡片；"
            "右侧一盏发出暖橙光的小台灯形成冷暖对比。"
            "风格：Q版二次元插画，赛璐璐平涂上色，干净描边，柔和体积光与光晕，光尘粒子，"
            "高质量，细节清晰，构图居中留白。竖版3:4。"
        ),
    },
    {
        "id": "mascot-002",
        "title": "小拾·工作表情三连（专注／思考／温和提醒）",
        "category": "consistency",
        "tags": ["企划形象", "表情包", "UI状态", "三连", "角色一致", "温度开关"],
        "prompt": (
            "同一名Q版二次元兽耳娘（2.5头身、狐狸耳与蓬松狐尾、深蓝黑发带品牌蓝挑染、"
            "青蓝大眼、深色工装外套配青色滚边、颈挂剪辑耳机）的三种工作表情三连图，"
            "白底，正面半身，统一打光与服装，五官比例严格一致，排成一行三格。"
            "① 专注：眉头微蹙、紧盯前方、身体略前倾，像在盯时间线；"
            "② 思考：头微侧、一根手指轻托下巴、眼睛看向斜上方，身旁飘一个小问号光点；"
            "③ 温和提醒：眼神柔和、嘴唇轻抿成小弧、一手在身前提着一枚发光的提示卡片。"
            "仅表达清晰的情绪，不夸张卖萌，不做性化处理。"
            "风格：Q版二次元插画，赛璐璐平涂，干净描边，柔和光晕。横版16:9。"
        ),
    },
    {
        "id": "mascot-003",
        "title": "小拾·动态问候（数字人 · 5s）",
        "category": "storyboard",
        "tags": ["企划形象", "动态视频", "数字人", "t2v", "5s", "横屏", "问候"],
        "prompt": (
            "Q版二次元兽耳娘「小拾」半身正面动态镜头：她从画面下方的屏幕蓝光中抬起头，"
            "狐耳轻轻一抖，随即朝镜头挥手打招呼，嘴里说着一句轻声问候；"
            "眼神看向镜头并自然眨眼，发丝与刘海（含那撮品牌蓝挑染）随动作轻晃，"
            "狐尾在身后小幅摆动，胸口有自然呼吸起伏，神情温和而克制。"
            "动作间隙有细小光点从她手边升起并向上飘散。"
            "镜头极缓慢向前微推；背景是深夜工作室，暗蓝底(#0a0e14)、屏幕蓝光与右侧一盏暖橙台灯。"
            "风格：Q版二次元赛璐璐质感，柔和体积光，光尘粒子。横版16:9，时长5秒。"
            "高质量，动态自然，无夸张动作。"
        ),
    },
    {
        "id": "mascot-004",
        "title": "小拾·画布协作场景（节点间指点）",
        "category": "storyboard",
        "tags": ["企划形象", "场景插画", "画布节点", "协作", "横版", "宣发"],
        "prompt": (
            "Q版二次元兽耳娘「小拾」站在悬浮的节点画布中间，正伸手把两张发光的节点卡片用一道细线连接起来，"
            "另一手抱着一卷胶片。她周围漂浮着几张纸片状的节点卡（分别有图像、摄像机、音符的小图标），"
            "脚下是一条发着蓝光的时间线轨道；一只狐耳竖起、另一只微微垂下，眼神专注。"
            "背景为深夜暗蓝(#0a0e14)，屏幕蓝光从左、暖橙台灯光从右，冷暖对比，光尘飘浮。"
            "风格：Q版二次元场景插画，赛璐璐平涂，干净描边，柔和体积光，高质量，构图有纵深。横版16:9。"
        ),
    },
]

content = json.dumps(ENTRIES, ensure_ascii=False, indent=2) + "\n"

# ---------------------------------------------------------------- 写入 4 个位置
targets = [
    os.path.join(C, "public", "prompts", PACK),
    os.path.join(C, "dist", "prompts", PACK),
    os.path.join(T, "public", "prompts", PACK),
    os.path.join(T, "dist", "prompts", PACK),
]
print("=" * 74)
print("① 写入提示词包（4 处）")
print("=" * 74)
for p in targets:
    d = os.path.dirname(p)
    if not os.path.isdir(d):
        print("  ⏭ %s （目录不存在，跳过）" % p)
        continue
    io.open(p, "w", encoding="utf-8").write(content)
    print("  ✅ %s  (%d 字节)" % (os.path.relpath(p, ROOT).replace("\\", "/"), os.path.getsize(p)))
print()

# ---------------------------------------------------------------- 注册（双侧）
print("=" * 74)
print("② 注册进 DEFAULT_PROMPT_SOURCES（主库 + 副库，保持字节一致）")
print("=" * 74)
ANCHOR = """  localAssetSource(
    "shiguang-avatar-pack",
    "拾光·虚拟形象包",
    "shiguang-avatar.json",
    false,
  ),
"""
NEW = ANCHOR + """  localAssetSource(
    "shiguang-mascot-pack",
    "拾光·Q版兽耳娘形象包（小拾）",
    "shiguang-mascot.json",
    false,
  ),
"""
TS = [
    os.path.join(C, "src", "promptLibrary.ts"),
    os.path.join(T, "src", "libtv", "promptLibrary.ts"),
]
for p in TS:
    b = io.open(p, encoding="utf-8").read()
    if "shiguang-mascot-pack" in b:
        print("  ⏭ %s 已注册" % os.path.relpath(p, ROOT))
        continue
    if ANCHOR not in b:
        print("  ❌ %s 找不到锚点，未注册" % os.path.relpath(p, ROOT))
        continue
    io.open(p, "w", encoding="utf-8").write(b.replace(ANCHOR, NEW, 1))
    print("  ✅ %s 已注册" % os.path.relpath(p, ROOT).replace("\\", "/"))
print()

# ---------------------------------------------------------------- 核验
print("=" * 74)
print("③ 核验")
print("=" * 74)
a = io.open(TS[0], "rb").read()
b2 = io.open(TS[1], "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b2 else "❌"))
try:
    json.loads(content)
    print("  JSON 合法: ✅  条目数 %d" % len(ENTRIES))
except Exception as e:
    print("  ❌ JSON 非法: %s" % e)
print()
r = subprocess.run(["python", os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
print("  双库校验 exit=%d" % r.returncode)
for l in out.splitlines()[:6]:
    print("     %s" % l[:100])
