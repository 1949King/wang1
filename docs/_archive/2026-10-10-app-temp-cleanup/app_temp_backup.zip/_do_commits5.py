# -*- coding: utf-8 -*-
"""分批提交 v5。

v4 两个 bug：① 分类写成 `(groups[g] ... ) and append`，空列表假值 → append 永不执行；
② 误判需要 -f。实测 git status 里的路径都是「已跟踪」或「未被忽略的未跟踪」，
精确文件路径下 git add 不需要 -f（v2 报错是因为传了被忽略的*目录*作 pathspec）。
"""
import os, io, subprocess, collections

ROOT = r"D:\拾光剪影"

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    return [(e[:2].strip(), unquote(e[3:])) for e in out.split("\x00") if e.strip()]

def staged():
    rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
    return [l for l in out.splitlines() if l.strip()]

ents = status()
paths_all = [p for _, p in ents]
print("工作区变更条目：%d" % len(ents), flush=True)

SKIP_FILES = {"app/_assess.py", "app/_do_commits.py", "app/_do_commits2.py",
              "app/_do_commits3.py", "app/_do_commits4.py", "app/_do_commits5.py",
              "app/_final_check.py", "app/_audit_commits.py"}

def classify(p):
    if p in SKIP_FILES:
        return None
    if p.startswith(("openshot-qt/", "libopenshot/", "libopenshot-audio", "thirdparty/")) \
       or p.startswith("app/core/video_processing/cpp_engine/openshot_wrapper"):
        return "vendor"
    if p in (".gitignore", ".pre-commit-config.yaml", "ruff.toml", "AGENTS.md",
             "CONTEXT.md", "plugin_config.json") or p.startswith((".github/", ".cursor/", "scripts/")):
        return "config"
    if p.startswith(("app/plugins/", "app/tests/", "app/data/", "app/version.py",
                     "app/__init__.py", "license/", "tests/")):
        return "plugins"
    if p.startswith("app/core/"):
        return "core"
    if p.startswith("app/modules/") or p in ("app/main_qt6.py", "app/verify_c8_qt6.py"):
        return "editor"
    if p.startswith("vendor/shiguang-canvas/"):
        return "canvas"
    if p.startswith(("docs/", ".workbuddy/", ".trae/")):
        return "docs"
    if p.startswith("_verify/"):
        return "verify"
    return None

D = set(p for k, p in ents if k == "D")
raw = collections.defaultdict(list)
unclass = []
for p in paths_all:
    g = classify(p)
    if g is None:
        unclass.append(p)
    else:
        raw[g].append(p)

groups = collections.defaultdict(list)
clean = []
for g, lst in raw.items():
    d_only = [p for p in lst if p in D and g != "vendor"]
    kept = [p for p in lst if p not in d_only]
    groups[g] = kept
    clean.extend(d_only)
groups["clean"] = clean

print("分组统计：")
for g in ("config", "vendor", "clean", "core", "editor", "plugins", "canvas", "docs", "verify"):
    print("   %-8s %d" % (g, len(groups.get(g, []))), flush=True)
print("   未归类(跳过) %d：%s" % (len(unclass), unclass[:10]), flush=True)
print(flush=True)

BATCHES = [
    ("chore(config): 更新忽略规则、CI 工作流与工程约定", "config",
     "更新 .gitignore / pre-commit / ruff / CI 模板与冻结区规则文件"),
    ("chore(vendor): 移除 openshot 第三方参考源码树", "vendor",
     "openshot-qt / libopenshot / libopenshot-audio / thirdparty 整棵上游参考实现；\n"
     "早年拉进来做技术对照，非本项目自有代码"),
    ("chore(clean): 清理已下线模块、合并旧编辑器、移除根目录临时产物", "clean",
     "① 7 个旧 video_editor/* 并入 editor_module.py\n② account_ops 随账号运营下线\n"
     "③ drama_finder_plugin 等无引用早期模块\n④ 根目录历史脚本与日志\n"
     "已做 AST 悬空 import 反查 = 0，无功能损失"),
    ("feat(core): Agent 能力体系与 AI 生成守护管线", "core",
     "app/core 下 agent_* 常量/目录/循环/人格/主动建议、AI 四守护、\n"
     "provider_pool 额度池、score_book 评分回写、context_budget、\n"
     "project_snapshot、timeline_source；log_manager 修 NameError"),
    ("feat(editor): 编辑模块与 Qt6 主窗口", "editor",
     "editor_module 系列 mixin、AI 面板、keyframe 曲线编辑器、导航栏图标、Qt6 入口"),
    ("feat(plugins): 转场插件、测试用例与版本推进", "plugins",
     "6 个转场插件、app/tests 用例更新、data 配置同步，版本推进至 4.35.0"),
    ("feat(canvas): shiguang-canvas 磁吸、新手模式与 Studio 页面", "canvas",
     "magnetic 引擎/bonds/reflow/levels、novice 新手卡、Stage3D/ImageStudio/VideoStudio、\n"
     "comfyToCanvas、cameraRecorder、vitest 配置"),
    ("docs: 归档知识库与历史文档，补充技术报告", "docs",
     "docs/knowledge/* → docs/_archive/knowledge/；根目录与 .trae 历史文档进 _archive；\n"
     "补 docs/_reports 系列报告与冷启动性能诊断、项目 MEMORY.md、CHANGELOG"),
    ("chore(verify): 补 _verify 校验与守卫脚本", "verify",
     "run_all_checks 总入口、scan_undefined_names（AST 作用域 NameError 扫描器）、\n"
     "各项 check_* 一致性守卫与 mjs 镜像测试"),
]

POLLUTION = ("node_modules/", "__pycache__/", "/dist/", "dist/",
             ".pyc", ".db-shm", ".db-wal", ".db", ".tsbuildinfo")

start = len(ents)
print("=" * 72, flush=True)
for idx, (subject, gname, body) in enumerate(BATCHES, 1):
    paths = groups.get(gname, [])
    if not paths:
        print("[%d] 无条目，跳过：%s" % (idx, subject), flush=True)
        continue
    git("reset")
    ps = os.path.join(ROOT, "app", "_ps5.txt")
    io.open(ps, "w", encoding="utf-8").write("\n".join(paths) + "\n")
    rc, out, err = git("add", "-A", "--pathspec-from-file=%s" % ps)
    os.remove(ps)
    if "fatal:" in err:
        print("[%d] ❌ add 失败：%s" % (idx, [l for l in err.splitlines() if "fatal:" in l][:2]), flush=True)
        git("reset")
        continue

    st = staged()
    dirty = [p for p in st if any(x in p for x in POLLUTION)]
    if dirty:
        ps2 = os.path.join(ROOT, "app", "_purge5.txt")
        io.open(ps2, "w", encoding="utf-8").write("\n".join(dirty) + "\n")
        git("rm", "-r", "--cached", "-q", "--pathspec-from-file=%s" % ps2)
        os.remove(ps2)
        print("      🧹 剔除污染项 %d 个" % len(dirty), flush=True)
        st = staged()

    if not st:
        print("[%d] 暂存为空，跳过：%s" % (idx, subject), flush=True)
        continue

    c = collections.Counter(p.split("/")[0] if "/" in p else "(root)" for p in st)
    mf = os.path.join(ROOT, "app", "_msg5.txt")
    io.open(mf, "w", encoding="utf-8").write(subject + "\n\n" + body + "\n")
    rc2, out2, err2 = git("commit", "-F", mf)
    os.remove(mf)
    if rc2 != 0:
        print("      ❌ commit 失败：%s" % err2.strip()[:300], flush=True)
        git("reset")
        continue
    print("[%d] ✅ %s" % (idx, subject[:56]), flush=True)
    print("      %d 个文件 · %s · 剩余 %d" % (len(st), dict(c.most_common(5)), len(status())), flush=True)

print("=" * 72, flush=True)
print("提交前 %d → 提交后 %d" % (start, len(status())), flush=True)
