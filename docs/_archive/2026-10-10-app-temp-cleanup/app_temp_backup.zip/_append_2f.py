# -*- coding: utf-8 -*-
"""补 §2f 画布引擎与架构现状，并提交。"""
import io
import os
import subprocess
import sys
import tempfile

ROOT = r"D:\拾光剪影"
TD = tempfile.gettempdir()
DOC = os.path.join(ROOT, "docs", "现行技术文档.md")

SEC = """
---

## 2f. 画布：引擎分层、架构现状与待改进项（2026-09-26 实测）

### 2f.1 画布有三种「引擎」，别混为一谈

| 层 | 是什么 | 现状（实测） |
|---|---|---|
| ① **宿主引擎** | `engine=shiguang`（WebEngine 内嵌 Qt6，**默认**）／ `engine=tauri`（独立桌面进程） | **只有 shiguang 在服役**；`engine=tauri` 需要的 `src-tauri/target/release` **不存在** ⇒ 宿主 B 处于「有源码、未构建」状态 |
| ② **渲染/交互引擎** | React 19 + `@xyflow/react` 12（图）+ three 0.185（3D）+ zustand 5（状态）+ vite 6 | 版本 **0.3.1**；`canvasVersion.ts` 与 `package.json` **一致 ✅** |
| ③ **生成引擎** | ComfyUI（本地，§2e 已修检测）／ 云端 provider ／ Ollama（本机在跑 :11434） | ComfyUI `engine_valid=true`（未运行时导入工作流会自动拉起） |

### 2f.2 架构（数据流）

```
Qt6 主程序（剪辑线）
  ├─ EditorModule._clips（唯一真相源，RLock）
  └─ canvas_bridge（业务层，冻结区 stage3d-core）
       └─ canvas_server（:18765 · HTTP ~45 端点 + SSE /host/agent/events）
            ↑↓
   ┌──────────┴───────────┐
   │ 宿主 A：WebEngine 内嵌 │  宿主 B：Tauri 独立进程
   │ canvas_runtime :3011   │  读 vendor/AI-Canvas-tauri/src/libtv
   │ → vendor/.../dist      │  （未构建 ⇒ 暂不可用）
   └────────────────────────┘

画布真源：vendor/shiguang-canvas/src   （106 文件 / 43,210 行）
副库副本：vendor/AI-Canvas-tauri/src/libtv（99 文件 / 42,533 行）
```

### 2f.3 待改进项（按优先级）

**P0-a · 画布真源没有 lint，且已有校验脚本未挂载**
| 项 | 真源 shiguang-canvas | 副库 AI-Canvas-tauri |
|---|---|---|
| eslint 配置 | ❌ **无** | ✅ 有 |
| `lint` 脚本 | ❌ **无** | ✅ 有 |
| tsconfig | ✅ | ✅ |
| vitest | ✅ 8 个测试 | ✅ 166 个测试 |

且 `_verify` 下的前端校验**多数未挂载**：
`check_canvas_frontend_quality.mjs` **既不进 pre-commit 也不进 run_all_checks（纯摆设）**；
`_run_tsc.cjs` / `_run_vitest.cjs` 未挂载。
⇒ **画布改动目前只有「双库一致性」一道卡点**，类型检查与 lint 都没强制。
**建议**：把这些已有脚本接进 pre-commit（零新增代码，只接线）。

**P0-b · `prompt-image` 失败无负缓存**（§2d.3 同项，对画布体验影响直接）

**P1 · 双宿主 = 双份维护，但其中一个没在用**
`libtv` 副本（42,533 行）是为 Tauri 宿主存在的，而它未构建 ⇒ 该副本目前**没有实际服役价值**，
却要跟着真源同步（本项目双库漂移复漂的根源）。
**建议二选一**：① 做完抽包 Phase 1-2（只留一份源码）；② 明确「tauri 宿主暂缓」并把 libtv 冻结，停止同步。

**P2 · 画布 5 个最大文件全在冻结区**
`Stage3D.tsx` 4,660 · `riggedHumanoid.ts` 3,707 · `styles.css` 3,550 · `CanvasShell.tsx` 3,199 · `store.ts` 2,452
⇒ 想拆必须先申请解冻（`stage3d-core` / `canvas-magnetic-intent`）。

**P3 · dist 里混装运行时数据**
dist 11.6 MB / 32 文件，其中 **7.3 MB（63%）是 prompts JSON + GLB 模型**，
每次前端构建都要复制一遍；更适合按需从 `public/` 或由宿主提供。

**⚠️ 订正**：§2c.4 曾写「主库侧由 shiguang-canvas 自己的 eslint 负责」——**实测不成立**（无配置、无脚本）。
真源当前只有 tsconfig + vitest 两道，且均未强制挂载。
"""

b = io.open(DOC, encoding="utf-8").read()
if "## 2f. 画布：引擎分层" in b:
    print("已存在，跳过")
else:
    io.open(DOC, "a", encoding="utf-8").write(SEC)
    print("已追加 §2f（%d 字节）" % os.path.getsize(DOC))

print()
print("=" * 74)
print("提交")
print("=" * 74)
ps = os.path.join(TD, "_ps8.txt")
io.open(ps, "w", encoding="utf-8").write("docs/现行技术文档.md\n")
subprocess.run(["git", "add", "-A", "--pathspec-from-file=" + ps], cwd=ROOT, capture_output=True)
msg = """docs(canvas): 补 §2f 画布引擎分层/架构现状/待改进项；订正 §2c.4 的错误表述

订正：§2c.4 曾写「主库侧由 shiguang-canvas 自己的 eslint 负责」——
2026-09-26 实测不成立：真源 vendor/shiguang-canvas **没有 eslint 配置**、
package.json 也没有 lint 脚本 ⇒ 画布真源目前**没有 lint 门禁**。

§2f 记录（均实测）：
· 三种「引擎」分层：宿主(shiguang/tauri) · 渲染栈(React19+xyflow+three) · 生成(ComfyUI/Ollama)
· 宿主 B (tauri) 的 src-tauri/target/release 不存在 ⇒ "有源码未构建"，暂不可用
· 画布版本三件套一致（canvasVersion.ts == package.json == 0.3.1）
· 待改进：P0 画布真源缺 lint + 已有校验脚本未挂载（前端质量/tsc/vitest 三脚本均未接线）
        P1 双宿主双份维护但 tauri 未服役（libtv 42,533 行无实际服役价值，却是漂移根源）
        P2 画布 5 个最大文件全在冻结区
        P3 dist 混装运行时数据（63% 是 prompts/GLB）

WARNING: 仅本地提交，未 push。"""
mf = os.path.join(TD, "_msg8.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
r = subprocess.run(["git", "commit", "-F", mf], cwd=ROOT, capture_output=True)
out = r.stdout.decode("utf-8", "replace").strip()
err = r.stderr.decode("utf-8", "replace").strip()
print("  exit=%d  %s" % (r.returncode, out.splitlines()[0] if out else err[:200]))
