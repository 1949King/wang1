# -*- coding: utf-8 -*-
"""验证规格说明书完整性：是否被误追加/重复。"""
import os, io, collections

P = r"D:\拾光剪影\docs\_reports\2026-09-23-拾光剪影-架构与算法规格说明书.md"
raw = io.open(P, "rb").read()
s = raw.decode("utf-8", "replace")
L = s.splitlines()

print("字节数: %d   行数: %d   字符数: %d" % (len(raw), len(L), len(s)))
print("平均每行字节: %.1f （>3 说明含中文，正常）" % (len(raw) / max(1, len(L))))
print()

print("=== 关键标题出现次数（>1 即重复）===")
keys = [
    "# 拾光剪影 — 项目架构与算法说明书",
    "# 第〇篇 阅读指南",
    "# 第一篇 总体架构",
    "# 第二篇 模块地图",
    "# 第三篇 核心机制",
    "# 第四篇 算法与公式",
    "# 第五篇 数据流与主链路",
    "# 第六篇 工程约束与铁律",
    "# 附录A 术语词典",
    "# 附录B 模块速查索引",
    "# 附录C 规模基线与版本",
]
for k in keys:
    n = s.count(k)
    print("  %-38s %d %s" % (k.replace("# ", ""), n, "OK" if n == 1 else "!! 重复"))
print()

print("=== 重复行 TOP 10（出现 >=3 次且长度>20）===")
c = collections.Counter(l.strip() for l in L if len(l.strip()) > 20)
for line, n in c.most_common(10):
    print("  x%-3d %s" % (n, line[:90]))
print()

print("=== 首尾各 3 行 ===")
for l in L[:3]:
    print("  头:", l[:100])
print("   ...")
for l in L[-3:]:
    print("  尾:", l[:100])
print()

print("=== 结构统计 ===")
print("  编号小节 ## N. :", len([l for l in L if l.startswith("## ") and l[3:4].isdigit()]))
print("  子节 ###      :", len([l for l in L if l.startswith("### ")]))
print("  表格行 |      :", len([l for l in L if l.startswith("|")]))
print("  代码围栏      :", len([l for l in L if l.strip().startswith("```")]))
