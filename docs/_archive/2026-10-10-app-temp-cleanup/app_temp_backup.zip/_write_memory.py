# -*- coding: utf-8 -*-
"""把本轮分析写入项目工作记忆（用脚本落盘，避免内联命令被 shell 误执行）。"""
import os
import io

P = r"D:\拾光剪影\.workbuddy\memory\2026-09-25.md"

NOTE = """
## 项目本质与技术债分析（22:46 - 23:10）· V4.39.5

用户：「解析项目的本质并分析它的技术债务，需要该怎么去解决优化」。

产出 `docs/_reports/2026-09-25-项目本质与技术债分析及优化方案.md`（30,844 字节 / 477 行 / 174 行表格）。
采集脚本三个（`app/temp/_debt_scan{,2,3}.py`，gitignore 目录内）。

### 本质结论（核心洞察，别丢）

**不是"一个软件"，是三套世界观不同的系统用一条 HTTP 桥粘在一起，由一个人维护。**
- ① 剪辑器（真相源 `_clips` + RLock，绝对时间轴，强一致性要求）
- ② 生成编排引擎（无长期状态，无时间，可降级）
- ③ 节点式创作台（Zustand store，图结构，可 undo/redo）

**三者的世界观冲突是债的根因**：失败观不同（可见 vs 降级 vs 诚实）→ 同一个 except 该不该 pass 有不同答案；
时间观不同（帧级可撤销 vs 整段原子 vs 图撤销）→ 画布↔时间线回流的撤销语义至今没统一。

**四条结构性原因**：R1 抽象速度<演化速度（竖切开发）· R2 单人带宽=维护天花板 ·
**R3 守卫缺失处必然复漂**（最重要的发现）· R4 AI 协作放大产出也放大不一致。

**结论**：债不是质量问题，是结构必然。优化目标 = **给每个复利口装守卫，让债增速降到 0 或负。**

### 最关键的一条发现（S1）

项目文档 §6.7 称 Phase 0-a「78 文件 MD5 100% 一致，漂移=0」，但**本次实测已复漂 23 个文件 / 副库缺 19 个**。
最大分叉：`useMagneticDrag.ts` 主库 468 / 副库 153（**差 315 行**，三段式手感副库完全没有）。
⇒ **把 Phase 3（CI 防漂卡点）从"未开始"提前到 P0**，否则 Phase 1-2 抽包会在移动靶子上施工。

其余 S 级：S2 `editor_module.py` 9,717 行 · S3 **副库未被 git 跟踪（唯一不可逆债，文档自承"曾无路可走"）**。

### 两个虚高数字（方法学纠偏，必须记住）

| 初测 | 纠偏后 | 原因 |
|---|---|---|
| `print()` 3,821 处 | **生产侧仅 217 处 / 28 文件** | 其余在 tests/legacy(1548)、app/temp(364)、tests/unit(340)、verification(253)——那里 print 是正确用法 |
| 前端测试 174 个 | **真源仅 8 个** | 166 个来自副库 AI-Canvas-tauri（参考仓自带，与主库无关） |

第三个坑：复核"未接线"时，用 `git grep` 会漏未跟踪文件，**改用文件系统 grep 又会把自己的采集脚本算进去**——两个方向都要防。

### 实测基线（2026-09-25）

总规模 1,413 文件 / **428,670 行**（Py 623/203,281 + TS 790/225,389 含副库副本）。
分层：app/core 180/82,602 · app/modules 97/70,613 · canvas 106/38,740 · _verify 91/13,003 · tests 78/12,218。
>1200 行 45 个（占全部行数 23.0%）；>2000 行 12 个（与 `_verify/check_file_size.py` 基线一致）。
债务气味：except:pass **155 处/70 文件** · 裸 except 13 · hasattr/getattr 1,664 · setStyleSheet **938 处/45 文件** · TODO 仅 20（反向信号：债没被登记）。
同名类 **52 组**（真债 6 组：LicenseManager/Keyframe/PerformanceMonitor/TaskStatus/_LazyModuleProxy/_LazyClassProxy；`Plugin`×27 是设计使然）。
git：61 提交 · `.git` **2,897 MB**。

### 状态机路径静默异常精确清单（≈41 处，8 文件，按项目自身判定线筛出）

`editor_agent_runtime_mixin`(6) · `local_video_infer`(6) · `canvas_agent_runtime`(6) · `model_management`(5) ·
`project_agent_host`(5) · `ai/video_generation_client`(5) · `preview_manager`(4) · `playback_shuttle`(4) · `canvas_runtime`(4) · `main_qt6`(4，有意降级但缺 debug 日志)。
排除项：`clip_widget`(12)/`timeline_widget`(10)/`timeline_subwidgets`(3) 属 UI 绘制，按判定线**可接受，不动**。

### 未接线模块（实测复核）

`engine_api.py` 生产引用 **0**（V4.38.5 收官之作，门面从未被调用 ⇒ **"代码层落地"≠"链路层落地"**）·
`module_scheduler.py` 0 · `simulator.py` 0（属测试面可接受）· `fusion.py` 文本/音频算子 0（视频已接）·
`global_price.auction()` 0（λ 已接）。合计约 1,300 行"在维护但不在服役"。

### 方案骨架

P0（本周 3 项）：① 双库漂移卡点 + 基线收紧到 23 ② 副库单独建本地 git（消除不可逆）
③ 静默异常精修 41 处 + 给 `stability_gate.py` 加"状态机路径禁 pass"规则。
P1（本月 3 项）：④ 继续拆 editor_module（给出 5 段行号区间，**注意 playback-av/exit-media/clip-transform 三冻结区在区间内，须先解冻**）
⑤ 未接线模块二选一（接线 or 归档，落台账）⑥ 测试盘点：先跑全量拿真实通过率 + `tests/legacy` 归档 + 3 个守卫接 pre-commit。
P2（季度）：同名类 6 组 · 内联样式治理（只装新增守卫，不全量重写）· 双库抽包（须在 P0-1 之后）· `.git` gc · 清悬空引用。

**反模式（明确不做）**：为降行数而拆 · 全量 print→logger · 修 npm audit 5 漏洞 · 升 numpy 2.x/任何 MAJOR ·
动冻结区"顺手优化" · 一次性统一三系统领域模型 · 把副库纳入主库 git。

### 资产澄清（别误当债清掉）

冻结区 85 锁点 = **本项目最成功的资产**（证据：进冻结区的功能都没回归，没进的反复改）；
双版本号 = 有意设计；8 个前端纯函数测试 = 投入产出比最高的一类；依赖钉死 + 故意不修 npm audit = 判断正确；
">2000 行只许减不许增" = 正确模式，本报告推荐全面采用。
"""

existing = io.open(P, encoding="utf-8").read() if os.path.exists(P) else "# 2026-09-25 工作记录\n"
marker = "## 项目本质与技术债分析"

if marker in existing:
    print("ALREADY_PRESENT")
else:
    io.open(P, "w", encoding="utf-8").write(existing.rstrip("\n") + "\n" + NOTE)
    print("APPENDED -> %s (%d bytes)" % (P, os.path.getsize(P)))
