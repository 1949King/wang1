# -*- coding: utf-8 -*-
"""补充度量：双库重复 / print 分布 / 静默异常位置 / 未接线复核。"""
import os
import io
import re
import hashlib
import subprocess
import collections

ROOT = r"D:\拾光剪影"

print("=" * 72)
print("① 双库重复度（shiguang-canvas 主库 vs AI-Canvas-tauri/src/libtv 副库）")
print("=" * 72)
A = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
B = os.path.join(ROOT, "vendor", "AI-Canvas-tauri", "src", "libtv")


def files_under(base):
    out = {}
    if not os.path.isdir(base):
        return out
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in ("node_modules", "dist", "__pycache__")]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css", ".json")):
                rel = os.path.relpath(os.path.join(dp, f), base).replace("\\", "/")
                out[rel] = os.path.join(dp, f)
    return out


fa, fb = files_under(A), files_under(B)
print("  主库 src 文件: %d   副库 libtv 文件: %d" % (len(fa), len(fb)))

same = diff = only_a = only_b = 0
diff_list = []
for k in sorted(set(fa) | set(fb)):
    if k in fa and k in fb:
        ha = hashlib.md5(io.open(fa[k], "rb").read()).hexdigest()
        hb = hashlib.md5(io.open(fb[k], "rb").read()).hexdigest()
        if ha == hb:
            same += 1
        else:
            diff += 1
            la = io.open(fa[k], encoding="utf-8", errors="replace").read().count("\n")
            lb = io.open(fb[k], encoding="utf-8", errors="replace").read().count("\n")
            diff_list.append((abs(la - lb), k, la, lb))
    elif k in fa:
        only_a += 1
    else:
        only_b += 1
print("  两边都有且完全一致: %d" % same)
print("  两边都有但内容分叉: %d" % diff)
print("  仅主库有: %d   仅副库有: %d" % (only_a, only_b))
print()
print("  分叉最大的 15 个文件（行数差）:")
for d, k, la, lb in sorted(diff_list, reverse=True)[:15]:
    print("    差%5d行  %-46s 主库%5d / 副库%5d" % (d, k, la, lb))
print()

print("=" * 72)
print("② print( 分布 —— 集中在哪一层")
print("=" * 72)
SKIP = {".git", ".venv312", "node_modules", "__pycache__", "dist", "build", "openshot-qt"}
by_area = collections.Counter()
top_files = []
for dp, dns, fns in os.walk(ROOT):
    dns[:] = [d for d in dns if d not in SKIP]
    for f in fns:
        if not f.endswith(".py"):
            continue
        rel = os.path.relpath(os.path.join(dp, f), ROOT).replace("\\", "/")
        if "_archive" in rel:
            continue
        try:
            body = io.open(os.path.join(dp, f), encoding="utf-8-sig", errors="replace").read()
        except Exception:
            continue
        n = len(re.findall(r"^\s*print\(", body, re.M))
        if not n:
            continue
        top = rel.split("/")[0] + ("/" + rel.split("/")[1] if "/" in rel else "")
        by_area[top] += n
        top_files.append((n, rel))
for k, v in by_area.most_common(12):
    print("  %-28s %5d" % (k, v))
print()
print("  单文件最多 TOP 10:")
for n, p in sorted(top_files, reverse=True)[:10]:
    print("    %5d  %s" % (n, p))
print()

print("=" * 72)
print("③ 静默 except: pass —— 按文件分布（判定线：状态机/资源路径不可接受）")
print("=" * 72)
sil = []
for dp, dns, fns in os.walk(ROOT):
    dns[:] = [d for d in dns if d not in SKIP]
    for f in fns:
        if not f.endswith(".py"):
            continue
        rel = os.path.relpath(os.path.join(dp, f), ROOT).replace("\\", "/")
        if "_archive" in rel:
            continue
        try:
            body = io.open(os.path.join(dp, f), encoding="utf-8-sig", errors="replace").read()
        except Exception:
            continue
        n = len(re.findall(r"except[^:\n]*:\s*\n\s*pass\b", body))
        if n:
            sil.append((n, rel))
sil.sort(reverse=True)
print("  合计 %d 处 / %d 个文件" % (sum(n for n, _ in sil), len(sil)))
print("  TOP 15:")
for n, p in sil[:15]:
    print("    %4d  %s" % (n, p))
print()

print("=" * 72)
print("④ 未接线复核（用文件系统 grep，git grep 会漏未跟踪文件）")
print("=" * 72)
NEEDLES = ["get_scheduler", "get_engine_api", "get_global_price", "get_pacer",
           "get_probe", "get_review", "get_store", "get_pool", "get_classifier"]
hits = collections.defaultdict(list)
for dp, dns, fns in os.walk(ROOT):
    dns[:] = [d for d in dns if d not in SKIP]
    for f in fns:
        if not f.endswith(".py"):
            continue
        rel = os.path.relpath(os.path.join(dp, f), ROOT).replace("\\", "/")
        if "_archive" in rel:
            continue
        try:
            body = io.open(os.path.join(dp, f), encoding="utf-8-sig", errors="replace").read()
        except Exception:
            continue
        for nd in NEEDLES:
            for m in re.finditer(r"\b%s\b" % nd, body):
                hits[nd].append(rel)

for nd in NEEDLES:
    fs = hits.get(nd, [])
    prod = [x for x in fs if x.startswith("app/") and "/ai/" not in x]
    inai = [x for x in fs if x.startswith("app/core/ai/")]
    veri = [x for x in fs if x.startswith("_verify")]
    tests = [x for x in fs if "test" in x]
    print("  %-18s 生产(非ai) %d · ai内 %d · _verify %d · 测试 %d"
          % (nd, len(prod), len(inai), len(veri), len(tests)))
    for p in prod[:3]:
        print("        生产引用 -> %s" % p)
