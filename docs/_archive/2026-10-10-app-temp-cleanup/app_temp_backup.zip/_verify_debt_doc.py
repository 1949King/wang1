# -*- coding: utf-8 -*-
"""校验技术债报告完整性 + 清理采集脚本残留检查。"""
import os
import io
import re
import subprocess

P = r"D:\拾光剪影\docs\_reports\2026-09-25-项目本质与技术债分析及优化方案.md"
s = io.open(P, encoding="utf-8").read()
L = s.splitlines()

print("字节 %d / 行 %d / 字符 %d" % (os.path.getsize(P), len(L), len(s)))
print()

print("=== 一级标题（应为 5 部分 + 附录）===")
for l in L:
    if l.startswith("# "):
        print("  ", l)
print()

print("=== 关键锚点检查 ===")
keys = ["结论速览", "世界观冲突", "为什么必然产生债", "S1 · 双库副本无 CI 卡点",
        "A1 · 状态机", "未接线模块", "P0-1", "P0-2", "P0-3", "P1-4", "P1-5", "P1-6",
        "反模式", "验收指标", "30 / 60 / 90", "方法学声明"]
for k in keys:
    print("  %s %s" % ("OK  " if k in s else "MISS", k))
print()

print("=== 结构统计 ===")
print("  表格行:", len([l for l in L if l.startswith("|")]))
print("  二级标题:", len([l for l in L if l.startswith("## ")]))
print("  代码块围栏:", len([l for l in L if l.strip().startswith("```")]))
print()

BAD = ["command not found", "syntax error", "No such file or directory", "bash.exe"]
hits = [(i, l) for i, l in enumerate(L, 1) for b in BAD if b in l]
print("  混入 shell 报错文本:", hits[:3] if hits else "无")
print()

print("=== 根目录 0 字节怪文件复查 ===")
ROOT = r"D:\拾光剪影"
zero = [e for e in sorted(os.listdir(ROOT))
        if os.path.isfile(os.path.join(ROOT, e))
        and os.path.getsize(os.path.join(ROOT, e)) == 0]
for e in zero:
    r = subprocess.run(["git", "ls-files", "--error-unmatch", "--", e],
                       cwd=ROOT, capture_output=True)
    print("  %-24s 已跟踪=%s" % (repr(e), r.returncode == 0))
print()

r = subprocess.run(["git", "-c", "core.quotePath=false", "status", "--porcelain", "-uall"],
                   cwd=ROOT, capture_output=True)
lines = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
print("git status: %d 项" % len(lines))
for l in lines:
    print("   ", l[:105])
