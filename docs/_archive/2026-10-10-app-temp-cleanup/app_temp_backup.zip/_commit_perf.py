# -*- coding: utf-8 -*-
"""提交冷启动优化 + 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-25.md")
TD = tempfile.gettempdir()


def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


MSG = """perf(startup): 冷启动 ~55s → ~1s；依赖检查改 find_spec + GPU 探测改 pynvml

## 真因（实测，非推测）
DependencyChecker.check_dependencies() 为「检查依赖」用 __import__ 把 16 个包
真的导了一遍（必需 9 + 可选 7），而调用方 _check_environment 只用到其中一项
（PyQt6 是否存在）——其余 15 个导完即丢。

实测单包导入成本：transformers 33.7s · torch 11.2s · mediapipe 4.3s
⇒ 16 包合计 __import__ 27.04s（热态）vs find_spec 0.02s（1226×）

## 两处修改（app/main_qt6.py）
1. check_dependencies: __import__ → importlib.util.find_spec（只定位、不执行）
   · 新增 _probe_installed()
   · 排查开关 SHIGUANG_STRICT_DEPS=1 可恢复旧的真导入行为
2. check_gpu: 优先 pynvml（0.06s），不可用才回退 torch（2.56s）
   设备名实测一致：NVIDIA GeForce RTX 4060 Laptop GPU

## 行为等价性（改前已证明）
两种方式对 16 个包逐项判定：15 项一致；唯一差异 mediapipe
（find_spec=True / __import__=False）恰恰是新行为更准确 —— 见下。

## 顺带查实一个陷阱（已写入代码注释防复发）
PyQt6 与 mediapipe 存在 DLL 加载顺序冲突：
  裸 mediapipe ✅ / PyQt6 后 mediapipe ❌ DLL load failed /
  mediapipe 先则 ✅；与 cv2/torch/easyocr/transformers 任意组合正常。
当前架构未踩到（姿态解析走独立子进程，不加载 PyQt6）；
但历史 check_dependencies 在主进程内导 mediapipe ⇒ 必然失败 ⇒ 误报「未安装」。

## 实测效果
  检查运行环境      54s（冷态） → 0s
  首个日志→启动成功  ~55s      → 1s
  首个日志→画布就绪  ~60s      → 5s
（口径：前为冷态、后为热态，不可直接相减；机制上确去掉 27s 真实导入执行。）

## 另记一个待处理项
启动日志显示 canvas_bridge 的 /host/prompt-image 对同一批 URL 反复重试
（00:06:44→00:07:55 多轮），失败无负缓存 ⇒ 每次启动重试、刷日志、拖慢启动。
建议加失败负缓存（TTL）或改按需加载。

WARNING: 仅本地提交，未 push。
"""

PATHS = ["app/main_qt6.py", "docs/现行技术文档.md"]

print("=" * 74)
print("① 编译 + 冻结区检查")
print("=" * 74)
import sys
body = io.open(os.path.join(ROOT, "app", "main_qt6.py"), encoding="utf-8-sig").read()
try:
    compile(body, os.path.join(ROOT, "app", "main_qt6.py"), "exec")
    print("  ✅ main_qt6.py 编译通过（%d 行）" % len(body.splitlines()))
except SyntaxError as e:
    print("  ❌ %s" % e)
    sys.exit(1)
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "frozen_zone_guard.py")],
                   cwd=ROOT, capture_output=True)
print("  冻结区: %s" % (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()[-60:])
print()

print("=" * 74)
print("② 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_ps6.txt")
io.open(ps, "w", encoding="utf-8").write("\n".join(PATHS) + "\n")
git("add", "-A", "--pathspec-from-file=" + ps)
rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
print("  暂存: %s" % [l for l in out.splitlines() if l.strip()])
mf = os.path.join(TD, "_msg6.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  commit exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

NOTE = """
## 冷启动优化 + 新机会扫描（23:58 - 00:12）· 主仓补提交

用户问：「还有哪些能进行优化？」

### 扫出并已修：冷启动 ~55s → ~1s（本轮最大单项收益）

**真因（实测，我两次猜错后才找到）**：
1. 先猜 transformers → ❌ 错：`app/` 里 transformers 导入点 **0 处**（我测的是库自身导入成本）
2. 再猜「模块级导入慢」→ ❌ 错：`import app.main_qt6` 只要 **0.3s / 142 模块**（重导入都藏在函数里，已优化得很好）
3. **真因**：`DependencyChecker.check_dependencies()`（L224-242）为「检查依赖」用
   `__import__(import_name)` **把 16 个包真的导了一遍**（必需9+可选7），
   而调用方 `_check_environment`(L341) **只用到其中一项**（PyQt6 是否存在，L343）。

单包成本：transformers 33.7s · torch 11.2s · mediapipe 4.3s · 其余 <1s
⇒ 16 包 `__import__` = **27.04s**（热态）vs `find_spec` = **0.02s**（**1226×**）

**两处修改**（`app/main_qt6.py`，非冻结区）：
- `check_dependencies`: `__import__` → `importlib.util.find_spec`（只定位不执行）；新增 `_probe_installed()`；
  排查开关 `SHIGUANG_STRICT_DEPS=1` 恢复旧行为
- `check_gpu`: 优先 `pynvml`（0.06s），不可用才回退 `torch`（2.56s）；设备名实测一致

**实测**：检查运行环境 54s→**0s**；首个日志→启动成功 ~55s→**1s**；→画布就绪 ~60s→5s
（口径：前冷态、后热态，不可直接相减；机制上确去掉 27s 真实导入执行）

### 顺带查实一个 DLL 陷阱（已写入代码注释防复发）

**PyQt6 与 mediapipe 存在 DLL 加载顺序冲突**（实测）：
`import PyQt6` → `import mediapipe` = ❌ `DLL load failed while importing _framework_bindings`；
反过来（mediapipe 先）✅；与 cv2/torch/easyocr/transformers 任意组合 ✅ 正常。

- **当前架构未踩到**：姿态解析走**独立子进程**（`pose_extract_service.py:4` 明示，用 subprocess 跑 pose_worker.py），子进程不加载 PyQt6
- **历史实现踩到了**：`check_dependencies` 在主进程内（PyQt6 已加载）真导 mediapipe ⇒ 必然失败 ⇒ **误报「未安装」**（其实装了，0.10.21）
- ⇒ 改 `find_spec` 后误诊顺带消失。**将来若把姿态推理搬进主进程，必须先解决此冲突**

### 新机会扫描（报告未登记，本次新发现）

**Ⓐ 磁盘/产物堆积 ≈2.75 GB**：`dist` 1909.9MB · `拾光剪影-发布版.zip` 743.2MB（根目录旧发布包）·
`app/logs` 88.4MB/124 文件 · `build` 79.6MB · `新建文件夹` 15.9MB

**Ⓑ 测试空白（比报告 A3 更具体）**：**所有高风险模块都没有同名测试** ——
editor_module 9,717行·0 · canvas_server 3,273·0 · canvas_aigc 2,905·0 ·
drama_understanding_engine 2,160·0 · capability_handlers 1,644·0 · project_agent_host 1,034·0 ·
video_generation_client 909·0（仅 preview_manager 有 1 个）
⇒ 这才是「改这些文件没安全网」的根因

**Ⓒ 耦合枢纽**：`modules.py` 被引用 **307 次**（1,612 行）· `editor_module.py` 179 次
⇒ 之前只盯 editor_module 的长度，**modules.py 才是最大耦合中心**

**Ⓓ 硬编码耦合**：端口字面量 47 处/14 文件（18765/3010/3011/17371/11434 —— 而这些是**冻结不变量**，
散落 47 处意味着改端口必漏）· 127.0.0.1 60 处 · provider 名 80 处 · `time.sleep` 43 处/17 文件 ·
Windows 绝对路径 8 处

**Ⓔ 重复实现**：ffmpeg 定位 56 处/14 文件 · atomic_write 29 处/16 文件 · retry 13 处/10 文件

**Ⓕ 日志轮转**：`log_manager` **有** RotatingFileHandler/maxBytes/backupCount/cleanup_old_logs，
但 8月12日、8月22日的日志仍在 ⇒ **cleanup_old_logs 未被调用或阈值过宽**（88.4MB 持续增长）

**Ⓖ 新发现（待处理）**：启动日志显示 `canvas_bridge - prompt-image failed` 对同一批 URL
（pbs.twimg.com / cdn.jsdelivr.net）在 00:06:44→00:07:55 **重复请求多轮**
⇒ 失败无负缓存，每次启动重试 + 刷日志 + 拖慢启动。建议加 TTL 负缓存或改按需加载。

**Ⓗ dist 不落后**：画布 dist（21:45）不早于源码（21:44）✅ 无此项债
"""

existing = io.open(MEM, encoding="utf-8").read()
if "冷启动优化 + 新机会扫描" in existing:
    print("ALREADY_PRESENT")
else:
    io.open(MEM, "w", encoding="utf-8").write(existing.rstrip("\n") + "\n" + NOTE)
    print("③ 记忆已写入 -> %d bytes" % os.path.getsize(MEM))
