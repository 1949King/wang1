# -*- coding: utf-8 -*-
"""收尾 v2：① 把临时脚本移出仓库（move，不删）② 补提遗漏的删除项。"""
import os, io, subprocess, tempfile, shutil, collections, time

ROOT = r"D:\拾光剪影"
TD = tempfile.gettempdir()
OUT = os.path.join(TD, "sg_jianguying_tmp_%d" % int(time.time()))
os.makedirs(OUT, exist_ok=True)

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    return [(e[:2].strip(), unquote(e[3:])) for e in out.split("\x00") if e.strip()]

# ---------- ① 临时脚本搬出仓库 ----------
pref = ("_do_commits", "_assess", "_final_check", "_audit_commits",
        "_ps5", "_purge5", "_m_7", "_finalize")
mine = [p for k, p in status() if k == "??" and os.path.basename(p).startswith(pref)]
moved = 0
for rel in mine:
    src = os.path.join(ROOT, *rel.split("/"))
    try:
        shutil.move(src, os.path.join(OUT, os.path.basename(rel)))
        moved += 1
    except Exception as e:
        print("   移出失败 %s: %s" % (rel, e))
print("① 临时脚本已移出仓库 %d/%d → %s" % (moved, len(mine), OUT))
print()

# ---------- ② 补提删除 ----------
ents = status()
dels = [p for k, p in ents if k == "D"]
print("② 待补提的删除项：%d" % len(dels), flush=True)
if dels:
    git("reset")
    ps = os.path.join(OUT, "_ps.txt")
    io.open(ps, "w", encoding="utf-8").write("\n".join(dels) + "\n")
    rc, out, err = git("add", "-A", "--pathspec-from-file=%s" % ps)
    if "fatal:" in err:
        print("   ❌ add 失败：%s" % [l for l in err.splitlines() if "fatal:" in l][:2])
    else:
        rc2, st, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
        paths = [l for l in st.splitlines() if l.strip()]
        c = collections.Counter(x.split("/")[0] if "/" in x else "(root)" for x in paths)
        body = ("补提前一批遗漏的部分：根目录历史文档/临时脚本/运行日志、\n"
                "空壳 integrations 包、旧 plugin/ 包、app/utils/cache_system.py 等。\n"
                "均为已确认无引用的删除项。")
        mf = os.path.join(OUT, "_msg.txt")
        io.open(mf, "w", encoding="utf-8").write(
            "chore(clean): 补提散落的删除项（根目录文档/脚本/日志与空壳包）\n\n" + body + "\n")
        rc3, out3, err3 = git("commit", "-F", mf)
        if rc3 == 0:
            print("   ✅ 已提交 %d 个文件 · 顶层 %s" % (len(paths), dict(c.most_common(6))))
        else:
            print("   ❌ commit 失败：%s" % err3.strip()[:300])
            git("reset")

print()
print("=" * 66)
left = status()
print("最终剩余 %d 项：" % len(left))
for k, p in left:
    print("   %-3s %s" % (k, p[:90]))
