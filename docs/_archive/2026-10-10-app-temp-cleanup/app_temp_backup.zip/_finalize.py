# -*- coding: utf-8 -*-
"""收尾：① 删除本轮我建的临时脚本 ② 补提交分类器漏掉的 56 项删除。"""
import os, io, subprocess, tempfile, collections

ROOT = r"D:\拾光剪影"
TD = tempfile.gettempdir()

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    return [(e[:2].strip(), unquote(e[3:])) for e in out.split("\x00") if e.strip()]

# ---------- ① 删除我本轮建的临时脚本 ----------
mine = [p for k, p in status() if k == "??" and os.path.basename(p).startswith(
        ("_do_commits", "_assess", "_final_check", "_audit_commits", "_ps5", "_purge5", "_m_7"))]
print("① 删除临时脚本 %d 个：" % len(mine))
removed = 0
for rel in mine:
    p = os.path.join(ROOT, *rel.split("/"))
    try:
        os.remove(p)
        removed += 1
    except Exception as e:
        print("   失败 %s : %s" % (rel, e))
print("   实际删除 %d 个" % removed)
print()

# ---------- ② 补提交剩余删除 ----------
ents = status()
dels = [p for k, p in ents if k == "D"]
print("② 剩余待提交的删除项：%d" % len(dels), flush=True)
for p in dels[:8]:
    print("   D %s" % p[:80])
print("   ...")
print()

if dels:
    git("reset")
    ps = os.path.join(TD, "_sg_final_ps.txt")
    io.open(ps, "w", encoding="utf-8").write("\n".join(dels) + "\n")
    rc, out, err = git("add", "-A", "--pathspec-from-file=%s" % ps)
    if "fatal:" in err:
        print("   ❌ add 失败：%s" % [l for l in err.splitlines() if "fatal:" in l][:2])
    else:
        rc2, st, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
        paths = [l for l in st.splitlines() if l.strip()]
        c = collections.Counter(x.split("/")[0] if "/" in x else "(root)" for x in paths)
        body = ("补提前一批遗漏的部分：根目录历史文档/临时脚本/运行日志、\n"
                "空壳 integrations 包、旧 plugin/ 包、app/utils/cache_system.py 等。\n"
                "均为确认无引用的删除项。")
        mf = os.path.join(TD, "_sg_final_msg.txt")
        io.open(mf, "w", encoding="utf-8").write(
            "chore(clean): 补提散落的删除项（根目录文档/脚本/日志与空壳包）\n\n" + body + "\n")
        rc3, out3, err3 = git("commit", "-F", mf)
        if rc3 == 0:
            print("   ✅ 已提交 %d 个文件 · 顶层 %s" % (len(paths), dict(c.most_common(6))))
        else:
            print("   ❌ commit 失败：%s" % err3.strip()[:300])
            git("reset")

print()
print("=" * 66)
left = status()
print("最终剩余：%d 项" % len(left))
for k, p in left:
    print("   %-3s %s" % (k, p[:90]))
