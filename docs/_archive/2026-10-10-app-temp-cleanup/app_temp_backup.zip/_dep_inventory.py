# -*- coding: utf-8 -*-
"""依赖现状盘点：实际安装版本 + 钉死清单 + 待评估清单。"""
import io
import json
import os
import re
import subprocess

ROOT = r"D:\拾光剪影"
VENV = os.path.join(ROOT, ".venv312", "Scripts", "python.exe")

print("=" * 74)
print("① requirements.txt（声明版本）")
print("=" * 74)
for rel in ("requirements.txt",):
    p = os.path.join(ROOT, rel)
    if not os.path.exists(p):
        print("  ❌ %s 不存在" % rel)
        continue
    L = io.open(p, encoding="utf-8-sig", errors="replace").read().splitlines()
    print("  行数 %d" % len(L))
    for l in L:
        t = l.strip()
        if t and not t.startswith("#"):
            print("     %s" % t[:96])
print()

print("=" * 74)
print("② 实际安装版本（关键包）")
print("=" * 74)
KEYS = ["PyQt6", "PyQt6-Qt6", "PyQt6-sip", "PyQt6-WebEngine", "numpy", "moviepy",
        "opencv-python-headless", "torch", "transformers", "faster-whisper", "easyocr",
        "Pillow", "mediapipe", "librosa", "numba", "onnxruntime", "aiohttp", "dashscope",
        "anthropic", "openai", "requests", "cryptography", "imageio", "scipy",
        "pydantic", "httpx", "starlette", "fastapi"]
r = subprocess.run([VENV, "-m", "pip", "list", "--format=json"], cwd=ROOT,
                   capture_output=True, timeout=300)
try:
    installed = {d["name"].lower(): d["version"] for d in json.loads(r.stdout.decode())}
except Exception as e:
    installed = {}
    print("  pip list 失败: %s" % e)
missing = []
for k in KEYS:
    v = installed.get(k.lower())
    if v:
        print("  %-26s %s" % (k, v))
    else:
        missing.append(k)
if missing:
    print("  未安装/名称不同: %s" % ", ".join(missing))
print("  已安装包总数: %d" % len(installed))
print()

print("=" * 74)
print("③ 前端依赖（画布真源 package.json）")
print("=" * 74)
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
pkg = json.load(io.open(os.path.join(C, "package.json"), encoding="utf-8"))
print("  dependencies:")
for k, v in sorted(pkg.get("dependencies", {}).items()):
    print("     %-26s %s" % (k, v))
print("  devDependencies:")
for k, v in sorted(pkg.get("devDependencies", {}).items()):
    print("     %-26s %s" % (k, v))
print()

print("=" * 74)
print("④ 文档里的「钉死 / 待评估」清单（§2b，权威依据）")
print("=" * 74)
doc = os.path.join(ROOT, "docs", "现行技术文档.md")
b = io.open(doc, encoding="utf-8").read()
i = b.find("依赖升级纪律")
j = b.find("### 单文件规模守卫")
seg = b[i:j] if i >= 0 and j > i else ""
for l in seg.splitlines():
    if l.strip():
        print("  %s" % l[:104])
