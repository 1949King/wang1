# -*- coding: utf-8 -*-
"""分批提交：把 2026-09-12 之后 ~9 天的改动按语义固化成多个 commit。"""
import os, io, subprocess, sys

ROOT = r"D:\拾光剪影"

def git(*a, **kw):
    r = subprocess.run(["git"] + list(a), cwd=ROOT,
                       capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    ents = []
    for e in out.split("\x00"):
        if e.strip():
            ents.append((e[:2].strip(), unquote(e[3:])))
    return ents

def count():
    return len(status())

# ---------- 收集删除清单 ----------
rc, out, err = git("status", "--porcelain", "-uall", "-z")
D = []
for e in out.split("\x00"):
    if not e.strip():
        continue
    k, p = e[:2].strip(), unquote(e[3:])
    if k == "D":
        D.append(p)

VENDOR_PFX = ("openshot-qt/", "libopenshot/", "libopenshot-audio", "thirdparty/")
d_vendor = [p for p in D if p.startswith(VENDOR_PFX)]
d_proj   = [p for p in D if not p.startswith(VENDOR_PFX)]
# cpp_engine 的 openshot 包装随 vendor 一起走
for extra in ["app/core/video_processing/cpp_engine/openshot_wrapper.cpp",
              "app/core/video_processing/cpp_engine/openshot_wrapper.h"]:
    if extra in d_proj:
        d_proj.remove(extra)
        d_vendor.append(extra)

print("删除：vendor 三方 %d 项 / 项目清理 %d 项" % (len(d_vendor), len(d_proj)))
print()

BATCHES = [
    ("chore(config): 更新忽略规则、CI 工作流与工程约定",
     ["细节：.gitignore（补临时候选目录与敏感文件）、.pre-commit-config.yaml、\n"
      "ruff.toml、AGENTS.md / CONTEXT.md、.github 模板与 quality-gate、\n"
      ".cursor/rules/frozen-zones.mdc、scripts/_split_timeline_phase1.py、plugin_config.json"],
     [".gitignore", ".pre-commit-config.yaml", "ruff.toml", "AGENTS.md", "CONTEXT.md",
      ".github/PULL_REQUEST_TEMPLATE.md", ".github/workflows/quality-gate.yml",
      ".cursor/rules/frozen-zones.mdc", "scripts/_split_timeline_phase1.py",
      "plugin_config.json"]),

    ("docs: 知识库归档迁移，补充技术报告与EME.patch".replace("EME.patch", "项目记忆"),
     ["细节：docs/knowledge/* → docs/_archive/knowledge/（含 17-canvas-magnetic-invariants、\n"
      "18-codebase-health、19-canvas-design-review），根目录与 .trae 历史文档进 _archive，\n"
      "补 docs/_reports 系列报告、冷启动性能诊断报告、项目 MEMORY.md"],
     ["docs/_archive", "docs/_reports", "docs/knowledge",
      "docs/冷启动性能诊断报告.md", ".workbuddy/memory/MEMORY.md", ".trae"]),

    ("chore(vendor): 移除 openshot 第三方参考源码树",
     ["细节：openshot-qt / libopenshot / libopenshot-audio / thirdparty/openshot 整棵 references\n"
      "（早年拉进来作技术参考的上游实现，非本项目自有代码），同时移除对应 C++ 包装。"],
     d_vendor),

    ("chore(clean): 清理已下线模块、合并旧编辑器、移除根目录临时产物",
     ["细节：① 7 个旧 video_editor/* 并入 editor_module.py；② account_ops 随账号运营下线；\n"
      "③ drama_finder_plugin / 早期 asset_* / multitrack_editor 等无引用遗留模块；\n"
      "④ 根目录 history 脚本与日志。已做 AST 悬空 import 反查 = 0，无功能损失。"],
     d_proj),

    ("feat(core): Agent 能力体系与 AI 生成守护管线",
     ["细节：app/core 下 agent_* 常量/目录/循环/人格/主动建议、AI 四守护（character_anchor /\n"
      "expression_clamp / prop_consistency）、provider_pool 额度池、score_book 评分回写、\n"
      "context_budget、project_snapshot、timeline_source、log_manager 修 NameError。"],
     ["app/core"]),

    ("feat(editor): 编辑模块与 Qt6 主窗口",
     ["细节：editor_module 系列 mixin 与 UI builder、Dashboard/AI 面板、keyframe 曲线编辑器、\n"
      "导航栏图标、main_qt6 入口。"],
     ["app/modules", "app/main_qt6.py", "app/verify_c8_qt6.py"]),

    ("feat(plugins): 转场插件、测试与版本推进",
     ["细节：新增/更新 6 个转场插件、app/tests 用例更新、license 管理、app/data 配置同步，\n"
      "版本推进至 4.35.0。"],
     ["app/plugins", "app/tests", "app/data", "app/version.py", "app/__init__.py",
      "license", "tests"]),

    ("feat(canvas): shiguang-canvas 磁吸、新手模式与 Studio 页面",
     ["细节：magnetic 引擎/ bonds / reflow / levels、novice 新手卡、Stage3D/ImageStudio/\n"
      "VideoStudio、comfyToCanvas、cameraRecorder、canvasVersion 与 vitest 配置。"],
     ["vendor/shiguang-canvas"]),

    ("chore(verify): 补 _verify 校验与守卫脚本",
     ["细节：run_all_checks 总入口、scan_undefined_names（AST 作用域 NameError 扫描器）、\n"
      "各项 check_* 一致性守卫与 mjs 镜像测试。"],
     ["_verify"]),
]

start = count()
print("提交前工作区变更总数：%d" % start)
print("=" * 70)

for idx, (subject, body, paths) in enumerate(BATCHES, 1):
    if not paths:
        print("[%d] 路径清单为空，跳过：%s" % (idx, subject))
        continue
    psfile = os.path.join(ROOT, "app", "_pathspec_%d.txt" % idx)
    io.open(psfile, "w", encoding="utf-8").write("\n".join(paths) + "\n")

    rc, out, err = git("add", "-A", "--pathspec-from-file=%s" % psfile)
    if rc != 0:
        print("[%d] git add 失败：%s\n%s" % (idx, err.strip()[:400], subject))
        os.remove(psfile)
        continue
    os.remove(psfile)

    rc2, staged, _ = git("diff", "--cached", "--name-only")
    n = len([l for l in staged.splitlines() if l.strip()])
    if n == 0:
        print("[%d] 无内容变更，跳过：%s" % (idx, subject))
        continue

    msg = subject + "\n\n" + "\n".join(body) + "\n"
    mfile = os.path.join(ROOT, "app", "_msg_%d.txt" % idx)
    io.open(mfile, "w", encoding="utf-8").write(msg)
    rc3, out3, err3 = git("commit", "-F", mfile)
    os.remove(mfile)
    if rc3 != 0:
        print("[%d] ❌ commit 失败\n%s\n%s" % (idx, err3.strip()[:600], out3.strip()[:300]))
        git("reset")
        continue
    print("[%d] ✅ %-60s  暂存并落盘 %d 项" % (idx, subject[:60], n))
    print("    剩余工作区变更：%d" % count())
    print()

print("=" * 70)
print("提交后剩余：%d （提交前 %d）" % (count(), start))
