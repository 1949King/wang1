# -*- coding: utf-8 -*-
"""诊断「画布显示引擎未安装」：判断是真没装，还是装了但检测不到。"""
import io
import os
import re
import socket
import subprocess

ROOT = r"D:\拾光剪影"
PROJECT_ROOT = ROOT  # comfy_provider 的 _PROJECT_ROOT 就是仓库根

print("=" * 74)
print("① 代码会检查的 4 个位置（逐个核实）")
print("=" * 74)
env_dir = os.environ.get("SHIGUANG_COMFY_HOME")
cands = [
    ("环境变量 SHIGUANG_COMFY_HOME", env_dir),
    ("<项目>/thirdparty/ComfyUI", os.path.join(PROJECT_ROOT, "thirdparty", "ComfyUI")),
    ("<项目>/comfyui", os.path.join(PROJECT_ROOT, "comfyui")),
    ("app/core/ai/comfyui", os.path.join(ROOT, "app", "core", "ai", "comfyui")),
]
for label, d in cands:
    if not d:
        print("  %-34s （未设置）" % label)
        continue
    exists = os.path.isdir(d)
    has_main = os.path.isfile(os.path.join(d, "main.py"))
    print("  %-34s 目录存在=%-6s main.py=%-6s" % (label, exists, has_main))
print()

print("=" * 74)
print("② 磁盘上是否有 ComfyUI（全盘找 main.py + ComfyUI 特征）")
print("=" * 74)
found = []
for base in (r"D:\\", r"C:\Users"):
    if not os.path.isdir(base):
        continue
    for dp, dns, fns in os.walk(base):
        depth = dp[len(base):].count(os.sep)
        if depth > 4:
            dns[:] = []
            continue
        dns[:] = [d for d in dns if d not in (
            "Windows", "$Recycle.Bin", "System Volume Information", "node_modules",
            "__pycache__", "AppData", ".git", "Program Files", "Program Files (x86)")]
        low = dp.lower()
        if "comfy" in low:
            has_main = "main.py" in fns
            has_nodes = "nodes.py" in fns
            if has_main or has_nodes:
                found.append((dp, has_main, has_nodes))
                print("  ✅ %s  (main.py=%s nodes.py=%s)" % (dp, has_main, has_nodes))
if not found:
    print("  ❌ 全盘（D:\\ 与 C:\\Users，深度≤4）未发现 ComfyUI 安装")
print()

print("=" * 74)
print("③ 引擎是否正在运行（默认端口 8188）")
print("=" * 74)
for port in (8188, 18765, 3011):
    s = socket.socket()
    s.settimeout(0.6)
    try:
        s.connect(("127.0.0.1", port))
        print("  %-6d ✅ 有服务在监听" % port)
    except Exception:
        print("  %-6d ❌ 无监听" % port)
    finally:
        s.close()
print()

print("=" * 74)
print("④ 代码自带的安装指引（给用户看的原文）")
print("=" * 74)
b = io.open(os.path.join(ROOT, "app", "core", "ai", "comfy_provider.py"),
            encoding="utf-8-sig", errors="replace").read()
L = b.splitlines()
for i in range(436, min(len(L), 484)):
    if L[i].strip():
        print("  L%-4d %s" % (i + 1, L[i][:112]))
