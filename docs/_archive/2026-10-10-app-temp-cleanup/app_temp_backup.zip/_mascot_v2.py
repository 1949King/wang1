# -*- coding: utf-8 -*-
"""形象包 v2：从「小妹妹秘书」重构为「温柔知心大姐姐（狐耳·华丽·戴眼镜）」。

重构依据（回应用户三处批评）：
  ① 不猛：端坐不扭转、单手轻扶眼镜、另一手托光点（而非伸臂去抓）
  ② 温柔：眼神温润微垂、轻笑、狐尾盘落不翘、狐耳放松不竖立
  ③ 华丽：丝缎改良立领 + 纱披肩 + 绣纹 + 腰系带流苏 + 织锦暗纹
  ④ 背景设计：拱形窗/浅月/城市剪影 + 发光时间线光带（含节点光点）+ 左屏蓝光 + 右暖橙灯
  ⑤ 呼应「剪影」：肩头与耳缘的暖橙边缘光 ⇒ 深蓝底上形成剪影
角色更名：小拾 → **拾岚**（"岚"＝山间薄雾，温柔有层次；"小"字与"大姐姐"气质不符）
"""
import io
import json
import os
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"

ENTRIES = [
    {
        "id": "mascot-001",
        "title": "拾岚·主形象卡（狐耳·华丽·眼镜·大姐姐）",
        "category": "portrait",
        "tags": ["企划形象", "狐耳", "兽耳娘", "温柔大姐姐", "眼镜", "华丽礼服",
                 "品牌色", "剪影边缘光", "竖版"],
        "prompt": (
            "Q版半头身二次元兽耳娘角色立绘，3.5头身精致比例，成年女性，端庄优雅的温柔大姐姐气质，"
            "完全着装、非性化。"
            "角色：一对狐狸兽耳（耳内侧浅色绒毛，耳姿自然放松、一只微垂，不竖立警觉）；"
            "一条蓬松狐尾自然盘落在身侧后方（毛流柔顺有层次，尾尖由深蓝渐变为浅白蓝），不做张扬翘起。"
            "深蓝黑长卷发及腰，发丝柔顺，刘海一撮品牌蓝(#3b82f6)挑染；"
            "戴一副细金丝圆框眼镜，镜片有极淡的品牌蓝反光；"
            "青蓝色眼眸温润，眼尾微垂，平视观者，嘴角有很轻的弧度，神情温和含笑而不谄媚。"
            "衣装（华丽东方改良礼服）：深蓝丝缎改良立领长袍，斜襟配手工盘扣；"
            "肩披一层半透明深蓝纱质披肩，边缘有品牌蓝(#3b82f6)与青绿(#2dd4bf)的细密刺绣纹样；"
            "袖口三层叠褶、内衬浅色，袖缘绣银线水波纹；腰间深色系带束出柔和腰线，带垂落流苏穗子；"
            "胸前配一枚小巧的胶片/剪影形状银质胸针。材质有丝绸光泽与织锦暗纹，华丽但不暴露。"
            "动作（安静温柔）：端坐姿态，重心稳、肩线放松；右手轻轻扶着眼镜框，"
            "左手在身侧轻托起一颗悬浮的小小暖光点；头微微侧向观者，身体不扭转、不前倾。"
            "背景设计：深夜室内，身后一扇拱形窗，窗外是极简夜色城市轮廓剪影与一轮浅月；"
            "身后墙面横贯一条柔和发光的时间线光带，带上散布几个极小的节点光点；"
            "前景是工作台边缘，桌上有一杯冒热气的茶和一盏暖橙小灯。"
            "光照：左侧屏幕蓝光为主光，右侧暖橙灯为辅助光，在她肩头与狐耳边缘形成柔和的剪影边缘光。"
            "风格：精致二次元插画，赛璐璐平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
            "构图居中偏左、右侧留白。竖版3:4。"
        ),
    },
    {
        "id": "mascot-002",
        "title": "拾岚·工作表情三连（阅读／温和提醒／了然含笑）",
        "category": "consistency",
        "tags": ["企划形象", "表情包", "UI状态", "三连", "角色一致", "温度开关"],
        "prompt": (
            "同一名二次元兽耳娘（3.5头身、狐狸兽耳放松微垂、深蓝黑长卷发带品牌蓝挑染、"
            "细金丝圆框眼镜、深蓝丝缎改良立领繁绣礼服、蓬松狐尾盘落身侧）的三种工作表情三连图，"
            "浅灰渐变底，正面半身，统一打光与服装，五官比例严格一致，排成一行三格。"
            "① 阅读：微微低头看手中一页发光的纸，眉毛平直、眼神专注而平静，眼镜片上有一道浅反光；"
            "② 温和提醒：抬眼平视，眼神柔和，一手在身前提着一枚发光的小提示卡片，嘴角轻抿；"
            "③ 了然含笑：眼睛微微弯起，低下头轻推眼镜镜桥，唇边有克制的笑意，身旁浮一颗暖光点。"
            "三种都保持端庄温柔的大姐姐气质，不做夸张卖萌、不做性化处理。"
            "风格：精致二次元插画，赛璐璐平涂，干净描边，柔和光晕。横版16:9。"
        ),
    },
    {
        "id": "mascot-003",
        "title": "拾岚·动态问候（数字人 · 5s）",
        "category": "storyboard",
        "tags": ["企划形象", "动态视频", "数字人", "t2v", "5s", "横屏", "问候"],
        "prompt": (
            "二次元兽耳娘「拾岚」半身正面动态镜头：她原本低头看着工作台，随后缓缓抬眼看向镜头，"
            "眼镜片上掠过一道浅光，狐耳轻轻一动；她抬起右手温和地挥了一下打招呼，"
            "唇边浮起克制的笑意，发丝与刘海（含品牌蓝挑染）随动作轻晃，狐尾在身后小幅摆动。"
            "抬手时有一颗小小暖光点从她掌心升起并向上飘散。"
            "镜头极缓慢向前微推；背景是深夜工作室，暗蓝底(#0a0e14)，身后拱形窗外有夜色城市剪影与浅月，"
            "身后墙面横贯一条柔和发光的时间线光带；左侧屏幕蓝光、右侧暖橙灯，"
            "在她肩头与耳缘形成柔和的剪影边缘光。"
            "风格：精致二次元赛璐璐质感，柔和体积光，光尘粒子。横版16:9，时长5秒。"
            "高质量，动态从容自然，无夸张动作，无卖萌。"
        ),
    },
    {
        "id": "mascot-004",
        "title": "拾岚·画布协作场景（在节点间落笔）",
        "category": "storyboard",
        "tags": ["企划形象", "场景插画", "画布节点", "协作", "横版", "宣发"],
        "prompt": (
            "二次元兽耳娘「拾岚」端坐在悬浮的节点画布中间，正用手中的一支细笔把两张发光的节点卡片"
            "用一道柔和的光线连接起来，另一手端着茶杯；她身体端正、姿态从容，眼神专注温和，"
            "眼镜片有一道浅反光。周围漂浮着几张纸片状的节点卡，卡片上分别有图像、摄像机、音符的小图标；"
            "她身下是一条发着蓝光的细长时间线轨道，轨道上有小小的播放头与节点光点。"
            "背景为深夜暗蓝(#0a0e14)，身后拱形窗外是夜色城市剪影与浅月；"
            "左侧屏幕蓝光、右侧暖橙台灯光，在她肩头、狐耳与狐尾边缘形成柔和的剪影边缘光，光尘飘浮。"
            "风格：精致二次元场景插画，赛璐璐平涂，干净描边，柔和体积光，高质量，构图有纵深。横版16:9。"
        ),
    },
]

content = json.dumps(ENTRIES, ensure_ascii=False, indent=2) + "\n"

print("=" * 74)
print("① 写入形象包 v2（4 处）")
print("=" * 74)
targets = [
    os.path.join(C, "public", "prompts", PACK),
    os.path.join(C, "dist", "prompts", PACK),
    os.path.join(T, "public", "prompts", PACK),
    os.path.join(T, "dist", "prompts", PACK),
]
for p in targets:
    if not os.path.isdir(os.path.dirname(p)):
        print("  ⏭ %s （目录不存在）" % p)
        continue
    io.open(p, "w", encoding="utf-8").write(content)
    print("  ✅ %s  (%d 字节)" % (os.path.relpath(p, ROOT).replace("\\", "/"), os.path.getsize(p)))
print()

print("=" * 74)
print("② 更新注册名（双侧，保持字节一致）")
print("=" * 74)
OLD = '"拾光·Q版兽耳娘形象包（小拾）"'
NEW = '"拾光·狐耳形象包（拾岚）"'
TS = [os.path.join(C, "src", "promptLibrary.ts"),
      os.path.join(T, "src", "libtv", "promptLibrary.ts")]
for p in TS:
    b = io.open(p, encoding="utf-8").read()
    if NEW in b:
        print("  ⏭ %s 已是新名" % os.path.relpath(p, ROOT))
        continue
    if OLD not in b:
        print("  ⚠️ %s 找不到旧名，跳过" % os.path.relpath(p, ROOT))
        continue
    io.open(p, "w", encoding="utf-8").write(b.replace(OLD, NEW, 1))
    print("  ✅ %s 已更名" % os.path.relpath(p, ROOT).replace("\\", "/"))
print()

print("=" * 74)
print("③ 收图进项目")
print("=" * 74)
SRC = os.path.join(ROOT, "generated-images",
                   "Q版半头身二次元兽耳娘角色立绘_3_5头身精致比例_成年女性_2026-09-25T11-28-46.png")
DSTD = os.path.join(ROOT, "assets", "mascot")
os.makedirs(DSTD, exist_ok=True)
DST = os.path.join(DSTD, "shilan-主形象卡-v2-大姐姐.png")
if os.path.exists(SRC):
    shutil.copy2(SRC, DST)
    print("  ✅ %s  (%.1f KB)" % (os.path.relpath(DST, ROOT), os.path.getsize(DST) / 1024.0))
else:
    print("  ❌ 源图不存在")
print()

print("=" * 74)
print("④ 核验")
print("=" * 74)
a = io.open(TS[0], "rb").read(); b2 = io.open(TS[1], "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b2 else "❌"))
try:
    d = json.loads(content); print("  JSON 合法: ✅ 条目 %d" % len(d))
except Exception as e:
    print("  ❌ JSON 非法: %s" % e)
r = subprocess.run([sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
print("  双库校验 exit=%d  %s" % (r.returncode, r.stdout.decode("utf-8", "replace").strip().splitlines()[0]))
