# -*- coding: utf-8 -*-
"""冷启动性能归因 + 日志轮转检查（两个新机会点）。"""
import io
import os
import subprocess
import sys
import time

ROOT = r"D:\拾光剪影"
VENV = os.path.join(ROOT, ".venv312", "Scripts", "python.exe")
PY = VENV if os.path.exists(VENV) else sys.executable

print("=" * 74)
print("Ⓖ 冷启动归因：关键重导入的耗时（上次实测启动卡 54s 在环境检查）")
print("=" * 74)
MODS = ["torch", "pynvml", "cv2", "numpy", "mediapipe", "librosa",
        "PyQt6.QtWidgets", "PyQt6.QtWebEngineWidgets", "transformers"]
for m in MODS:
    t0 = time.time()
    r = subprocess.run([PY, "-c", "import %s" % m], cwd=ROOT,
                       capture_output=True, timeout=600)
    dt = time.time() - t0
    ok = r.returncode == 0
    print("  %-28s %6.2fs  %s" % (m, dt, "OK" if ok else "FAIL"))
print()
print("  说明：torch/pynvml 若在 10s 量级，即验证「启动卡在导入」的判断。")
print()

print("=" * 74)
print("Ⓗ 日志轮转：app/logs 是否在无限增长")
print("=" * 74)
LOGDIR = os.path.join(ROOT, "app", "logs")
files = []
for f in os.listdir(LOGDIR):
    p = os.path.join(LOGDIR, f)
    if os.path.isfile(p):
        files.append((os.path.getsize(p), f, os.path.getmtime(p)))
files.sort(reverse=True)
tot = sum(s for s, _, _ in files)
print("  文件数 %d · 合计 %.1f MB" % (len(files), tot / 1048576.0))
print("  最大 5 个:")
for s, f, m in files[:5]:
    print("     %8.1f MB  %-40s %s" % (s / 1048576.0, f[:40],
                                       time.strftime("%Y-%m-%d %H:%M", time.localtime(m))))
days = {}
for s, f, m in files:
    d = time.strftime("%Y-%m-%d", time.localtime(m))
    days[d] = days.get(d, 0) + 1
print("  按日期分布（最近 10 天）:")
for d in sorted(days, reverse=True)[:10]:
    print("     %s  %d 个文件" % (d, days[d]))
print()

print("=" * 74)
print("Ⓘ 日志轮转配置（有没有配 rotation）")
print("=" * 74)
for rel in ("app/core/log_manager.py", "app/core/logging_enhanced.py"):
    p = os.path.join(ROOT, *rel.split("/"))
    b = io.open(p, encoding="utf-8-sig", errors="replace").read()
    hits = []
    for kw in ("RotatingFileHandler", "TimedRotatingFileHandler", "maxBytes",
               "backupCount", "when=", "cleanup_old_logs", "deleteOldLogs"):
        if kw in b:
            hits.append(kw)
    print("  %-34s %s" % (rel, hits if hits else "❌ 无轮转相关配置"))
print()

print("=" * 74)
print("Ⓙ 打包产物是否该清（dist / build / 新建文件夹）")
print("=" * 74)
for d in ("dist", "build", "新建文件夹", "拾光剪影-发布版.zip"):
    p = os.path.join(ROOT, *d.split("/"))
    if os.path.isfile(p):
        print("  %-22s %8.1f MB  (文件)" % (d, os.path.getsize(p) / 1048576.0))
        continue
    if not os.path.isdir(p):
        continue
    n = tot = 0
    for dp, dns, fns in os.walk(p):
        for f in fns:
            try:
                tot += os.path.getsize(os.path.join(dp, f))
                n += 1
            except OSError:
                pass
    print("  %-22s %8.1f MB  (%d 文件)" % (d, tot / 1048576.0, n))
print()
print("  ⚠️ dist/ 是画布 Runtime 的静态服务源（canvas_runtime 指向 vendor 的 dist，")
print("     根 dist/ 是主程序打包产物）—— 清理前须确认不是运行依赖。")
