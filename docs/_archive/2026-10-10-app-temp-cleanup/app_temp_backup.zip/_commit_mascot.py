# -*- coding: utf-8 -*-
"""把形象图收进项目 + 提交主仓与副库 + 写记忆。"""
import io
import os
import shutil
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()

SRC_IMG = os.path.join(ROOT, "generated-images",
                       "Q版二次元兽耳娘角色立绘_2_5头身的大头小身比例_成年女性_2026-09-25T11-16-57.png")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    name = git("config", "user.name")[1].strip() or "1949King"
    mail = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + name, "-c", "user.email=" + mail, *a, cwd=T)


print("=" * 74)
print("① 形象图收进项目")
print("=" * 74)
DST_DIR = os.path.join(ROOT, "assets", "mascot")
os.makedirs(DST_DIR, exist_ok=True)
DST = os.path.join(DST_DIR, "xiaoshi-主形象卡.png")
if os.path.exists(SRC_IMG):
    shutil.copy2(SRC_IMG, DST)
    print("  ✅ %s  (%.1f KB)" % (os.path.relpath(DST, ROOT), os.path.getsize(DST) / 1024.0))
else:
    print("  ❌ 源图不存在: %s" % SRC_IMG)
print()

print("=" * 74)
print("② 主仓待提交（画布真源侧）")
print("=" * 74)
rc, out, _ = git("-c", "core.quotePath=false", "status", "--porcelain",
                 "-uall", "--", "vendor/shiguang-canvas", "assets/mascot")
for l in [x for x in out.splitlines() if x.strip()]:
    print("   %s" % l[:104])
print()

print("=" * 74)
print("③ 提交主仓")
print("=" * 74)
msg = """feat(canvas): 新增「拾光·Q版兽耳娘形象包（小拾）」+ 主形象图

角色「小拾」—— 拾光的「拾」，也是「拾起」的动作（点题她拾起光点）。

设计依据（全部取自项目实测，非凭空）：
· 品牌蓝 #3b82f6（画布 --accent）· 青色 #2dd4bf · 深夜底 #0a0e14 / #1c2638
· Agent 定位「知心秘书」⇒ 安静专业、不夸张卖萌、非性化
· 功能元素入画：时间线轨道条 · 画布节点卡 · 剪辑耳机 · 胶片徽章
· 点题动作：手"拾起"一束悬浮光点；冷暖对比（屏幕蓝光 vs 暖橙台灯）

产出：
· vendor/shiguang-canvas/public/prompts/shiguang-mascot.json（4 条）
  mascot-001 主形象卡（Q版兽耳娘，竖版 3:4）
  mascot-002 工作表情三连（专注/思考/温和提醒）— 呼应「温度开关」lite/full
  mascot-003 动态问候（t2b 5s，数字人用）
  mascot-004 画布协作场景（节点间指点，宣发用）
· 注册进 promptLibrary.ts 的 DEFAULT_PROMPT_SOURCES（shiguang-mascot-pack）
· assets/mascot/xiaoshi-主形象卡.png（已生成的主形象图）

双库同步：promptLibrary.ts 双侧字节一致；双库校验仍 分叉 0 / 缺失 7。

WARNING: 仅本地提交，未 push。"""
ps = os.path.join(TD, "_ps9.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "vendor/shiguang-canvas/src/promptLibrary.ts\n"
    "assets/mascot\n")
git("add", "-A", "--pathspec-from-file=" + ps)
rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
print("  暂存: %s" % [l for l in out.splitlines() if l.strip()])
mf = os.path.join(TD, "_msg9.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("④ 提交副库（libtv + public/prompts）")
print("=" * 74)
rc, out, _ = gt("status", "--porcelain", "--", "src/libtv", "public/prompts")
for l in [x for x in out.splitlines() if x.strip()][:10]:
    print("   %s" % l[:100])
gt("add", "-A", "--", "src/libtv/promptLibrary.ts", "public/prompts/shiguang-mascot.json")
msg2 = """feat(libtv): 同步「拾光·Q版兽耳娘形象包（小拾）」注册与提示词包

与主库 vendor/shiguang-canvas 保持一致（promptLibrary.ts 字节一致）：
· src/libtv/promptLibrary.ts 注册 shiguang-mascot-pack
· public/prompts/shiguang-mascot.json（4 条）

WARNING: origin 为第三方仓库，请勿 push。"""
mf2 = os.path.join(T, ".git", "_M2.txt")
io.open(mf2, "w", encoding="utf-8").write(msg2)
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

print("=" * 74)
print("⑤ 写记忆")
print("=" * 74)
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")
NOTE = """
## 「小拾」Q版兽耳娘企划形象（01:15 - 01:55）

用户：「帮我给项目做一个 Q 版兽耳娘的二次元虚拟形象的提示词跟图片，
要贴合项目气质特色和功能使用的一个情况。」

### 角色设定：小拾
名字取自「拾光」的「拾」，同时是「拾起」的动作 —— 点题她**手拾起一束光点**。

### 设计依据（全部实测，非凭空）
| 依据 | 来源 |
|---|---|
| 品牌蓝 **#3b82f6**（画布 `--accent`）· 青色 #2dd4bf · 深夜底 #0a0e14 / #1c2638 | `styles.css` CSS 变量 + `theme_manager.py` 实测色值 |
| 「安静专业、不夸张卖萌、非性化」 | Agent 定位「知心秘书」（`agent_persona.py`：语气可暖，但不说假拟人话） |
| 功能元素入画 | 时间线轨道条 · 画布节点卡 · 剪辑耳机 · 胶片徽章 |
| 冷暖对比 | 屏幕蓝光 vs 暖橙台灯（呼应「温度开关」） |

**核心气质**：「拾光剪影」= 在深夜蓝里拾取光 ⇒ 暗蓝底 + 屏幕蓝光 + 她指间的光点。

### 产出
1. **图片**：`assets/mascot/xiaoshi-主形象卡.png`（1024×1536 竖版 3:4，已亲眼核验：狐耳+蓬松狐尾、
   深蓝黑发带品牌蓝挑染、青蓝大眼、深色工装外套配青色滚边、颈挂耳机、拾光点动作、
   悬浮时间线轨道与节点卡、暖橙台灯 —— 设计意图基本全落地）
2. **提示词包**：`vendor/shiguang-canvas/public/prompts/shiguang-mascot.json`（4 条）
   - mascot-001 主形象卡 · mascot-002 工作表情三连（**呼应温度开关 lite/full**）·
     mascot-003 动态问候（t2v 5s，数字人）· mascot-004 画布协作场景（宣发）
3. **注册**：`promptLibrary.ts` 的 `DEFAULT_PROMPT_SOURCES` 加 `shiguang-mascot-pack`
   ⇒ 应用内「提示词库」可见可用
4. 写入 4 处（主库/副库 × public/dist），双侧 `promptLibrary.ts` **字节一致**，
   **双库校验仍 分叉 0**（我同步做了，没制造新漂移）

### 顺带验证了一条纪律
改画布真源 ⇒ **必须同步副库**，否则双库守卫立刻报新分叉。
这次同步做完整（含 dist 与 public），验证了「双宿主双份维护成本」是真实的（§2f P1 项）。

### 成本
图片生成消耗模型额度（单张约 5-10 credits）。已向用户说明。
"""
if os.path.exists(MEM):
    b = io.open(MEM, encoding="utf-8").read()
else:
    b = "# 2026-09-26 工作记录\n"
if "小拾" in b:
    print("  已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  已写入 -> %d bytes" % os.path.getsize(MEM))
