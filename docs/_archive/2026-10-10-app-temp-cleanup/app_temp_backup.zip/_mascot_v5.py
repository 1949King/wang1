# -*- coding: utf-8 -*-
"""形象包 v5：修正「偏男性」问题 —— 新增身体轮廓段，并补一张女性化修正示范图。

诊断（用户指出「这几张偏男性风格」）：
  根因 = **矫正过度** —— 为去幼态，我用的是「去女性化」的手段（去曲线/去腰线/挺括肩线），
  而不是「成年女性化」的手段 ⇒ 从「幼态少女」直接跳到「中性/偏男性」。

5 个具体信号 → 修正：
  ① 剪裁轮廓  H型直筒      → X型（收腰）/ A型（垂坠展开）
  ② 腰线      3套全无      → 明确收腰（自然腰位或稍高）
  ③ 肩线      挺括垫肩感   → 柔肩/连肩/落肩
  ④ 领型/颈线 高领遮住     → 露出颈部与锁骨（端庄不开深）
  ⑤ 下装      长裤         → 裙装（及膝）
  ⑥ 色彩      全低饱和深蓝 → 深蓝为主 + 浅色/柔色块面
"""
import io
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"
PACK_PATH = os.path.join(C, "public", "prompts", PACK)

SILHOUETTE = ("【身体轮廓·关键】X型轮廓：**明确收腰，腰围可见**（腰封或收腰剪裁），"
              "腰位在自然腰或稍高；**肩线柔和不挺括**（连肩/落肩，无垫肩感）；"
              "**颈部修长、锁骨线条可见但领口不开深**。"
              "禁止直筒无腰的H型廓形、禁止挺括垫肩、禁止全深色无层次。")

print("=" * 74)
print("① 给 005/006/007 注入身体轮廓段（去偏男性）")
print("=" * 74)
data = json.load(io.open(PACK_PATH, encoding="utf-8"))
by_id = {e["id"]: e for e in data}

FIXES = {
    "mascot-005": [
        ("【衣装·现代都市知性通勤装】深蓝(#1c2638)高领细针织打底，外搭一件剪裁利落的深蓝长款羊毛风衣"
         "（肩线挺括、腰带有系带），下配同色系直筒长裤与深蓝低跟短靴；",
         "【衣装·现代都市知性通勤女装】深蓝(#1c2638)细针织打底（领型为端庄的V领，露出颈部与锁骨）；"
         "外搭一件**柔肩（连肩无垫肩）深蓝长款薄外套**，敞开穿着形成纵向线条；"
         "下配**收腰及膝A字裙**（或高腰修身直筒裙）而非长裤，腰间系一根细腰带明确收出腰线；"
         "深蓝低跟/中跟浅口船鞋；**裙摆带米白/浅蓝的纵向色块或品牌蓝细绣边**以增加明暗层次；"),
        ("胸前别一枚小小的胶片/剪影形状银质胸针。材质为针织与羊毛的柔哑质感对比，端庄不暴露。",
         "胸前别一枚小小的胶片/剪影形状银质胸针。材质为针织与**真丝/雪纺的垂坠丝滑感**，"
         "深蓝为主 + 米白浅蓝色块平衡，端庄不暴露。"),
    ],
    "mascot-006": [
        ("【衣装·现代居家舒适装】深蓝(#1c2638)宽松长款针织开衫（袖口翻折），",
         "【衣装·现代居家舒适女装】深蓝(#1c2638)长款针织开衫（袖口翻折、**肩线柔和不挺括**，"
         "不必宽松到遮蔽身形，腰线自然可见），"),
        ("颈间围着一条柔软的浅灰长围巾。",
         "颈间围着一条柔软的浅灰长围巾（**松松搭在肩上、露出颈部线条，不裹住下巴**）；"
         "内搭领型为柔和的圆领/一字领，锁骨线条可见；**整体加浅灰与米白的浅色块面**平衡深蓝，"),
    ],
    "mascot-007": [
        ("【衣装·现代都市机能创客风】深蓝(#1c2638)简约立领机能夹克",
         "【衣装·现代都市机能创客女装】深蓝(#1c2638)**柔肩收腰短款机能外套**"
         "（去掉立领改柔和翻领、去掉垫肩感、腰间有收腰抽绳或细腰带明确腰线）"),
        ("（**剪裁干净、裤子为无侧袋的简约直筒款**，明确避开野外工装、战术装备与多口袋工装裤），"
         "内搭米白高领打底，下配深蓝修身直筒机能裤与干净的白色低帮运动鞋；",
         "（**剪裁干净、无侧袋、无绑带**，明确避开野外工装、战术装备与多口袋语汇），"
         "内搭米白V领打底（露出颈部与锁骨），下配**深蓝高腰修身直筒裤 + 白色低帮鞋**"
         "（或高腰及膝机能裙 + 短靴，二者取其一），"),
        ("深蓝黑长卷发在脑后束一个低马尾，几缕碎发垂落，刘海一撮品牌蓝(#3b82f6)挑染。",
         "深蓝黑长卷发**柔和披落或半束**（不用低马尾——低马尾会偏向干练中性），"
         "几缕碎发垂落，刘海一撮品牌蓝(#3b82f6)挑染。"),
    ],
}

for pid, pairs in FIXES.items():
    e = by_id.get(pid)
    if not e:
        print("  ⚠️ %s 不存在" % pid)
        continue
    p = e["prompt"]
    hit = 0
    for old, new in pairs:
        if old in p:
            p = p.replace(old, new, 1)
            hit += 1
        else:
            print("      ⚠️ %s 未命中: %s..." % (pid, old[:34]))
    if SILHOUETTE not in p:
        p = p.replace("【角色】", SILHOUETTE + "【角色】", 1) if "【角色】" in p else SILHOUETTE + p
    e["prompt"] = p
    print("  ✅ %s 替换 %d/%d 段 + 注入轮廓段" % (pid, hit, len(pairs)))
print()

print("=" * 74)
print("② 新增 mascot-008（女性化修正示范图）")
print("=" * 74)
DEMO = {
    "id": "mascot-008",
    "title": "拾岚·现代涂装④优雅女装（女性化修正版）",
    "category": "portrait",
    "tags": ["现代涂装", "替换外观", "skin", "优雅女装", "收腰", "X型轮廓",
             "女性化修正", "成人比例", "竖版"],
    "prompt": (
        "二次元兽耳娘角色全身立绘，成年女性，优雅温柔而知性的知心大姐姐气质，完全着装、非性化。"
        "【比例·必须严格遵守】7.5头身；头宽:肩宽≈1:2.2；腰线偏高，腿长占身高约55%；躯干修长。"
        "禁止Q版、禁止短身、禁止大头。"
        + SILHOUETTE +
        "【面部·成年人脸型】鹅蛋/卵形脸，脸长:脸宽≈1.4:1；下颌线清晰、下巴略尖；"
        "眼睛细长、眼尾微上扬，眼裂宽度约占脸宽1/3（不要大圆眼），双眼皮明确，瞳色青蓝；"
        "神态温婉含笑、眼神温润。"
        "【角色】一对狐狸兽耳（耳内侧浅色绒毛，耳姿自然放松、一只微垂，不竖立警觉）；"
        "一条蓬松狐尾自然盘落在身侧后方，尾尖由深蓝渐变为浅白蓝。"
        "深蓝黑长发柔和披落（非马尾），发丝有垂坠感，刘海一撮品牌蓝(#3b82f6)挑染。"
        "戴一副细金丝圆框眼镜，镜片有极淡的品牌蓝反光。"
        "【衣装·现代都市优雅女装】深蓝(#1c2638)真丝**收腰及膝连衣裙**（掐腰 + 微A字裙摆），"
        "领型为端庄的V领/船形领，**露出颈部与锁骨线条但不开深**；"
        "外搭一件**柔肩深蓝长款薄外套**（连肩/无垫肩、敞开穿着形成纵向线条）；"
        "腰间系一根**细腰带收出腰线**，带小巧金属扣；裙摆有柔和的流动感与及膝小开衩；"
        "**色块层次：深蓝为主 + 米白/浅蓝的裙面渐变块 + 品牌蓝(#3b82f6)细绣边**；"
        "配饰：细金链项链（小颗品牌蓝晶石吊坠）、银色细表。"
        "材质为真丝与雪纺的**垂坠丝滑感**，端庄不暴露。"
        "【动作】优雅站姿，一手轻搭在腰侧、另一手在身侧托起一颗悬浮的小小暖光点；"
        "肩线放松、微含胸不挺胸，颈部线条舒展，头微微侧向观者；不插口袋、不叉腰、不扭转。"
        "【背景】深夜室内，身后一扇拱形窗，窗外是极简夜色城市轮廓剪影与一轮浅月；"
        "身后墙面横贯一条柔和发光的时间线光带，带上散布几个极小的光点；"
        "前景工作台边缘，桌上有一杯冒热气的茶与一盏暖橙小灯。"
        "光照：左侧屏幕蓝光为主光，右侧暖橙灯为辅助光，在肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。"
        "【风格】精致二次元插画，赛璐珞平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
        "构图居中、全身入画并留出上下留白。竖版3:4。"
    ),
}
if DEMO["id"] not in by_id:
    data.append(DEMO)
    print("  ✅ 已追加 mascot-008")
else:
    print("  ⏭ 已存在")
print()

content = json.dumps(data, ensure_ascii=False, indent=2) + "\n"
print("=" * 74)
print("③ 写入 4 处并收图")
print("=" * 74)
for p in [os.path.join(C, "public", "prompts", PACK), os.path.join(C, "dist", "prompts", PACK),
          os.path.join(T, "public", "prompts", PACK), os.path.join(T, "dist", "prompts", PACK)]:
    if os.path.isdir(os.path.dirname(p)):
        io.open(p, "w", encoding="utf-8").write(content)
print("  ✅ 4 处已写入（%d 条 / %d 字节）" % (len(data), len(content)))
SRC = os.path.join(ROOT, "generated-images",
                   "二次元兽耳娘角色全身立绘_成年女性_优雅温柔而知性的知心大姐_2026-09-25T11-41-44.png")
DST = os.path.join(ROOT, "assets", "mascot", "shilan-涂装04-优雅女装-女性化修正.png")
if os.path.exists(SRC):
    shutil.copy2(SRC, DST)
    print("  ✅ %s (%.1f KB)" % (os.path.basename(DST), os.path.getsize(DST) / 1024.0))
print()

print("=" * 74)
print("④ 核验")
print("=" * 74)
a = io.open(os.path.join(C, "src", "promptLibrary.ts"), "rb").read()
b = io.open(os.path.join(T, "src", "libtv", "promptLibrary.ts"), "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b else "❌"))
print("  JSON 合法: ✅ 条目 %d" % len(json.loads(content)))
for e in data:
    has = "✅" if "【身体轮廓·关键】" in e["prompt"] else "—"
    print("     %-12s 轮廓段 %s" % (e["id"], has))
r = subprocess.run([sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
print("  双库校验 exit=%d  %s" % (r.returncode,
      r.stdout.decode("utf-8", "replace").strip().splitlines()[0]))
