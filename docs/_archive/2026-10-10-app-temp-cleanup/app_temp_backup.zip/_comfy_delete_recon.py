# -*- coding: utf-8 -*-
"""删除前的尽职调查：两份 ComfyUI 的体积/模型/产出/可运行性对比。

⚠️ 目的：回答「能不能删旧的」之前，先确认
   ① 旧的那份里有没有**不可再生**的东西（模型权重、用户产出、工作流）
   ② 新的那份**到底能不能跑**（否则删了就没引擎了）
"""
import os

ROOT = r"D:\拾光剪影"
AKI = r"C:\Users\Administrator\Desktop\ComfyUI-aki-v1.7"
CMP = r"D:\_comfy_compare"
CMP_UI = os.path.join(CMP, "ComfyUI")


def dir_size(p):
    n = tot = 0
    biggest = []
    if not os.path.isdir(p):
        return 0, 0, []
    for dp, dns, fns in os.walk(p):
        for f in fns:
            fp = os.path.join(dp, f)
            try:
                s = os.path.getsize(fp)
            except OSError:
                continue
            n += 1
            tot += s
            biggest.append((s, os.path.relpath(fp, p).replace("\\", "/")))
    biggest.sort(reverse=True)
    return n, tot, biggest


print("=" * 76)
print("① 秋叶整合包（旧，0.3.40）—— 逐子目录体积")
print("=" * 76)
total_aki = 0
for e in sorted(os.listdir(AKI)):
    p = os.path.join(AKI, e)
    if os.path.isfile(p):
        s = os.path.getsize(p)
        total_aki += s
        print("  [文件] %-34s %10.1f MB" % (e, s / 1048576.0))
    elif os.path.isdir(p):
        n, tot, big = dir_size(p)
        total_aki += tot
        print("  [目录] %-34s %10.1f MB (%d 文件)" % (e, tot / 1048576.0, n))
print("  " + "-" * 62)
print("  合计: %.1f GB" % (total_aki / 1073741824.0))
print()

print("=" * 76)
print("② 秋叶包里「不可再生」的部分（模型 / 产出 / 工作流）")
print("=" * 76)
for rel in ("ComfyUI/models", "ComfyUI/output", "ComfyUI/input",
            "ComfyUI/user", "ComfyUI/custom_nodes", "ComfyUI/workflows"):
    p = os.path.join(AKI, *rel.split("/"))
    n, tot, big = dir_size(p)
    if n:
        print("  %-26s %9.1f MB (%d 文件)" % (rel, tot / 1048576.0, n))
        for s, f in big[:5]:
            print("        %8.1f MB  %s" % (s / 1048576.0, f[:72]))
print()

print("=" * 76)
print("③ 对照：_comfy_compare（新，0.35.0）")
print("=" * 76)
for e in sorted(os.listdir(CMP)):
    p = os.path.join(CMP, e)
    if os.path.isdir(p):
        n, tot, big = dir_size(p)
        print("  [目录] %-34s %10.1f MB (%d 文件)" % (e, tot / 1048576.0, n))
    else:
        print("  [文件] %-34s %10.1f MB" % (e, os.path.getsize(p) / 1048576.0))
print()
n, tot, big = dir_size(os.path.join(CMP_UI, "models"))
print("  ComfyUI/models           %9.1f MB (%d 文件)" % (tot / 1048576.0, n))
for s, f in big[:6]:
    print("        %8.1f MB  %s" % (s / 1048576.0, f[:72]))
print("  ComfyUI 有自带解释器: %s" % (os.path.isdir(os.path.join(CMP_UI, "python_embeded"))
                                    or os.path.isdir(os.path.join(CMP_UI, "venv"))
                                    or os.path.isdir(os.path.join(CMP, "python"))))
print()

print("=" * 76)
print("④ 关键：两份的 models 是否重合（删旧的会不会丢模型）")
print("=" * 76)


def model_files(base):
    out = {}
    if not os.path.isdir(base):
        return out
    for dp, dns, fns in os.walk(base):
        for f in fns:
            if f.lower().endswith((".safetensors", ".ckpt", ".pt", ".pth", ".bin", ".gguf", ".onnx")):
                fp = os.path.join(dp, f)
                rel = os.path.relpath(fp, base).replace("\\", "/")
                try:
                    out[rel] = os.path.getsize(fp)
                except OSError:
                    pass
    return out


m_aki = model_files(os.path.join(AKI, "ComfyUI", "models"))
m_cmp = model_files(os.path.join(CMP_UI, "models"))
print("  秋叶包模型文件: %d 个 / %.1f GB" % (len(m_aki), sum(m_aki.values()) / 1073741824.0))
print("  新库模型文件:   %d 个 / %.1f GB" % (len(m_cmp), sum(m_cmp.values()) / 1073741824.0))
only_aki = {k: v for k, v in m_aki.items() if k not in m_cmp}
print("  ⇒ **只在秋叶包里**的模型: %d 个 / %.1f GB" % (len(only_aki), sum(only_aki.values()) / 1073741824.0))
for k, v in sorted(only_aki.items(), key=lambda x: -x[1])[:12]:
    print("        %8.2f GB  %s" % (v / 1073741824.0, k[:76]))
