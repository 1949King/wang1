# -*- coding: utf-8 -*-
"""复核：① 画布版本三件套一致性 ② 双库缺失明细 ③ 构建自动化与守卫覆盖。"""
import io
import json
import os
import re
import subprocess

ROOT = r"D:\拾光剪影"
CAN = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")

print("=" * 74)
print("① 画布版本三件套一致性（项目铁律：canvasVersion.ts → package.json → CHANGELOG）")
print("=" * 74)
cv = os.path.join(CAN, "src", "canvasVersion.ts")
body = io.open(cv, encoding="utf-8", errors="replace").read()
m = re.search(r'CANVAS_VERSION\s*=\s*["\']([^"\']+)', body)
ts_ver = m.group(1) if m else "?"
pkg = json.load(io.open(os.path.join(CAN, "package.json"), encoding="utf-8"))
pkg_ver = pkg.get("version", "?")
code = re.search(r'CODENAME\s*=\s*["\']([^"\']+)', body)
print("  canvasVersion.ts CANVAS_VERSION = %s" % ts_ver)
print("  package.json     version        = %s" % pkg_ver)
print("  canvasVersion.ts CODENAME       = %s" % (code.group(1) if code else "?"))
print("  ⇒ 一致: %s" % ("✅" if ts_ver == pkg_ver else "❌ 不一致（项目铁律要求同步）"))
# 副库
cv2 = os.path.join(T, "src", "libtv", "canvasVersion.ts")
if os.path.exists(cv2):
    b2 = io.open(cv2, encoding="utf-8", errors="replace").read()
    m2 = re.search(r'CANVAS_VERSION\s*=\s*["\']([^"\']+)', b2)
    pk2 = json.load(io.open(os.path.join(T, "package.json"), encoding="utf-8"))
    print("  副库 libtv canvasVersion = %s / 副库 package.json = %s ⇒ %s"
          % (m2.group(1) if m2 else "?", pk2.get("version"),
             "✅" if m2 and m2.group(1) == pk2.get("version") else "❌"))
print()

print("=" * 74)
print("② 双库缺失明细（副库缺哪 7 个）")
print("=" * 74)
r = subprocess.run([os.sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
out = r.stdout.decode("utf-8", "replace")
for l in out.splitlines():
    if "缺失" in l or "分叉" in l or "已知缺失" in l:
        print("  %s" % l.strip()[:100])
print()

print("=" * 74)
print("③ 构建自动化与守卫覆盖")
print("=" * 74)
# 1) canvas_runtime 是否会自动 build
cr = io.open(os.path.join(ROOT, "app", "core", "canvas_runtime.py"),
             encoding="utf-8-sig", errors="replace").read()
print("  canvas_runtime 含自动 build: %s" % ("✅ 有（后台异步）" if "npm run build" in cr or "run_async_build" in cr or "build" in cr.lower() else "❌ 无"))
# 2) pre-commit 是否覆盖画布
pc = io.open(os.path.join(ROOT, ".pre-commit-config.yaml"), encoding="utf-8").read()
for name in ("双库一致性", "canvas-dual-repo", "shiguang-canvas"):
    print("  pre-commit 含 %-16s : %s" % (name, "✅" if name in pc else "—"))
# 3) 前端是否有 lint/typecheck/test 门禁
print("  前端门禁脚本（真源 package.json scripts）:")
for k, v in pkg.get("scripts", {}).items():
    print("     %-12s %s" % (k, v))
# 4) _verify 里有没有前端相关校验
vd = os.path.join(ROOT, "_verify")
fe = [f for f in os.listdir(vd) if f.endswith((".mjs", ".cjs"))]
print("  _verify 下的前端校验脚本: %s" % (fe if fe else "（无）"))
print()

print("=" * 74)
print("④ 画布 >2000 行文件（守卫基线中的项）")
print("=" * 74)
for base in (os.path.join(CAN, "src"),):
    rows = []
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in ("node_modules", "dist")]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css")):
                p = os.path.join(dp, f)
                n = sum(1 for _ in io.open(p, encoding="utf-8", errors="replace"))
                if n > 2000:
                    rows.append((n, os.path.relpath(p, ROOT).replace("\\", "/")))
    rows.sort(reverse=True)
    for n, p in rows:
        print("     %6d  %s" % (n, p))
