# -*- coding: utf-8 -*-
"""量化优化效果：解析启动日志的时间线，对比优化前后的关键间隔。"""
import io
import os
import re

LOG = r"D:\拾光剪影\app\temp\qt6_launch.log"
L = io.open(LOG, encoding="utf-8", errors="replace").read().splitlines()

TS = re.compile(r"^(\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2})")
events = []
for l in L:
    m = TS.match(l.strip())
    if m:
        clean = re.sub(r"\x1b\[[0-9;]*m", "", l)
        events.append((m.group(1), clean.strip()))

print("=" * 74)
print("启动时间线（按日志时间戳）")
print("=" * 74)
prev = None
for ts, line in events:
    h, mnt, s = ts[11:].split(":")
    sec = int(h) * 3600 + int(mnt) * 60 + int(s)
    gap = ""
    if prev is not None:
        d = sec - prev
        gap = "  (+%ds)" % d if d > 0 else ""
    prev = sec
    # 只显示里程碑行
    body = re.sub(r"^\S+ \S+ \[\w+\] ", "", line)
    print("  %s%s  %s" % (ts[11:], gap, body[:96]))

print()
print("=" * 74)
print("关键指标")
print("=" * 74)
if events:
    def sec(t):
        h, mnt, s = t[11:].split(":")
        return int(h) * 3600 + int(mnt) * 60 + int(s)

    t0 = sec(events[0][0])
    t_env = None
    t_after_env = None
    t_run = None
    t_ok = None
    t_canvas = None
    for ts, line in events:
        if "检查运行环境" in line and t_env is None:
            t_env = sec(ts)
        if "初始化路径" in line and t_after_env is None and t_env is not None:
            t_after_env = sec(ts)
        if "[OK] 启动完成" in line or "启动完成!" in line:
            t_ok = t_ok or sec(ts)
        if "应用启动成功" in line and t_ok is None:
            t_ok = sec(ts)
        if "canvas bridge listening" in line or "canvas static server" in line:
            t_canvas = t_canvas or sec(ts)

    print("  首个日志 → 检查运行环境 : %ss" % (t_env - t0 if t_env else "?"))
    if t_env and t_after_env:
        print("  ★ 环境检查耗时          : %ss   <-- 优化前实测 54s" % (t_after_env - t_env))
    if t_env and t_ok:
        print("  检查环境 → 启动完成     : %ss" % (t_ok - t_env))
    print("  首个日志 → 应用启动成功 : %ss   <-- 优化前实测约 55s" % (t_ok - t0 if t_ok else "?"))
    if t_canvas:
        print("  首个日志 → 画布就绪     : %ss" % (t_canvas - t0))
print()
print("  ⚠️ 注意：本次是**热态**（我刚跑过一轮启动，磁盘缓存已暖）。")
print("     冷态对比需另测；但环境检查的下降主要来自「不再真导入 16 个包」。")
