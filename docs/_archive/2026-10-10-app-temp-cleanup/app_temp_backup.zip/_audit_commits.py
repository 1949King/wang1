# -*- coding: utf-8 -*-
"""精确复核：每个提交到底纳入了哪些文件（--numstat 不截断路径）。"""
import os, subprocess, collections
ROOT = r"D:\拾光剪影"

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return r.stdout.decode("utf-8", "replace")

BAD_PAT = ("node_modules", ".env", "credentials", "id_rsa", ".pem")
BIG_LIMIT = 1024 * 1024

log = git("log", "--format=%h|%s", "d67f80a..HEAD").strip().splitlines()
allpaths = []
for line in log:
    if not line.strip():
        continue
    h, subj = line.split("|", 1)
    out = git("-c", "core.quotePath=false", "show", "--numstat", "--format=", h)
    add = dele = 0
    c = collections.Counter()
    bigs, bads = [], []
    paths = []
    for l in out.splitlines():
        parts = l.split("\t")
        if len(parts) < 3:
            continue
        a, d, p = parts[0], parts[1], "\t".join(parts[2:])
        if a != "-":
            add += int(a)
        if d != "-":
            dele += int(d)
        paths.append(p)
        allpaths.append(p)
        c[p.split("/")[0] if "/" in p else "(root)"] += 1
        if any(b in p for b in BAD_PAT):
            bads.append(p)
        # 二进制文件在 numstat 里表现为 "-\t-\t路径"
        if a == "-" and d == "-":
            bigs.append(p)
    print("%s  %s" % (h, subj[:54]))
    print("     文件 %d · 增 %d 行 / 删 %d 行" % (len(paths), add, dele))
    print("     顶层: %s" % dict(c.most_common(6)))
    if bads:
        print("     ⚠️ 含 node_modules/凭据类路径 %d 个: %s" % (len(bads), bads[:3]))
    if bigs:
        print("     二进制/无 diff 项 %d 个: %s" % (len(bigs), bigs[:3]))
    print()

print("=" * 70)
print("全批合计文件条目（含重复计数）: %d" % len(allpaths))
bad_all = [p for p in allpaths if any(b in p for b in BAD_PAT)]
print("含 node_modules / 凭据模式: %d 个" % len(bad_all))
for p in bad_all[:10]:
    print("   ", p)
