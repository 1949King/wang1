# -*- coding: utf-8 -*-
"""写记忆：ComfyUI 两份实情 + 删除决策建议。"""
import io
import os

MEM = r"D:\拾光剪影\.workbuddy\memory\2026-09-26.md"
NOTE = """
## ComfyUI 两份的实情 + 删除决策尽职调查（01:57 - 02:15）

用户问：「要不要把那个 ComfyUI 的安装包给删掉？还有哪些需要考虑的？」

### 尽职调查结论（实测）

| 项 | 秋叶包（旧 0.3.40） | `D:\\_comfy_compare`（新 0.35.0） |
|---|---|---|
| 总体积 | **14.4 GB** | ~260 MB |
| 其中 rar 安装包 | **4.16 GB**（`ComfyUI-aki-v1.7.rar`） | — |
| 其中 python | **8.59 GB / 46,077 文件** | ❌ **没有解释器** |
| models | 1 个（`sams/sam_vit_b_01ec64.pth` 0.34 GB） | **0 个** |
| custom_nodes | **931 MB / 4023 文件**（efficiency-nodes / animatediff / controlnet_aux / was-suite / UltimateSDUpscale…） | 仅 2 个官方示例 |
| 能否拉起 | ✅ 能 | ❌ **不能**（无解释器 + 无模型 + 无插件） |

### 🔴 关键结论：新库只是"一份更新的源码"，不是"一个能用的引擎"

**⇒ 现在删整个秋叶包 = 删掉唯一能用的 ComfyUI 引擎**（它携带唯一可用解释器 + 唯一模型 + 插件生态）。
**⇒ 可以安全删的只有 `ComfyUI-aki-v1.7.rar`（4.16 GB）** —— 安装源，内容已全部解压。
但建议**先重命名为 `.rar.bak` 观察几天**（万一解压不完整，rar 是唯一回退源）。

### 正确的动作序列（顺序不能反）
1. **先让新库能跑**：给 0.35.0 建**独立 venv**（不要复用项目 .venv312，会污染）+ 装 requirements
2. **共享模型**：用 ComfyUI 官方的 `extra_model_paths.yaml` 指向秋叶包的 `models/`（避免复制，且以后模型只维护一份）
3. **再改选择策略**：`_find_engine_dir()` 改成「先筛能拉起 → 再选版本最高」
4. **最后才考虑删旧库**（新库稳定运行一段时间后）

### ⚠️ 别误删：`_comfy_compare` 下有三个**独立项目**，不是 ComfyUI 的一部分
`libtv-skills`（画布相关 skills 仓库，含 .git）· `open-canvas`（含 .git）· `ComfyUI_frontend`

### 其它可清理项
`.cache` 127 MB（可再生的 Manager 缓存）· `.launcher` 75 MB · `git` 67 MB（绘世启动器组件）
⇒ 若继续用绘世启动器就留着；改用命令行启动可清，合计约 269 MB。
`ComfyUI/output` 是空的、`input/` 只有 example.png ⇒ **没有用户产出会被删掉**。

### 磁盘空间
C: 545 GB 总 / **308.4 GB 可用** · D: 954 GB 总 / **478.0 GB 可用** ⇒ 空间充足，
但新库建 venv 后总占用会再涨 **6–8 GB**（ComfyUI 全量依赖含 torch+cu124）。

### 我未动手
桌面属个人目录（高危区），4 GB 级删除必须用户亲自确认 ⇒ **只给方案与清单，不代删。**
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "ComfyUI 两份的实情" in b:
    print("已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("已写入 -> %d bytes" % os.path.getsize(MEM))
