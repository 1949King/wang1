# -*- coding: utf-8 -*-
"""侦察：冻结区边界 + 粘合层现状。"""
import os
import io
import json
import re

ROOT = r"D:\拾光剪影"
FZ = os.path.join(ROOT, "docs", "knowledge", "frozen_zones.json")

print("=" * 74)
print("① 冻结区清单（哪些文件/符号被锁 —— 我禁止改的就是这些）")
print("=" * 74)
z = json.load(io.open(FZ, encoding="utf-8"))
print("version=%s  updated=%s" % (z.get("version"), z.get("updated")))
print("policy=%s" % json.dumps(z.get("policy", {}), ensure_ascii=False)[:200])
print()

all_files = []
all_syms = []
all_marks = []
for zone in z.get("zones", []):
    zid = zone.get("id")
    print("── [%s] %s" % (zid, zone.get("reason", "")[:70]))
    f = zone.get("files", [])
    s = zone.get("symbols", [])
    m = zone.get("markers", [])
    print("   files  : %d" % len(f))
    for x in f:
        p = x if isinstance(x, str) else x.get("path", "")
        print("       %s" % p)
        all_files.append(p)
    if s:
        print("   symbols: %d" % len(s))
        for x in s[:8]:
            print("       %s" % json.dumps(x, ensure_ascii=False)[:110])
            all_syms.append(x)
        if len(s) > 8:
            print("       ... 另 %d 个" % (len(s) - 8))
    if m:
        print("   markers: %d" % len(m))
        for x in m[:5]:
            print("       %s" % json.dumps(x, ensure_ascii=False)[:110])
            all_marks.append(x)
    print()

print("=" * 74)
print("② 汇总：被整文件锁定的路径（改动禁区）")
print("=" * 74)
for p in sorted(set(all_files)):
    print("   %s" % p)
print()
print("   合计整文件锁: %d 个" % len(set(all_files)))
print("   符号级锁    : %d 个" % len(all_syms))
print("   标记块锁    : %d 个" % len(all_marks))
print()

print("=" * 74)
print("③ 粘合层候选文件是否存在 / 是否在冻结区")
print("=" * 74)
GLUE = [
    "app/core/editor_canvas_link.py",
    "app/core/canvas_bridge.py",
    "app/core/canvas_server.py",
    "app/core/canvas_gen_jobs.py",
    "app/core/canvas_aigc.py",
    "app/core/project_snapshot.py",
    "app/core/ai/guard_base.py",
]
for rel in GLUE:
    p = os.path.join(ROOT, *rel.split("/"))
    exists = os.path.exists(p)
    n = -1
    if exists:
        n = sum(1 for _ in io.open(p, encoding="utf-8-sig", errors="replace"))
    frozen = rel in set(all_files)
    print("  %-42s 存在=%s 行数=%s 冻结=%s"
          % (rel, exists, n if n >= 0 else "-", "⛔ 是" if frozen else "否"))
print()

print("=" * 74)
print("④ 冻结区覆盖的 app/ 与 vendor/ 路径（写代码前必查）")
print("=" * 74)
for p in sorted(set(all_files)):
    if p.startswith(("app/", "vendor/")):
        print("   ⛔ %s" % p)
