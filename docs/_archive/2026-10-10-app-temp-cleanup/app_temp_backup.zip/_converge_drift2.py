# -*- coding: utf-8 -*-
"""漂移收敛 第二轮：补齐「仅主库有」的文件。

为什么必须补：第一轮同步后 store.ts 出现
    error TS2307: Cannot find module './comfyToCanvas'
因为 comfyToCanvas.ts 属"仅主库有"，未同步 —— 半收敛状态会留下断引用。

同样带闭环：同步后测 tsc，变差即回滚。
"""
import hashlib
import io
import os
import re
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
MAIN = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
SUB = os.path.join(ROOT, "vendor", "AI-Canvas-tauri", "src", "libtv")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
NODE = r"C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3\node.exe"
SKIP = {"node_modules", "dist", "__pycache__"}
APPLY = "--apply" in sys.argv


def files_under(base):
    out = {}
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css", ".json")):
                rel = os.path.relpath(os.path.join(dp, f), base).replace("\\", "/")
                out[rel] = os.path.join(dp, f)
    return out


def run_tsc():
    b = os.path.join(T, "node_modules", "typescript", "bin", "tsc")
    if not os.path.exists(b):
        b = os.path.join(T, "node_modules", "typescript", "bin", "tsc.js")
    r = subprocess.run([NODE, b, "-b"], cwd=T, capture_output=True, timeout=1200)
    out = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")
    return len(re.findall(r"error TS\d+", out)), out


def gt(*a, **kw):
    """调副库 git（自动注入主仓身份，避免 Author identity unknown）。"""
    name = subprocess.run(["git", "config", "user.name"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "1949King"
    mail = subprocess.run(["git", "config", "user.email"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "x@y.z"
    r = subprocess.run(["git", "-c", "user.name=" + name, "-c", "user.email=" + mail] + list(a),
                       cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


fa, fb = files_under(MAIN), files_under(SUB)
missing = [k for k in sorted(fa) if k not in fb]
print("仅主库有（副库缺失）: %d 个" % len(missing))
for k in missing:
    n = io.open(fa[k], encoding="utf-8", errors="replace").read().count("\n")
    print("   %5d 行  %s" % (n, k))
print()

if not APPLY:
    print("DRY-RUN：加 --apply 补齐（带 tsc 闭环）")
    sys.exit(0)

n0, _ = run_tsc()
print("tsc 基线: %s" % n0)
print()

copied = []
for k in missing:
    dst = os.path.join(SUB, *k.split("/"))
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    shutil.copy2(fa[k], dst)
    copied.append(k)
print("已补齐 %d 个文件" % len(copied))
print()

n1, out1 = run_tsc()
print("tsc 复测: %s（基线 %s）" % (n1, n0))
for l in out1.splitlines()[-6:]:
    print("   %s" % l[:110])
print()

if n1 > n0:
    print("❌ 变差，回滚")
    for k in copied:
        gt("checkout", "--", "src/libtv/" + k)
        p = os.path.join(SUB, *k.split("/"))
        # 新增文件不在 HEAD，checkout 无效 → 直接删
        if os.path.exists(p) and gt("ls-files", "--error-unmatch", "src/libtv/" + k)[2]:
            os.remove(p)
    print("   复测: %s" % run_tsc()[0])
    sys.exit(1)

print("✅ 未变差，提交")
gt("add", "-A", "--", "src/libtv")
msg = ("chore(sync): 补齐主库有而副库缺的画布文件，完成双库对齐\n\n"
       "第一轮同步后 store.ts 出现 TS2307（找不到 ./comfyToCanvas）——\n"
       "该文件属「仅主库有」，半收敛会留断引用。本轮补齐 %d 个文件。\n\n"
       "验收：tsc 错误数 %s → %s（未增加）。\n\n"
       "WARNING: 本仓库 origin 为第三方仓库，请勿 push。" % (len(copied), n0, n1))
mf = os.path.join(T, ".git", "_MSG.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = gt("commit", "-F", mf)
os.remove(mf)
print("   commit exit=%d %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()
print("   提交历史:")
for l in gt("log", "--oneline", "-4")[1].splitlines():
    print("      %s" % l)
