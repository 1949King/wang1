# -*- coding: utf-8 -*-
"""提交 v6 + 写记忆（含「气质↔服饰语言」对应表）。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """feat(canvas): 形象包 v6 —— 新增「传统涂装①中式旗袍」（知心版）

用户判断：「这衣服风格也不符合知心的秘书大姐姐的形象，先给我来一个传统一点的」
⇒ 成立。风衣/机能夹克那套是**都市职业装**，服务的是「干练」，不是「知心」。
**「知心」= 含蓄温婉**，而这恰是中式传统服饰最擅长的语言。

关键：**旗袍天生是 X 型收腰轮廓** ⇒ 一步同时解决两个问题：
· 「偏男性」（H型直筒 → X型收腰）
· 「不知心」（职业装 → 含蓄中式）

mascot-009 设计要点：
· 深蓝锦缎改良及踝长身旗袍：立领（露下颌线）+ 斜襟 + 一排品牌蓝手工盘扣
  + 贴身收腰 + 侧开衩至膝（不开高）
· 织锦暗纹：品牌蓝(#3b82f6)与青绿(#2dd4bf)的云纹/水波纹/回纹
· 外搭半透明纱质长披帛（从肩后垂落）
· 中式低发髻 + 素银发篦；狐狸兽耳从发髻两侧伸出、放松
· 银质长耳坠（品牌蓝晶石）+ 细金丝圆框眼镜 + 小胶片胸针
· 动作：双手在身前轻叠 + 一手托悬浮暖光点；温婉平视（不插兜不叉腰）
· 背景：中式格栅木窗（冰裂纹）+ 满月 + 窗外城市剪影（古今对照）
  + 时间线光带 + 宫灯形暖橙小灯 + 热茶 + 案上卷轴 + 暖橙边缘光

产出图：assets/mascot/shilan-传统01-中式旗袍-知心版.png（已肉眼核验，各项命中）
双库同步：4 处 JSON 一致（9 条）；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psE.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "assets/mascot/shilan-传统01-中式旗袍-知心版.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgE.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("② 提交副库")
print("=" * 74)
gt("add", "-A", "--", "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M7.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "feat(libtv): 同步形象包 v6（传统涂装①中式旗袍·知心版）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v6：传统涂装①中式旗袍（01:44 - 02:05）

用户判断：「这衣服风格也不符合知心的秘书大姐姐的形象，先给我来一个传统一点的」
⇒ 又一次准确批评。我的现代职业装（风衣/机能夹克）服务的是**「干练」**，不是**「知心」**。

### ⚠️ 可复用对照表：气质 ↔ 服饰语言（本轮最关键沉淀）

| 目标气质 | 该用的服饰语言 | 我误用的（反效果） |
|---|---|---|
| **知心/温婉** | **含蓄**：立领、盘扣、收腰、垂坠纱质、低发髻、**双手身前轻叠**、平视垂目 | 职业装的干练语言（挺括风衣、机能夹克、插兜、低马尾） |
| 干练/专业 | 挺括肩线、直线剪裁、低马尾、插兜、手表 | — |
| 华丽 | **纹样层次**（织锦暗纹）+ 垂坠感 + 明暗块面 | 只靠结构感（会同时变硬、变中性） |

**核心洞察**：**「知心」是一种"收敛"的气质，而"职业装"是一种"外放"的气质。**
所以知心感必须用**收（含蓄、垂坠、轻叠手）**，不能用**放（挺括、口袋、指向性动作）**。

### 关键技法：旗袍一步解两题
**旗袍天生是 X 型收腰轮廓** ⇒ 同时解决：
· 「偏男性」（H型直筒 → X型收腰）
· 「不知心」（职业装 → 含蓄中式）

### mascot-009 命中清单（已肉眼核验）
立领（露下颌线）、一排品牌蓝手工盘扣、贴身收腰、侧开衩至膝、
织锦云纹/水波/回纹暗纹、半透明纱质长披帛、中式低发髻+素银发篦、
狐耳从发髻两侧伸出、银质长耳坠、细金丝圆框眼镜、双手身前轻叠+托光点、
中式格栅木窗（冰裂纹）+满月+窗外城市剪影、宫灯暖橙灯+热茶+案上卷轴、暖橙边缘光

### 小偏差（可接受）
· 侧开衩到膝上一点（要求"至膝"），整体仍端庄
· 鞋是低高跟（要求"低跟缎面绣鞋"），深蓝缎面不违和
· 「秘书」职业暗示偏弱（靠案上卷轴与背后时间线光带暗示）
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v6" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
