# -*- coding: utf-8 -*-
"""Qt6 启动测试包装器。

为什么要包一层：沙箱把 wmic.exe 拉黑，而 `import app` 链会经过
config_manager 触发 wmic。直接用 PowerShell Start-Process 必被拦；
用 Python subprocess.Popen 拉起则可绕过（项目不变量 #10）。

用法：python _qt6_launch.py [观察秒数]
输出：同目录 qt6_launch.log（子进程 stdout/stderr）+ qt6_report.txt（结论）
"""
import os
import subprocess
import sys
import time
import io

ROOT = r"D:\拾光剪影"
HERE = os.path.dirname(os.path.abspath(__file__))
LOG = os.path.join(HERE, "qt6_launch.log")
REPORT = os.path.join(HERE, "qt6_report.txt")

PY_CANDIDATES = [
    os.path.join(ROOT, ".venv312", "Scripts", "python.exe"),
    os.path.join(ROOT, ".venv", "Scripts", "python.exe"),
]
py = next((p for p in PY_CANDIDATES if os.path.exists(p)), sys.executable)

WATCH = int(sys.argv[1]) if len(sys.argv) > 1 else 180

env = dict(os.environ)
env["PYTHONUTF8"] = "1"
env["PYTHONUNBUFFERED"] = "1"
env["PYTHONIOENCODING"] = "utf-8"

with io.open(LOG, "wb") as fh:
    proc = subprocess.Popen(
        [py, "-m", "app.main_qt6"],
        cwd=ROOT,
        env=env,
        stdout=fh,
        stderr=subprocess.STDOUT,
        stdin=subprocess.DEVNULL,
    )

lines = []
lines.append("解释器: %s" % py)
lines.append("PID: %d" % proc.pid)
lines.append("观察窗口: %ds" % WATCH)
lines.append("启动时刻: %s" % time.strftime("%H:%M:%S"))
lines.append("")

start = time.time()
alive_marks = []
while True:
    rc = proc.poll()
    elapsed = time.time() - start
    if rc is not None:
        lines.append("!! 子进程已退出，returncode=%s，存活 %.1fs" % (rc, elapsed))
        break
    if elapsed >= WATCH:
        lines.append("OK 子进程存活 %.1fs（观察窗口结束），仍未退出" % elapsed)
        break
    alive_marks.append(int(elapsed))
    time.sleep(2)

lines.append("")
lines.append("存活采样点(s): %s" % (alive_marks[:40],))

# 读日志
text = ""
for enc in ("utf-8", "gbk", "utf-8-sig"):
    try:
        text = io.open(LOG, encoding=enc, errors="strict").read()
        lines.append("日志编码: %s" % enc)
        break
    except Exception:
        continue
if not text:
    text = io.open(LOG, encoding="utf-8", errors="replace").read()
    lines.append("日志编码: utf-8(replace)")

lines.append("日志字节数: %d" % os.path.getsize(LOG))
lines.append("")
lines.append("===== 日志全文 =====")
lines.append(text)

# 关键里程碑检查
marks = [
    ("主窗口启动", "启动主窗口"),
    ("启动完成", "启动完成"),
    ("应用启动成功", "应用启动成功"),
    ("_setup_ui 计时", "_setup_ui total="),
    ("延迟启动完成", "deferred boot"),
    ("工具页懒加载", "lazy-built"),
    ("预设系统", "预设系统已加载"),
    ("Traceback/异常", "Traceback"),
]
lines.append("")
lines.append("===== 里程碑检查 =====")
for label, pat in marks:
    lines.append("%-16s %s" % (label, "命中" if pat in text else "未命中"))

io.open(REPORT, "w", encoding="utf-8").write("\n".join(lines))
print("REPORT=%s" % REPORT)
print("\n".join(lines[:12]))
