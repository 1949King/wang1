# -*- coding: utf-8 -*-
"""项目体检：为技术债分析采集硬数据。"""
import os
import io
import re
import subprocess
import collections

ROOT = r"D:\拾光剪影"
SKIP = {".git", ".venv312", "node_modules", "__pycache__", "dist", "build",
        ".wheelhouse", ".vite", ".pytest_cache", "openshot-qt", "libopenshot"}


def walk(exts, extra_skip=()):
    out = []
    sk = set(SKIP) | set(extra_skip)
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if d not in sk]
        rel = os.path.relpath(dp, ROOT).replace("\\", "/")
        for f in fns:
            if f.endswith(exts):
                out.append(rel + "/" + f if rel != "." else f)
    return out


def count_lines(path):
    try:
        return sum(1 for _ in io.open(os.path.join(ROOT, *path.split("/")),
                                      encoding="utf-8-sig", errors="replace"))
    except Exception:
        return -1


print("=" * 72)
print("① 总体规模")
print("=" * 72)
py = walk((".py",))
ts = walk((".ts", ".tsx"))
py = [p for p in py if "_archive" not in p]
ts = [p for p in ts if "/dist/" not in p and p.split("/")[0] != "dist"]
py_l = sum(max(0, count_lines(p)) for p in py)
ts_l = sum(max(0, count_lines(p)) for p in ts)
print("  Python : %5d 文件 / %8d 行" % (len(py), py_l))
print("  TS/TSX : %5d 文件 / %8d 行" % (len(ts), ts_l))
print("  合计   : %5d 文件 / %8d 行" % (len(py) + len(ts), py_l + ts_l))
print()

print("=" * 72)
print("② 分层规模（行数）")
print("=" * 72)
areas = [
    ("app/core", "app/core"),
    ("app/modules", "app/modules"),
    ("app/plugins", "app/plugins"),
    ("app/skills+utils+ui+tests", None),
    ("vendor/shiguang-canvas", "vendor/shiguang-canvas"),
    ("scripts", "scripts"),
    ("_verify", "_verify"),
    ("tests", "tests"),
]
pick = []
for label, pref in areas:
    if pref:
        sub = [p for p in py + ts if p.startswith(pref + "/")]
    else:
        sub = [p for p in py + ts if p.startswith(("app/skills/", "app/utils/",
                                                   "app/ui/", "app/tests/"))]
    if not sub:
        continue
    tot = 0
    for p in sub:
        tot += max(0, count_lines(p))
    pick.append((label, len(sub), tot))
    print("  %-30s %4d 文件 / %7d 行" % (label, len(sub), tot))
print()

print("=" * 72)
print("③ 巨型文件 TOP 25（>1200 行）")
print("=" * 72)
sizes = []
for p in py + ts:
    n = count_lines(p)
    if n > 1200:
        sizes.append((n, p))
sizes.sort(reverse=True)
print("  >1200 行的文件共 %d 个，占全部行数的 %.1f%%" % (
    len(sizes), 100.0 * sum(s for s, _ in sizes) / max(1, py_l + ts_l)))
print()
for n, p in sizes[:25]:
    print("  %6d  %s" % (n, p))
print()

print("=" * 72)
print("④ 测试资产")
print("=" * 72)
tests = [p for p in py if os.path.basename(p).startswith("test_") or "/tests/" in p]
tcount = 0
for p in tests:
    try:
        body = io.open(os.path.join(ROOT, *p.split("/")), encoding="utf-8-sig",
                       errors="replace").read()
        tcount += len(re.findall(r"^\s*def test_", body, re.M))
    except Exception:
        pass
print("  测试相关 .py : %d 个" % len(tests))
print("  def test_ 总数: %d" % tcount)
print("  测试行数占比 : %.1f%%" % (
    100.0 * sum(max(0, count_lines(p)) for p in tests) / max(1, py_l)))
fe = len([p for p in ts if p.endswith(".test.ts") or p.endswith(".test.tsx")])
print("  前端测试文件 : %d 个" % fe)
print()

print("=" * 72)
print("⑤ 债务气味扫描")
print("=" * 72)
pats = {
    "TODO/FIXME/HACK/XXX": r"\b(TODO|FIXME|HACK|XXX)\b",
    "裸 except:": r"except\s*:",
    "except …: pass（静默）": r"except[^:\n]*:\s*\n\s*pass\b",
    "print( 调用（应走 logger）": r"^\s*print\(",
    "hasattr/getattr 动态访问": r"\b(hasattr|getattr)\(",
    "内联 setStyleSheet": r"setStyleSheet\(",
}
for label, pat in pats.items():
    n = 0
    files = 0
    rx = re.compile(pat, re.M)
    for p in py:
        try:
            body = io.open(os.path.join(ROOT, *p.split("/")), encoding="utf-8-sig",
                           errors="replace").read()
        except Exception:
            continue
        m = rx.findall(body)
        if m:
            n += len(m)
            files += 1
    print("  %-28s %6d 处 / %d 个文件" % (label, n, files))
print()

print("=" * 72)
print("⑥ 未接线模块复查（写了但生产无调用）")
print("=" * 72)
cands = [
    ("ai/module_scheduler.py", "get_scheduler"),
    ("ai/engine_api.py", "get_engine_api"),
    ("ai/simulator.py", "Simulator("),
    ("ai/fusion.py", "fuse_text"),
    ("ai/global_price.py", "auction("),
]
def git_grep(needle):
    r = subprocess.run(["git", "grep", "-n", "-F", needle, "--", "app", "_verify"],
                       cwd=ROOT, capture_output=True)
    out = r.stdout.decode("utf-8", "replace")
    prod = [l for l in out.splitlines() if "/ai/" in l and "_verify" not in l]
    ver = [l for l in out.splitlines() if "_verify" in l]
    return prod, ver

for f, sym in cands:
    prod, ver = git_grep(sym)
    defined = [l for l in prod if f.split("/")[-1] in l]
    users = [l for l in prod if f.split("/")[-1] not in l]
    print("  %-28s 定义行 %d · 生产引用 %d · _verify 引用 %d"
          % (f, len(defined), len(users), len(ver)))
print()

print("=" * 72)
print("⑦ 命名冲突与悬空引用")
print("=" * 72)
cls = collections.defaultdict(list)
for p in py:
    try:
        body = io.open(os.path.join(ROOT, *p.split("/")), encoding="utf-8-sig",
                       errors="replace").read()
    except Exception:
        continue
    for m in re.finditer(r"^class\s+(\w+)", body, re.M):
        cls[m.group(1)].append(p)
dups = {k: v for k, v in cls.items() if len(v) > 1 and not k.startswith("Test")}
print("  同名类（>=2 处定义）: %d 组" % len(dups))
for k, v in sorted(dups.items(), key=lambda kv: -len(kv[1]))[:12]:
    print("    %-28s x%d" % (k, len(v)))

r = subprocess.run(["git", "status", "--porcelain", "-uall"], cwd=ROOT, capture_output=True)
gl = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
print()
print("  git 工作区变更: %d 项" % len(gl))
for l in gl[:15]:
    print("     ", l[:100])

r = subprocess.run(["git", "log", "--oneline", "-1"], cwd=ROOT, capture_output=True)
print()
print("  HEAD: %s" % r.stdout.decode("utf-8", "replace").strip())
r = subprocess.run(["git", "rev-list", "--count", "HEAD"], cwd=ROOT, capture_output=True)
print("  提交总数: %s" % r.stdout.decode("utf-8", "replace").strip())

tot = 0
for dp, dns, fns in os.walk(os.path.join(ROOT, ".git")):
    for f in fns:
        try:
            tot += os.path.getsize(os.path.join(dp, f))
        except OSError:
            pass
print("  .git 体积: %.0f MB" % (tot / 1048576.0))
