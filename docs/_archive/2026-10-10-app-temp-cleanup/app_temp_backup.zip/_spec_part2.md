# 第三篇 核心机制

## 15. 真相源与并发模型

### 15.1 `EditorModule._clips` 的唯一性

```
self._clips_lock = threading.RLock()      editor_module.py:480
self._clips      = []                     editor_module.py:481
```

**为什么必须持锁**（注释 :473-479 明示三类跨线程访问）：
1. 画布桥 HTTP 线程读写
2. autosave 定时器每 3s 序列化
3. 渲染 / 导出主线程遍历

**三条强制纪律：**

| 纪律 | 做法 | 位置 |
|---|---|---|
| ① 非原子替换整段 | 必须 `with self._clips_lock:` 包住「清空 → 逐个 add」 | `agent_replace_timeline_clips:8083`（:8100-8104） |
| ② 序列化 / 遍历用快照 | 绝不把 `self._clips` 引用交给 `json.dump`；改用 `_clips_snapshot()` | `_clips_snapshot:8058`（锁内 `list()`） |
| ③ 锁是 RLock | 允许同线程重入，避免自死锁 | `:480` |

**对外注册：** `set_full_clips_provider(lambda: self._clips_snapshot())`（`:593`）+ `set_clips_writer(...)`（`:594`）

**Agent 公开接口：** `agent_get_timeline_context():8075` / `agent_replace_timeline_clips():8083`

**反例（禁止）**：`AppState` 与孤儿 `ExportRenderer` 未接线，往它们写数据等于写进黑洞。

## 16. 插件双体系（两个 `PluginManager`）

| 维度 | 新体系 `ExtensionsRegistry` | 旧体系 `PluginManager` |
|---|---|---|
| 定义 | `extension_base.py:332` | `plugin_manager.py:13`（另有 `plugin_hotloader.py:49` 同名） |
| 覆盖 | 三类扩展：Plugin`:149` / Skill`:213` / Mcp`:263` | 仅插件 |
| 单例入口 | `get_extensions_registry():402` | `load_plugins():64` |
| UI 合并 | `extensions_module.py:160-161` 取新注册表；`:173-177` 兼容初始化旧体系；`:1291` 注释「合并 ExtensionsRegistry + PluginManager + PluginStore」 |
| 另有 | — | EditorModule 独立懒加载旧 PluginManager（`editor_module.py:868`） |

**结论：两者并存、不合并。** 真家源码目录是 `app/plugins/`；`plugin_*.py` 单文件与旧 `plugins/` 目录已归档。
**注册表 id 用 `extensions`（不是旧 `plugins`）。**

## 17. 冻结区（9 zone / 85 锁点）

**清单**：`docs/knowledge/frozen_zones.json`（机器基线，勿移动）
**基线**：`docs/knowledge/frozen_zones.hashes.json`（85 个锁点哈希）
**守卫**：`scripts/frozen_zone_guard.py`（无参 = 校验；`--update` 解冻改完后重写；`--list` 列出）

**三类锁点**（`collect_hashes:74-103`）：

| 类型 | 哈希对象 | 实现 |
|---|---|---|
| `symbols` | AST 提取的函数体 | `:86-92` |
| `files` | 整文件 | `:93-95` |
| `markers` | `FROZEN:<id> BEGIN/END` 标记块 | `:96-102` |

**9 个 zone：** `playback-av:7` · `exit-media:95` · `clip-transform:133` · `transform-bake:153` · `canvas-transform:190` · `plugin-host-ui:231` · `plugin-store-catalog:260` · `stage3d-core:286` · `canvas-magnetic-intent:312`

**纪律**：未获用户「解冻 `<zone-id>`」前，禁止改 `frozen_zones.json` 所列符号与 `FROZEN:*` 标记块。改 zone 需同步 **4 处**：`frozen_zones.json` · `docs/现行技术文档.md §5` · `.cursor/rules/frozen-zones.mdc` · `frozen_zones.hashes.json`（`--update` 生成）。

`canvas-magnetic-intent` 锁 33 个整文件 —— **画布改动无一例外需要先解冻**。

## 18. 事件总线与内核

`app/modules/lego/core.py:585`

| 组件 | 行号 | 职责 |
|---|---|---|
| `EventType:25` | — | 事件类型枚举 |
| `EventBus:113` | `emit:165` | 发布订阅 |
| `MasterClock:220` | `tick:356` | 主时钟 |
| `DataBus:375` | — | 数据总线 |
| `TimelineModel:449` | — | 时间线模型 |

启动时由 `main_qt6.py:381-384` 创建为单例。测试有 `reset_singletons:78`（autouse）保证隔离。

## 19. 画布桥接协议

### 19.1 基础约定

| 项 | 值 | 位置 |
|---|---|---|
| 基址 | `http://127.0.0.1:18765` | `bridge.ts:5`；`canvas_bridge.py:55` |
| 端口纪律 | **不得更改**（注释明示） | `canvas_server.py:11` |
| 运行端口 | 静态 3011 / dev 3010（不得更改） | `canvas_runtime.py:42-43`；`frozen_zones.json:294` |
| Token 优先级 | `window.__SHIGUANG_BRIDGE_TOKEN` → `localStorage.__shiguang_bridge_token` → URL `?token=` | `bridge.ts:59-66` |
| 请求头 | `X-Shiguang-Token`（多数端点同时走 query） | `authHeaders:68` |
| Tauri 覆盖 | `invoke("get_bridge_token" / "get_bridge_url")` | `ensureTauriBridgeCredentials:38` |

### 19.2 HTTP 端点清单（约 45 个）

| 类别 | 端点 | 调用点行号 |
|---|---|---|
| 提示词代理 | `/host/prompt-fetch` `/host/prompt-bundled` `/host/prompt-image` | 80 / 99 / 125 |
| 配置与模型 | `/host/prefs` `/host/image-models` `/host/audio-models` `/host/music-models` `/host/video-models` `/host/chat-models` | 132 / 152 / 850 / 875 / 900 / 686 |
| 生成 | `/host/generate-image` `/host/generate-audio` `/host/generate-music` `/host/generate-video` `/host/inpaint` `/host/still-video` | 202 / 586 / 628 / 945 / 557 / 1248 |
| 后处理 | `/host/model-preload` `/host/video-postprocess` | 294,309 / 987 |
| ComfyUI | `/host/comfyui/run` `/host/comfyui/status` | 426 / 458 |
| 3D / 姿态 | `/host/pose-extract` `/host/pose-video-encode` | 1059 / 1108 |
| 批量视频 | `/host/video-batch`（POST/GET） `/host/video-concat` | 1187,1205 / 1226 |
| 分镜 / 拉片 | `/host/storyboard-breakdown` `/host/video-storyboard` `/host/storyboard-camera-plan` `/host/storyboard-memory-plan` | 1369 / 1427 / 1458 / 1511 |
| Agent | `/host/agent` `/host/agent/start` `/host/agent/chat` `/host/agent/session` `/host/project-agent/chat` | 1694 / 1715 / 655 / 824 / 740 |
| 工具 | `/host/tools` `/host/tools/run` | 782 / 803 |
| 素材 | `/host/upload-asset` `/host/ai-config-patch` `/host/canvas-ai-review` | 1550 / 1633 / 380 |
| 编辑器联动 | `/inject.js` `/ingest` `/editor_outbox` `/host/timeline-snapshot` | 1738 / 1762 / 1788 / 1821 |
| **SSE** | `/host/agent/events` | 1888 |
| 回执 | `/host/agent/reply` | 1944 |
| 其它 | `/host/characters`(store.ts:2296) · `/host/generation/{submit,status,cancel,list}`(generationQueue.ts:92-133) · `/host/budget`·`/host/calls`(AgentPanel.tsx:638) · `/host/project-snapshot/{export,import}`(projectZip.ts:283,303) · `/host/interpolate`(CanvasShell.tsx:2157,3033) |

**响应约定**：统一 `fetch` + JSON；成功普遍 `{ ok, message?, data? }`，失败抛 `HTTP <status>` 或返回 `{ok:false, fallback_placeholder:true}`（`generateImageViaHost:183-233`）。

### 19.3 SSE 事件协议

- 客户端：`subscribeAgentEvents:1884` 用 `EventSource`，监听命名事件 `"agent"`（`:1899`）
- 信封：`AgentEventEnvelope:1862` = `{ id, ts, from, to, type, correlation_id, payload, ack_required }`
- 断点续传：`since_id`（`:1887`）
- **事件类型**（消费于 `AgentPanel.handleEditorEvent:189-276`）：`ping` / `pong`（心跳忽略）· `chat.delta`（流式增量，含 `status:"start"`）· `chat.done` · `chat.message` · `task.progress` · `task.done` · `task.fail` · `task.create` · `compliance.report`
- 回执：`sendAgentReply:1937` POST `/host/agent/reply`，`type` 默认 `"canvas.reply"`

**服务端实现**（`canvas_server.py:435`）：先回放环形缓冲断线补发（`:454-459`）→ 注册订阅队列（`:465-467`）→ 15s 超时发 `:ping` 保活（`:477`）。桥侧 `_EVT_BUFFER:100`（maxlen=200）、`broadcast_agent_event:129`。

### 19.4 路由机制（绞杀者模式）

`canvas_server.py:264-299`：路由表 `_ROUTES_GET/_ROUTES_POST:274-275`，装饰器 `_route_get:278` / `_route_post:290`（**重复注册直接 raise** `:283`）；分发 `_dispatch_table:348`（命中则执行，未命中回落老的千行 if 链）。

> 注释 `:264-273` 记录教训：「追加到文件末尾会落进 `return` 之后永远走不到」——现已配 AST 校验脚本防复发。

### 19.5 Agent 工具白名单（画布侧）

`AgentPanel.executeRemoteTask:283-571` + `agentPolicy.ts:14-47`：

```
addNode / updateNode / connectNodes / deleteNode / runGenerate / batchGenerate
runBatchGenerate / setNodeImage / setNodeVideo / importImage / queryTimeline
queryNodes / selectNode / duplicateNode / groupNodes / undo / redo
bindShotlistFrame / fillStoryboardCell / breakdown         （及对应 canvas_* 别名）
```

策略三档：`plan`（只读，写操作 deny）/ `collaborative`（写操作 require_approval）/ `autonomous`（allow）

## 20. 主题、i18n 与安全

- **主题**：全局 QSS 由 `theme_manager.py:527` 统一下发到 QApplication 级（避免逐控件设样式卡死）。
  **⚠️ 内联样式是主题盲区**：每新增一个 `setStyleSheet` 内联控件，必须回 `set_theme()` 补刷新（对比度：深色底 `#edf3ff` / 浅色底 `#172033`）。
- **i18n**：`i18n.py:311`（`I18n:208`）
- **安全**：`security.py:982`（路径检查 `PathSecurityChecker:58`）+ `permission_management.py:654`（RBAC）+ `secure_store.py:249`（Fernet 加密落盘）
- **线程安全**：`thread_safety.py:370`（`DeadlockDetector:155`）+ `lego/utils/thread_pool.py:101`（**线程池 SSOT**）

---

# 第四篇 算法与公式

## 21. 内容情绪 8 维向量

**位置**：`drama_understanding_engine.py:541-542`（音频侧同构 `audio_emotion_analyzer.py:40`）

```python
EMOTION_DIMS = ["开心","悲伤","愤怒","紧张","浪漫","悬疑","激动","温馨"]
EMOTION_TO_INDEX = {e: i for i, e in enumerate(EMOTION_DIMS)}
```

**归一化**（`:675-679`）：`total = vec.sum(); if total > 0: vec = vec / total`
**无命中**：取均匀值 `0.125`（`:646-647`）
**输入输出**：单句对白 → `np.ndarray[8]`，和为 1

> ⚠️ `affect_model.py` **不是**内容情绪（见 §41）；内容情绪真身只在此处与 `audio_emotion_analyzer.py:40`。

## 22. ABCD 四维融合矩阵（真高光算法）

**位置**：`drama_understanding_engine.py:1429-1691`
**维度**：A=剧情(Plot) · B=情绪(Emotion) · C=视觉(Scene) · D=爆款(Viral)

**权重按剧种 8 套**（`:1432-1442`），示例：

```python
甜宠: {A:0.20, B:0.45, C:0.20, D:0.15}          # :1433
默认: {A:0.25, B:0.30, C:0.25, D:0.20}          # DEFAULT_WEIGHTS :1442
```

**时间轴构建**（0.5s 网格，`:1460` `grid_step = 0.5`）：

| 轴 | 公式 | 行号 |
|---|---|---|
| A | `score = pp.importance * pp.emotional_impact` | :1470 |
| B | `b_score = 0.40*arousal + 0.40*intensity + 0.20*volatility` | :1506 |
| | `arousal = Σvec[[2,3,6]]`（愤怒+紧张+激动） | :1495 |
| | `intensity = max(vec)` | :1498 |
| | `volatility = 1 - (top1-top2)/top1` | :1503 |
| | 局部反差 `local_contrast = (1 - cos(pre,post)) * 0.3` | :1515-1517 |
| C | 场景类型查表（CONFLICT 0.9 / ACTION 0.85 …） | :1546-1551 |
| D | `viral_detector.quick_detect().total_score / 100` | :1576-1586 |

**融合公式**（`:1597-1605`）：

```
fused(t) = wA·A(t) + wB·B(t) + wC·C(t) + wD·D(t)
```

**高光区间提取**（`:1608-1649`）：`threshold=0.35, min=3s, max=30s` 找连续高分区
**编排**（`:1651-1691`）：间隔 <3s 合并取时长加权均分；贪心控总时长

**剧种识别（元学习版）**（`content_classifier.py:299-356`）：

```
cos          = a·b / (|a||b|)                            # :242-251
adjusted_sim = sim * min(1.0, sample_count/20 + 0.5)     # :327
```

## 23. 多模态情绪融合（文本 + 音频）

**位置**：`drama_understanding_engine.py:1140-1175`

```python
fused_vec = tv * 0.55 + av * 0.45          # :1157-1166
fused_vec /= fused_vec.sum()
# 无音频向量时：fused_vec = tv
```

**标量兼容曲线**（`:1171-1173`）：`composite = Σfused[[0,4,6,7]] − Σfused[[1,2,3,5]]`（正极性 − 负极性）

**音频侧声学映射**（`audio_emotion_analyzer.py:44-58`）：RMS / 频谱质心 / 过零率 / F0 → 8 维权重启发式表

- 门控：`high_ratio = 1/(1+exp(-8*(value-0.5)))`（`:281`）
- 特征归一化：`rms_norm = min(1, rms_mean/0.15)`（`:244-247`）

## 24. LLM 优先 + 关键词降级链

**位置**：`drama_understanding_engine.py:601-629`（情绪向量）· `:683-726`（批量）· `:1010-1043`（场景分类）

**触发条件**：`_ensure_ollama_probed()` 为假（ollama 不可用）**或** `_llm_emotion_vector` 抛异常

**降级公式**（`:636-648`）：

```python
vec[i] = Σ_{w ∈ 词表_i} text.count(w)     # 词表 _FALLBACK_EMOTION_WORDS :551-568
# 命中总数归一；零命中取 0.125
```

**记账**：`llm_fallback_stats.record("emotion_vector", degraded=True, reason=...)`（`:618-627`）
**剪辑脚本侧同模式**：`editing_script_generator.py:169-207`（LLM 失败返回 None → `_gen_via_rules:275-`）

## 25. 词锚定 / 重锚引擎

**位置**：`app/core/dialogue_anchor.py`

**指纹算法**（`:70-81`）：

```python
fingerprint = "".join(re.findall(r"\w+", text)).lower()
```

只留词字符（字母 / 数字 / 下划线 / CJK），反向提取免枚举标点。

**匹配流程**（`plan_reanchor:179-270`）：
1. 快路径：id 命中且指纹一致（`:234-236`）
2. 慢路径：`_match_by_fingerprint:273-302`

**相似度**：

```python
difflib.SequenceMatcher(None, old_fp, d.fp).ratio()
DEFAULT_SIMILARITY_THRESHOLD = 0.75      # :42
```

**歧义判孤儿**（`:299-301`）：`(best − second) < AMBIGUITY_MARGIN(0.05)` ⇒ 返回 None

> 设计原则：**孤儿优先于错配** —— 找不准宁可标记，也不硬挂错句子。

**区间→时间**（`span_range:124-146`）：区间不完整（`to_word > len(words)`）直接返回 None 判孤儿，**不静默截断**；时间精度毫秒（`TIME_PRECISION = 3`，`:60`）

## 26. 剪辑决策算法

### 26.1 九维加权打分（`modules.py:540-602`）

```
score = ( 1.2·volume + 1.5·volume_change + 1.8·shot_change + 1.0·motion
        + 0.8·brightness + 0.6·saturation + 2.0·keyword + 1.5·emotion )
        × time_weight
```

- 提示词动态调权（"高能" → shot_change 2.5）：`:568-579`
- 时间权重：前 10% ×1.5、后 10% ×1.3（`:585-588`）
- 镜头切换检测 = 相邻帧 **8-bin 颜色直方图差**（`:696-700`）
- 运动强度 = 帧间平均绝对差（`:692-693`）

### 26.2 LLM 粗剪（`llm_clipper.py:228-358`）

Whisper 字幕 + 剧情上下文（`importance > 0.6` 的情节点，`:294-297`）→ Ollama 返回时间段 → MLT/FFmpeg 切片
**失败链**：MLT → ffmpeg fallback（`:444-476`）

### 26.3 精剪规则回退（`editing_script_generator.py:275-312`）

| 规则 | 阈值 |
|---|---|
| 选片 | 按 weighted_score 降序贪心凑目标时长 |
| 转场 | `≥85` fade / `≥70` cut / 其余 zoom（`:294-300`） |
| 节奏 | 平均镜头时长 `≤2.5s` fast / `≥6s` slow（`:303-309`） |
| 卡点 | 每 2.5s 一个（`:312`） |

### 26.4 停顿 / 静音检测（`filler_silence_detect.py`）

- 静音阈值 `silence_min_sec = 0.4`（`:68`）；句间 `gap_end − gap_start ≥ min_gap` 记为可删（`:312-315`）
- 纯填充词：`len(norm) ≤ 6 且全为填充字`（`:190`）
- 区间合并 `merge_gap_sec = 0.05`（`:351-361`）

## 27. 五维打分与评分回写

### 27.1 五维打分（`five_dimension_scorer.py`）

```
weighted = Σ dim_i × w_i
w = { visual 0.25, narrative 0.25, copy 0.20, bgm 0.15, duration 0.15 }   # :91-97
# 分级：S≥90 / A≥80 / B≥70 / C≥60 / D<60 剔除            :99, 218-223
# 缺评分用基线 _SMART_BASELINE = 70.0                      :180
```

### 27.2 评分回写（`score_book.py`）

```python
分组键 = (sorted(gains), sorted(negatives))     # :67-68
avg = Σ(score × w) / n                          # :214-219
w = 0.4 if retake else 1.0                      # RETAKE_WEIGHT :48
推荐门槛 avg ≥ 0.5                              # MIN_RECOMMEND_SCORE :54
score > 1 自动 /100 归一                        # :171-179
每风格上限 200 条                                # MAX_ENTRIES_PER_STYLE :51
```

**持久化**：`~/.shiguang/score_book.json`，0600 权限 + 原子写
**回写点**：`editor_ai_tools_mixin.py:353-377`（五维打完即 `record`）
**消费点**：`guard_pipeline.py:166-185`（按 style_dna 查历史高分组合替换全量负面词）

## 28. 上下文预算（`context_budget.py`）

```python
usable = min(window × 0.7, window − 4096)        # :121-145
max_chars = max(2000, int(usable × CHARS_PER_TOKEN))
CHARS_PER_TOKEN = 1/0.6 ≈ 1.67                   # :37（对齐"中文 0.6 token/字"）
MAX_USABLE_RATIO = 0.7                           # :34
OUTPUT_RESERVE_TOKENS = 4096                     # :32
```

**窗口查找**（`window_for:93-113`）：model+provider 小写拼接，取**最长命中键**（防 `"gemini"` 32K 抢先匹配 `"gemini-1.5-pro"` 2M）
**保守默认**：查不到 → `DEFAULT_MAX_CHARS = 12000`（`:29`，零行为变化）

## 29. 短剧理解引擎补充算法

**位置**：`drama_understanding_engine.py`

### 29.1 情绪状态链（`:1198-1320`）

```python
arousal = Σ v[[2,3,6]]；valence = pos − neg
delta = np.diff(arousal)；|delta| > 0.05 ⇒ rising / falling     # :1247-1252
```

**阶段标签即剪辑价值**（`:1290-1304`）：`peak 0.95 / build 0.70 / release 0.40 / plateau 0.35 / calm 0.20`
**反转判定**（`:1315-1317`）：`|v_delta| > 0.3 且前后 valence 异号` ⇒ `reversal 0.90`

### 29.2 反差峰（`:1693-1762`）

向量法：`cosine_dist = 1 − max(0, dot(before_avg, after_avg)) > 0.35`（`:1720-1722`）
标量兜底：`|after − before| > 0.35`（`:1733-1738`）
相近 2s 内去重保留绝对值大者（`:1750-1759`）

### 29.3 情绪峰值（`:1868-1883`）

窗口 5 内局部极值且 `>0.5` 或 `<−0.5`

### 29.4 MLT 高光提取（⚠️ 占位实现，勿当真实算法）

`mlt_engine_cpp.py:1375-1488`

```python
volumedetect = f"min_volume={-60 + sensitivity*40}:max_volume=-10"   # :1413-1416
score = 0.3 + sensitivity * 0.4 + (i % 3) * 0.1                      # :1444
阈值 score > 0.5；按 5s 定长切片                                        # :1446, :1432
```

> 源码自述"简单的高光检测算法" / "计算片段能量评分（模拟）"，`(i % 3)` 是周期性假波动，**不是真实音频能量**。真高光算法走 §22。

## 30. 磁吸系统五件套（画布核心）

### 30.1 edge-gap 判据（`MagneticEngine.ts:61-70`）

```ts
gapX = Math.max(a.x - (b.x + b.w), b.x - (a.x + a.w), 0)     // :65
gapY = Math.max(a.y - (b.y + b.h), b.y - (a.y + a.h), 0)     // :66
return { gap: Math.hypot(gapX, gapY), ... }                   // :69
```

**判据**：`if (gap > config.weakDistance) continue;`（`:114`）

**五档阈值**（`types.ts:66-78` `DEFAULT_MAG_CONFIG`）：

| 档 | 阈值 | 语义 |
|---|---|---|
| instant | `gap < 10` | 立即锁死 |
| strong | `gap < 60` | 强吸附 |
| medium | `gap < 50` | 中吸附 |
| weak | `gap ≤ 120` | 弱感知 |
| 其余 | — | 不吸附 |

> ⚠️ spec 注释（`types.ts:21-26`）写的 80/50/25 **已作废**，2026-09-17 裁定为 **120/50/60/10**（`types.ts:65` 注释）

**吸附落点**（单轴吸附，`:225, 243-265`）：`gap = -2`（边框融合），另一轴保持拖拽卡当前位置（`keepY`）
**测试证据**：`MagneticEngine.test.ts:60-67`（gap=5→instant、gap=30→strong，instant 优先回归）

### 30.2 Bond 咬合（`bonds.ts`）

```python
bondKey = a < b ? "a|b" : "b|a"                # 无向键  :28-30
MIN_OVERLAP = 40                                # :25
# 例：abs(rb.x - aRight) <= tol && overlapY >= MIN_OVERLAP   # :66
tol = bondTolerance = 2px
```

**设计要点**：

- 两卡大幅重叠（层叠）**不算**咬合（`:42-43` 注释）
- **纯几何实时推导，不存状态** ⇒ 刷新不丢
- 多条咬合时按拖拽方向点积选最相关一条（`:154-176`）：`score = -(ux*v.x + uy*v.y)`
- `computeBonds:102-128` 用 SpatialIndex 邻域查询避免 O(n²)

### 30.3 三段式手感（`useMagneticDrag.ts:277-309`）★ 最有特色

```ts
const pull = Math.hypot(pullX, pullY);                     // :280 拉力
const give = pull <= cfg.stretchThreshold                  // :284-287
  ? 0                                                      // 段1 ≤30px：完全粘住（无限刚度）
  : (pull - cfg.stretchThreshold) * cfg.bondGiveRatio;      // 段2 30~50px：只让出 28%
writeNodePos(id, { x: origin.x + (pullX/len)*give, ... }); // :289-292 单位向量 × 让出量
phase:  pull <= cfg.stretchThreshold ? "stretching" : "strained",   // :295
strain: Math.min(pull / cfg.breakThreshold, 1),            // :296 0~1 张力进度
// 段3：pull >= breakThreshold(50) → 断裂；本次拖拽内 mutedRef 屏蔽该目标 :303-308
```

**参数**（`types.ts:66-78`）：`stretchThreshold=30` `bondGiveRatio=0.28` `breakThreshold=50`

| 段 | 区间 | 物理模型 | 手感 |
|---|---|---|---|
| 1 | pull ≤ 30 | 无限刚度粘合（位移=0） | 纹丝不动 |
| 2 | 30 < pull < 50 | 比例阻尼（让出 28%） | 像橡皮筋 |
| 3 | pull ≥ 50 | 脆断 | 「啪」断开 |

**视觉佐证**：`grow = strain * 13`、线宽 `3 → 1.5`（`SnapSeam.tsx:110-111`）

### 30.4 让位 reflow（`reflow.ts:156-330`）

```python
同行/列判据：overlapOn ≥ MIN_OVERLAP(40)                     # :92-99, :42
让位轴选择：取两轴中对侧重叠最大者，沿其垂直轴推               # :176-189
层叠排除：overlapAlong(...) > LANDING_GAP(-2) → 不让位       # :203-206
步进：step = dimension + LANDING_GAP（= 卡尺寸 − 2px）       # :130-133
链生长：从锚点（gap 最小）逐张吸收"同行+同侧+间隙≤2px"的紧邻卡  # :238-276
红线③预测碰撞：链尾平移 step 后若与链外卡紧贴 → blocked:true 整链放弃  # :289-304
```

**三条红线**（`:20-27` 注释）：只推同行 / 列 · 链式整链推一格但不递归 · 撞链外卡即断链
**测试证据**：`reflow.test.ts`（`:219` 引用「链整体推一格」回归）

### 30.5 拖拽状态机（`useMagneticDrag.ts:68-468`）

| 阶段 | 行为 | 行号 |
|---|---|---|
| `onNodeDragStart:234-259` | 快照 `findBondFor` 咬合与咬合原点 | — |
| `onNodeDrag:262-368` | ① 咬合阻力 → ② `queryNear:313-316` 取候选 → `computeMagnetic` **只记录不覆写**（`:337-343`）→ `planReflow` **只预览不执行**（`:356-361`） | — |
| 段间 | 拖拽中 **1:1 跟手不覆写位置**（`:326-336`） | — |
| `onNodeDragStop:371-456` | 仍粘住 → 回弹 150ms（`:378-384`）；有磁吸 → 邻居先滑开 180ms（`:414`）→ 拖拽卡滑入 ghost/snapPos，200ms + strong/instant 带 **5px 过冲**（`:421-431`） | — |

**动画曲线**（`:142-153`）：

```ts
easeInOutCubic:  t < 0.5 ? 4t³ : 1 - (-2t+2)³/2
过冲:            sin((t-0.7)π/0.3) * -overshootPx     // t≥0.7 才生效
```

**SpatialIndex 格子**：`CELL_W/H = CARD_SIZE + 140`（`SpatialIndex.ts:16-17`）

### 30.6 磁吸层级（`magneticLevels.ts`）

```python
levelByGap:  gap<0 → none; gap<instant → instant; gap<strong → strong
             gap<medium → medium; gap<weak → weak; else → none      # :97-107
```

**层级元数据**（`:32-76`）：`none(rank0) / weak(0.12) / medium(0.24) / strong(0.45) / instant(1.0)`
**关键变更**：`strength` 自 2026-09-18 起**仅供 UI 展示，不再驱动吸附力度**（`:26` 注释；`MagneticEngine.ts:116-117` 同）

### 30.7 空间形态分析（`SpatialAnalyzer.ts`，非 depth 记忆）

聚类 BFS，距离阈值 `CARD_SIZE.width × 1.5`（`:95`，即 360px）；`nodeDistance` 为中心点欧氏距离（`:208-214`）

**模式识别**（`detectPattern:148-205`）：

```python
环状: radiusVariance < avgRadius² × 0.15      # :177
横排: width > height*2 且 y 方差 < 卡高²      # :183-188
纵排: height > width*1.5                      # :193
分支: 左 30% / 右 60% 分区计数                 # :198-202
```

> **未找到 depth 字段**：本文件无"空间记忆 depth"概念。项目里真正的 depth 在 `novice/NoviceCard.tsx:154`（意图胶囊层深，`min(3, max(1, intentDepth||2))`：1 表面 / 2 语义 / 3 实现）与 `stage3dControlNet.ts:66`（ControlNet 深度图），**均与磁吸无关**。

### 30.8 表现层四组件分工

| 组件 | 画什么 | 关键参数 |
|---|---|---|
| `MagneticLines.tsx:45-126` | 拖拽中的「蓝色占位缝」 | `getSeam:28-43`；柔光层 `strokeWidth=10, opacity=0.25, feGaussianBlur(4)` + 核心线 3px |
| `SnapSeam.tsx:81-167` | 已咬合被拉扯 / 落座的瞬态反馈 | 静止 idle **零渲染**（`:84-88`）；`grow=strain*13`、`thickness=max(1.5, 3-strain*1.5)`；琥珀 `#fbbf24` / 红 `#f87171`；FLASH_MS=1100 |
| `SlotGhost.tsx:38-62` | 让位后的「坑位」 | `2px dashed #378ADD`、圆角 16、6% 蓝填充；经 `ViewportPortal` 直写流坐标 |
| `SoftConnectionLines.tsx:35-103` | 待确认的「血缘虚线」 | 二次贝塞尔 `M a Q mid b`（`:70`）；中点「⚡固化」按钮；**注释注明当前恒空、仅保留链路**（`:7-8`） |

配合 `CardStack.ts:199`（层叠 reducer，`getActiveLayer:171`）与 `StackBadge.tsx:230`（层叠角标）。

## 31. 姿态重定向（`stage3dPoseRetarget.ts`）

**输入**：COCO18（2D）+ BlazePose33（z 深度）→ **输出**：25 关节 `JointPose`（`:154-291`）
**可见度阈值**：`KP_VIS_THRESHOLD = 0.4`（`:54`）

| 部位 | 公式 | 行号 |
|---|---|---|
| 摆角 | `swingX = atan2(front, up) * 180/π`，`front = -(zEl - zSh)` | :118-122 |
| 侧展 | `abductZ = atan2(dxImg, dyImg) * DEG` | :128-132 |
| 肘 / 膝弯曲 | `bend = 180 − 内角(a,b,c)`，内角 `acos(clamp(v1·v2/(|v1||v2|)))` | :135-146, 235, 266 |
| 躯干侧倾 | `spineZ = -abductZ(肩髋差) * 0.5`，clamp ±40~50° | :181-191 |
| 躯干扭转 | `spineY = (hipAng - shoulderAng) * DEG * 0.5` | :181-191 |
| 根位移 | `(baseX - mHipX) * 1.6`（归一化→米），下蹲 dy 取负 | :304-321 |
| 坏帧 | `lerpJointPose` 逐关节线性插值 | :294-301 |
| 关键点缺失 | 沿用 `prevPose` | :155-157 |

**帧采集（刀4）** `stage3dPoseVideo.ts:48-66`：`indices.push(Math.round(k*span/(limit-1)))` 保首尾，上限 **900 帧**。
**刀5**：通道就位（`stage3dControlNet.ts` 三通道导出），但目前**无模型支持 `video_motion`**。

## 32. ComfyUI → 画布转换（`comfyToCanvas.ts:101-190`）

**节点映射** `kindForClassType:41-61`（class_type 小写子串匹配）：

| 命中子串 | kind |
|---|---|
| textencode / cliptext / text | `prompt` |
| checkpoint / lora / sampler / latent / vae / unet / controlnet / model / loader / upscale | `config` |
| saveimage / previewimage / save | `image` |
| loadimage / load | `source` |
| 兜底 | `text`（**不丢节点**） |

**提示词提取** `extractPrompt:64-79`：优先 name 为 text/prompt 的 widget 对应位置字符串，兜底第一个非空字符串 widget；graph 格式查 `text / prompt / positive / clip_text / conditioning_text` 键（`:82-89`）

**连线映射**：

- UI 格式（`:135-147`）：`links = [link_id, src, src_slot, dst, dst_slot, type]`，取 `link[1] → link[3]`；要求两端存在 + 非自连 + `${src}->${dst}` 去重
- graph 格式（`:171-188`）：inputs 值形如 `[src_id, slot]`（长度 2 且 slot 为数字）→ 边

**判定**：`isComfyWorkflowText:193-202` 以「解析后 nodes 非空」为准

## 33. Agent 循环与大脑

### 33.1 ReAct 主循环（`agent_loop.py:241-434`）

```
预算常量：_DEFAULT_MAX_ROUNDS = 12 · _DEFAULT_MAX_TOOLS = 24      # :46-47
每轮：compress_messages 压上下文 :328
   → begin_model_round 预算闸 :331（失败置 reason = stopped / paused / budget）
   → 调模型
   → parse_tool_calls
       无工具调用 → reason="done" 退出 :349-354
       有工具 → 逐条执行：
           Plan 模式非只读工具跳过 :370-375
           require_approval → 收集 pending_commands、reason="approval" 立即返回 :383-394
           观察结果回流成 user 消息喂下一轮 :407-414
   → 预算耗尽 → reason="budget" :424-427
```

### 33.2 神经元激活扩散 + Hebbian 强化（`agent_brain.py:181-216`）

```python
# 扩散（只沿 weight ≥ _ACTIVATION_THRESHOLD 的突触 top-K）
post.activation = w × strength × 0.7        # _DEFAULT_DECAY :211

# 强化
syn.weight = min(1.0, w + Δ)  成功
syn.weight = max(0.0, w − Δ)  失败
Δ = 0.02 / 0.04 / 0.08 按反馈严重程度          # :274

# 全局衰减
decay_all(factor=0.9)                        # :218-221
```

### 33.3 读并发 / 写串行派发（`agent_runtime.py:196-265`）

- 只读工具（`_READONLY_TOOL_PREFIXES:23-55`）→ `ThreadPoolExecutor(max_workers=_MAX_PARALLEL_READS=3)` 并发（`:241-254`）
- 写工具 → 逐个串行保序
- 超时：读 8s / 写 20s（`:59-60`）

### 33.4 能力目录与守卫（`agent_capability_catalog.py`）

- `CAPABILITY_ROWS:73`：每行 8 元组 `(capability_id, category, effect, paid, description, hemisphere, label, keywords)`（`:39`）
- 合法集：`effect ∈ {read, canvas_write, file_write, media_write, memory_write}`（`:220`）；`hemisphere ∈ {right, left, cc}`（`:221`）
- 画布节点级行由 `_canvas_node_catalog_rows():43-70` 从 `agent_action_registry._CANVAS_ACTION_ROWS` **派生**，避免两处手写分裂
- 守卫 `verify_catalog_consistency():261-284`：

```
missing_reg = catalog_ids - registered   → 「目录登记但未注册」
missing_cat = registered - catalog_ids   → 「已注册但目录缺失（会落 FILE_WRITE 兜底）」
再逐行校验 effect / hemisphere 合法性、description 非空
```

**新增能力的唯一入口 = 目录表加一行**（由 `verify_catalog_consistency()` 守卫）。

### 33.5 能力调用链（`capability_dispatcher.py:169-307`）

```
invoke():
  agent_policy.decide()           策略判定 :203-228（DENY 拒绝 / REQUIRE_APPROVAL 返回 require_approval）
  agent_origin_scope()            盖 Agent 章执行 handler :251-253
  agent_brain.activate()          激活神经元 :271-279（成功 strength=1.0 / 失败 0.6）
  memory.record()                 写 trace :282-295（失败 score=0.8 > 成功 0.5）
  广播 CAPABILITY_COMPLETED
  GenCancelled 异常 → 直接 re-raise 不写 trace :256-259
```

### 33.6 管线二分路由与六阶段编排

**路由**（`agent_pipeline_router.py:93-140`）：

```python
has_material = len(_filter_usable(materials)) > 0    # :112-114
→ EDITING if has_material else GENERATION            # :116-124
# _filter_usable:144-165 按扩展名推类型（_infer_type:167-180），unknown 直接过滤防误触发
```

**编排**（`agent_pipeline_orchestrator.py:133-320`）：

```
routing:161 → generation / import_parsing:174/:189 → preview:206
  → 预览失败时 _consult_brain 决策「重生成 vs 带瑕疵继续」:219-237
  → 人工模式有失败则停在 waiting_for_preview_confirmation:249-268
  → scoring:271 → scripting:277 → editing:286 → done / error
降级语义：有脚本无成片 = degraded=True，不算成片成功 :295-299
```

## 34. 生成链路三件套

### 34.1 额度池（`provider_pool.py`）

```python
健康 = cooldown_until ≤ now 且 used_today < daily_quota      # :201-210
排序 = (-quality_tier, last_used_at 升序)                     # :233-236
退避 = min(BACKOFF_BASE × 2^(fails-1), BACKOFF_CAP)           # :423
        BACKOFF_BASE = 60.0 / BACKOFF_CAP = 1800.0            # :55-57
成功才扣额度：used_today += segments                          # :403
跨天清零 _rollover :194-198
reorder_providers :247-273（有健康账号的提前，local 恒垫底）
```

> **注意**：失败**不扣**额度 ⇒「失败回滚」以「不扣减」形式天然成立。

### 34.2 能力矩阵与收益排序（`provider_caps.py`）

```python
supports = 能力位 ∧ duration ≤ max_duration ∧ resolution ∈ resolutions   # :195-203
utility  = q̂ − λ_c × price                                              # :259-262
λ_c 默认 _LAMBDA_PRICE = 0.2（可被 budget_pacer 影子价覆盖）              # :89-91
排序键 = (-utility, -tier)；local 恒追加末尾                               # :265, :269
cost_estimate = price_per_clip × count                                   # :294-300
```

### 34.3 生成任务队列（`canvas_gen_jobs.py`）

```
并发 SG_GEN_CONCURRENCY 默认 3                                 # :20
FIFO 队列 + 固定线程池                                          # :380-455
重试间隔 retry_backoff^(attempt-1) 指数退避                     # :419, :438
状态机 queued → running → done / failed / cancelled
queued 真取消；running 经 GenCancelToken 关闭在途 HTTP 响应打断  # :16-20, :121-137
★ 取消必须丢弃结果、绝不落盘                                    # :452-453
```

### 34.4 生成后处理（`generation_postprocess.py`）

```python
# 补帧 :199-203
diff = mean(absdiff(帧i, 帧i+1))
if diff < 40.0: 插入 (0.5×a + 0.5×b) 混合帧使帧数翻倍
# 超分 :228-243：SuperResolutionEngine 2x 逐帧
```

## 35. 异构动态协作引擎（12 切片落地）★

> 本节与《异构动态协作引擎规格书》v4.3 逐篇对齐。数据来源：各切片文件头注释的「来源：§xx」标注。

### 35.1 切片 - 规格书 - 落地总表

| # | 切片文件:行数 | 对应规格书 | 落地程度 | 接入状态 |
|---|---|---|---|---|
| ④ | `ai/budget_pacer.py:300` | 第六篇 C 模块 | 完整 | ✅ `video_generation_client.py:466-468, 622-629` |
| ⑤ | `ai/execution_modes.py:221` | §10 / §11 / §12 | 完整 | ✅ `:484, 508`（D 执行体部分接线） |
| ⑥ | `ai/divergence_probe.py:290` | 第四篇 §16-19 | 完整 | ✅ `:499-504, 640-642, 664` |
| ⑦ | `ai/fusion.py:208` | 第八篇 §42 | 完整 | ⚠️ 仅视频算子接线（`:665, 743`），文本 / 音频未接 |
| ⑧ | `ai/global_price.py:369` | §2 / §39-41 | 完整 | ⚠️ λ 已接线（`:474-476, 632-634`），`auction()` 未接生产 |
| ⑨ | `ai/sampling_review.py:464` | 第十四篇 §70-76 | 完整 | ✅ `ai_video_generation_pipeline.py:416, 438-439, 489-491` |
| ⑩ | `ai/module_scheduler.py:357` | 第二篇 §5-7 | 完整（状态机） | ❌ **未接生产** |
| ⑪ | `ai/simulator.py:268` | 第十一篇 | 完整 | ❌ 仅 `_verify/check_simulator.py` |
| ⑫ | `ai/engine_api.py:249` | 第十篇 | 完整 | ❌ 仅 `_verify/check_engine_api.py` |
| — | `ai/quality_prior.py:223` | §14 / §39 最小切片 | 完整 | ✅ `video_generation_client.py:455-462, 606-608`；`ai_video_generation_pipeline.py:415, 471, 497` |
| — | `ai/degradation.py:195` | §44-46 | 完整 | ✅ `video_generation_client.py:149, 223, 254, 707` |
| — | `ai/provider_pool.py:498` | 头注为 P0-1（非规格书切片） | 完整 | ✅ `:139-142, 173, 202, 325, 386-388` |
| — | `ai/provider_caps.py:305` | 头注为 P0-3（非规格书切片） | 完整 | ✅ `:448, 484-485, 487` |
| — | `ai/score_book.py:279` | 头注为 P0-2（非规格书切片） | 完整 | ✅ `guard_pipeline.py:171-173`；`editor_ai_tools_mixin.py:359, 368, 372` |

**统计：11 个已实接主链路；3 个（module_scheduler / engine_api / simulator）实现完整但未接线。**

### 35.2 ④ PI 影子价格控制器（`budget_pacer.py`）

**定位**：把静态 `λ_c = 0.2` 升级为随预算消耗连续调节的 PI 影子价格。

```python
# 剩余法误差 :197-199
budget_left_ratio = max(0.0, (budget - spent) / budget)
time_left_ratio   = max(0.02, 1.0 - _day_progress())
e = budget_left_ratio - time_left_ratio

# PI 迭代 :217-219
delta   = _kp * (self._e_prev - e) + _ki * (-e)
new_lam = lam + delta
clamped = min(_LAMBDA_MAX, max(_LAMBDA_MIN, new_lam))
```

**常量**（`:54-61`）：`_DEFAULT_BUDGET=50.0` · `_LAMBDA_INIT=0.2` · `_LAMBDA_MIN=0.05` · `_LAMBDA_MAX=1.0` · `_KP=0.5` · `_KI=0.1` · `_UPDATE_INTERVAL=30.0`（周期锁死） · `_ROLLOVER_RELAX=0.5`

**三项稳定措施：**

| 措施 | 实现 | 行号 |
|---|---|---|
| 抗卷绕 | 撞界时不更新 `_e_prev`，冻结积分 | :221-224 |
| 观测门控 | `_obs_valid=False` 直接 return；恢复时 `_pi_ready=False` 首拍只建基线 | :207-215, :104-117 |
| 跨日回退 | `lam = _LAMBDA_INIT + (lam - _LAMBDA_INIT) * 0.5` | :174 |

### 35.3 ⑧ 全局价格层 + 配额拍卖（`global_price.py`）

**叠加规则**（头注 §2）：`λ_eff(u, τ) = λ^G + λ^τ`

```python
# 积分主导 PI :219-227
p_term = _KP_G * k * (e_prev - e)
i_new  = i_term + _KI_G * k * (-e)
raw    = _LG_INIT + i_new + p_term
# ★ 变化率限制：|Δλ^G| ≤ _RATE_LIMIT_G = 0.1
clamped = min(_LG_MAX, max(_LG_MIN, raw))
# 抗卷绕：at_bound and raw_beyond → 冻结 _i_term :228-236
```

**常量**（`:45-55`）：`_DEFAULT_MONTHLY_BUDGET=500.0` · `_LG_INIT=0.0` · `_LG_MIN=0.0` · `_LG_MAX=0.5` · `_KP_G=0.1` · `_KI_G=0.3` · `_UPDATE_INTERVAL_G=60.0` · `_RATE_LIMIT_G=0.1` · `_KAPPA_GEARS=(0.5, 1.0, 2.0)`

**配额拍卖四步**（§39，`:283-341`）：

```
① 关键任务保底：floor  = min(pool, remaining × floor_ratio)
② 欠账扣款：    pay    = min(debt, quotas[t])
③ 余量按压力：  share  = pool × p / total_p
④ 永久不变量：  total_alloc ≤ remaining        （否则 assert，:309-338）
```

### 35.4 ⑥ 分歧度探针（`divergence_probe.py`）

**定位**：量化本地/云端差异 Δ，**仅用于筛 D 模式候选，不直接决策路由**。

```python
# 文本分歧度 :58-59
delta = 不同值字段数 / 并集字段数

# 视频/音频分歧度 :108
delta = 0.6*d_hash + 0.25*d_size + 0.15*d_dur

# 自适应阈值 :224-225
raw = _BASE_THRESHOLD - _VAR_GAIN * (quality_var + var_d)
tau = min(_THRESHOLD_MAX, max(_THRESHOLD_MIN, raw))

# EMA 更新（record）:176-177
mean += _ALPHA * delta_err
var   = (1-_ALPHA) * (var + _ALPHA * delta_err * delta_err)

# D 模式判定 :247
ok = delta > tau
```

**常量**（`:33-38`）：`_ALPHA=0.3` · `_BASE_THRESHOLD=0.5` · `_THRESHOLD_MIN=0.15` · `_THRESHOLD_MAX=0.8` · `_VAR_GAIN=1.0` · **`_COST_RATIO_LIMIT=0.02`（探针成本 ≤ 单元成本 2%）**

> 语义：质量方差越大 → 不确定越高 → 阈值自动放低 → 越容易开启双路校验。

### 35.5 ⑤ 六种执行模式与收益函数（`execution_modes.py`）

**模式集**：`Mode ∈ {L, C, D, L→C, C→L, SkipMerge}`（`:39-46`）

**收益函数**（`:67` 注释）：

```
V_i(m) = q̂_i(m) − λ_c·(ĉ_i(m) − c_base) − λ_l·(l̂_i(m) − l_base) − κ_sw·1{switch}
基线：c_base = cost_local，l_base = lat_local
```

**逐模式展开**：

```python
v[L]  = q_local                                              # :107
v[C]  = q_cloud − lam_c*max(0, cost_cloud−c_base)
                − lam_l*max(0, lat_cloud−l_base)             # :107-110
v[D]  = q_D − lam_c*max(0, cost_local+cost_cloud−c_base)
            − lam_l*max(0, max(lat_local,lat_cloud)−l_base)  # :111-113
v[L2C] = p_local_ok*v[L] + (1-p_local_ok)*(v[C] − lam_l*max(0,lat_local))   # :116-117
v[C2L] = p_cloud_ok*v[C] + (1-p_cloud_ok)*v[L]               # :120
v[SkipMerge] = v[C] + lam_c*0.05                             # :122

# κ_sw 切换惩罚 :124-127
if current_mode and kappa_sw > 0:
    for m != current_mode: v[m] -= kappa_sw
```

**融合质量**（`:78`）：`q_D = 1 − (1 − q_L)(1 − q_C)`
**可行集投影**（`:136`）：硬约束（显存/QPS/断网）**只删除不可行选项，绝不修改打分**（保证日志可完全归因）。

### 35.6 ⑨ AI 辅助抽检（`sampling_review.py`）

**自适应分层抽样**（`:188-194`）：

```python
p   = _P_BASE * (1.0 + _ALPHA_R * r + _ALPHA_D * dv)
p   = min(1.0, max(_P_MIN, p))
hit = _stable_hash(unit_id) < p
# 新版本 / 新题材强制必检：p = 1.0   :180-185
```

**常量**（`:43-54`）：`_P_BASE=0.02` · `_P_MIN=0.005` · `_ALPHA_R=4.0` · `_ALPHA_D=2.0` · `_DEDUP_WINDOW=86400.0` · **`_DRIFT_WARN=0.15`** · **`_DRIFT_FREEZE=0.30`** · `_MIN_SAMPLES_FOR_DRIFT=5` · `_ALPHA=0.3`

**残差漂移监控**（`:330-362`）：

```python
residual = |y − ai_score|                 # y 为人工真值标签
d = residual - mean
mean += _ALPHA * d
var   = (1-_ALPHA) * (var + _ALPHA * d * d)
mean > 0.30 → freeze（冻结闭环权重更新）
mean > 0.15 → warn
```

**AI 预审**（`prescreen:209`）：输出风险等级（低/中/高），高风险优先推送人工；**AI 打分禁止作为真值参与闭环**（`:279` `submit_ai_score` 与 `:311` `submit_human_label` 分离）。

### 35.7 ⑩ 模块调度器（`module_scheduler.py`，未接线）

**优先级**（`:32-37`）：`P0=0` 画布预览 · `P1=1` 画布生成 · `P2=2` AI 剪辑 · `P3=3` 视频/音频生成 · `P4=4` 后台批量
**调度选择**（`:188-189`）：按 `(priority, seq)` 最小
**DAG**（`:155-157`）：依赖就绪 → `ready`；上游 `failed/cancelled/skipped` → 下游 `skipped`（降级传播）
**不可抢占**：`DEFAULT_MODULES:328-343` 中 `video_gen` / `audio_gen` 标 `non_preemptible=True`
**进度**（`:306`）：`progress = (done + degraded) / total`
**关键方法**：`register_module:60` `submit:94` `_would_cycle_locked:129` `next_runnable:173` `should_preempt:193` `start:211` `complete:225` `fail:238` `cancel:262` `preempt:276` `status:295`

### 35.8 ⑦ 三分融合算子（`fusion.py`）

**铁律**（第八篇 §42）：**禁止通用张量加权平均**，三类介质各用独立算子，且必须保留 `provenance` 溯源字段。

**文本算子**（`fuse_text:38`）：三级仲裁
```
字段锁域（lock） > 逐字段质量分（score） > 命名空间优先级（priority / only）   # :64-88
输出 provenance = { 字段: {source, rule} }
```

**视频算子**（`plan_video_fusion:99`）：
```python
keyframe_ok = False        → q *= 0.7                                  # :128
质量差 < 0.05 且 prefer 在场 → 让给 prefer                               # :128-146
按 slot 升序产出拼接计划
```

**音频算子**（`plan_audio_mix:162`）：
```python
_ROLE_GAIN = {"voice":1.0, "music":0.5, "sfx":0.7, "other":0.6}   # :27
target_peak = 0.9
单轨：peak*gain > target → gain = target / peak                     # :181-203
总线：bus > 1.0 → bus_scale = 1.0 / bus（等比压缩）
```

### 35.9 六级降级（`degradation.py:39-47`）

| 级别 | 名称 | 含义 |
|---|---|---|
| 0 | `full` | 完整交付 |
| 1 | `dual_down` | 双路降级【预留】 |
| 2 | `cloud_down` | 换渠道 / 换模型 |
| 3 | `quality_down` | 降分辨率 / 时长重试 |
| 4 | `feature_down` | 功能降级【预留】 |
| 5 | `partial` | 部分交付 |
| 6 | `local_fallback` | 本地占位 |

**终态取最严重**：`_FINAL_ORDER = (6,5,4,3,2,1,0)`（`:50`）
**失败分类**（`:57-79`）：`resource / auth / model / unknown`；`_RESOURCE_PATTERNS` 含 `timeout / 超时 / oom / 429 / 限流 / 网络 / 502 / 503 / 504`
**L3 重试**：480p 降级重试（`:161-179`）

### 35.10 质量先验库（`quality_prior.py`）

```python
# EMA :124-127
delta = x - mean
mean  = mean + a * delta
var   = min(_MAX_VAR, (1-a) * (var + a * delta * delta))     # a = _ALPHA = 0.3

# 冷启动继承 :178-183
var = min(_MAX_VAR, max(src.var * 4.0, 0.25))                # _COLD_START_VAR=0.25, _INHERIT_VAR_FACTOR=4.0
n   = 0.0

# 查桶优先级 :158-166
route_mean → quality 桶 → default 桶 → 中性 0.5

# 真值映射 :210-212
passed → 1.0；未过 → 0.3；skipped → None
```

> 语义：**新版本继承均值、放大 4 倍方差**实现冷启动不确定度 ⇒ 越不确定越容易触发双路校验。

### 35.11 ⑪ 端到端仿真器（`simulator.py`）

**渠道剧本**（`:32-38`）`(ok_rate, quality, latency, cost)`：

| 渠道 | ok_rate | quality | latency | cost |
|---|---|---|---|---|
| dashscope | 0.90 | 0.85 | 8.0 | 1.5 |
| seedance | 0.85 | 0.75 | 6.0 | 1.0 |
| cogvideo | 0.80 | 0.65 | 5.0 | 0.8 |
| local | 1.00 | 0.30 | 0.5 | 0.0 |

**结构**（`:41-73`）：`Simulator` 内实例化 `BudgetPacer / GlobalPriceController / QualityPriorStore / DivergenceProbe / ModuleScheduler / SamplingReview`
**输出报告**（`:220-258`）：`lambda_tau_final` `lambda_g_final` `tail_var` `spent_total` `route_counts` `degradation_events` `auction_invariant_fails` `decision_time_avg_ms` `digest`
其中 `_tail_var` 取**后 20% 方差**（`:213-218`）
**参数扫描**：`parameter_sweep:261`

### 35.12 ⑫ 统一门面与错误码（`engine_api.py`）

**接口清单**：`create_task:86` `submit_unit:120` `route_callback:190` `resource_report:203`
**响应信封**（`:65-70`）：`{ok, code, message, data}`
**错误码**（`:34-44`）：

```
ERR_OK · ERR_INVALID_PARAM · ERR_CAPABILITY_UNSUPPORTED · ERR_MODULE_UNHEALTHY
ERR_DEPENDENCY_CYCLE · ERR_DUPLICATE_TASK · ERR_BUDGET_EXHAUSTED · ERR_LOOP_FROZEN
ERR_PROVIDER_UNAVAILABLE · ERR_CANCELLED · ERR_INTERNAL
```

**`resource_report`**（`:203-231`）：汇总 L1 预算 / L0 账单 / 调度 / 抽检**四视图**

## 36. AI 四守护

**共享基座** `guard_base.py`：指纹 `sha1("k=v|k=v..."(排序))[:12]`（`:81-87`）；漂移 = 特征字典逐 key 不等即记 `drifted`（`:90-114`）

| 守护 | 位置 | 核心公式 / 阈值 |
|---|---|---|
| ① 角色一致性 | `character_anchor.py:178-222` | 漏拼判定 `missing = [k for k,v in must.items() if v[:6] not in normalized_prompt]`（`min_prefix=6`）；只盯 `STRONG_TRAITS`（appearance / memory_anchors）；漏拼镜头进 `retry_indices` |
| ② 表情幅度 | `expression_guard.py:40-254` | 维度上限表（cheekPuff=0.30 / eyeBlink=0.85 / 兜底 `FALLBACK_CAP=0.60`）× 档位缩放（subtle 0.65 / natural 1.0 / intense 1.3）；`caps[k] = min(1.0, NATURAL_CAPS[k]×scale)`（`:100`）；帧间限幅 `|val − prev| > 0.25` 时 `limited = prev ± max_delta`（`:196-202`） |
| ③ 道具一致性 | `prop_guard.py:226-286` | 掌尺度 `palm = dist(腕, 中指根)`；指尖最小间距比 `min_gap = min(dist(指尖对)/palm)`；`min_gap < 0.35` 判手指粘连；关键点 `conf < 0.5` 判不可信 |
| ④ TTS | `tts_guard.py:39-355` | 每段 ≤ `DEFAULT_MAX_CHARS=40` 字；过短段（<8）并入相邻（`:107-118`）；回读相似度 `SequenceMatcher(None, asr, 原文去标点).ratio()`，`ratio < 0.9` 判「发音与字幕不符」需重生成（`:352-354`） |

**编排** `guard_pipeline.py`：

- 生成前注入 `enhance_prompt:88`（按 style_dna 查 score_book 替换全量负面词 `:166-185`）
- 生成后质检 `augment_inspection:243-322`
- **规则层零成本永远跑**（道具 / 角色漂移）+ **LLM 层默认关**（`use_llm` 默认 False 防烧钱，`:259-260, :301-312`）
- 表情档位自动推断：命中强情绪词表 → intense（`:345, :433-437`）

## 37. 双记忆模型

### 37.1 观众记忆衰减（`memory_model.py`）

```python
λ = λ0 · (1 − αE) · (1 − βC) · (1 + γI)      # α=0.60, β=0.50, γ=0.80
R(t) = R0 · e^(−λt)                           # 下限 _MIN_RATE = 1e-4
# λ0（每小时）：细节 0.090 / 意义 0.020 / 情绪 0.008
综合分 = (0.2·D(t) + 0.45·S(t) + 0.35·E(t)) × (0.5 + 0.5R)    # :184-208，默认 t = 72h
```

### 37.2 系统经验记忆强度（`memory_store.py:142-185`）

```python
strength = score · e^(−λt)
λ = λ0 · (1 − α·C)，其中 C = min(recall_count / _RECALL_SATURATION, 1)
λ0 = 0.001 / 小时                     # 天级，比观众模型小两个数量级
# reinforce 只对真正被注入的条目 recall_count+1 并刷新衰减起点
```

query 默认按静态 score 排序；开 `set_strength_ranking` 后按 `strength_at` 排序（`:251-280`）。

> 语义：**写得越重、被用得越多的经验忘得越慢**；没人碰的记忆自然沉底。

## 38. 故事板时长分配（`storyboard_memory.py`）

**24h 基线保留率**（docstring `:13`）：细节 **11.5%** / 意义 **61.9%** / 情绪 **82.5%**

```python
out[i] = total × w[i] / Σw                      # :102 按保留率权重分配
# 迭代 ≤8 轮夹紧到 [MIN_DURATION=0.8, MAX_DURATION=12.0]  把余量按权重摊回未夹紧行 :104-128
```

**干扰警告**（`:186-198`）：相邻双情绪锚点，或 `≥4 镜且情绪镜过半` ⇒ 「**名场面太多反而记不住**」（单镜长 ≥4s 且两个以内更佳，取片段 ≤2 个）。

## 39. 主动建议（`agent_proactive.py`）

**状态快照 × 规则表**（`:36-92`）：

```python
for rule in sort(_RULES, key=-priority):
    if rule.condition(state): hit
# 同一 id 去重、按 priority 降序截 limit 条        :110-120
```

state 字段：`clip_count / has_transition / has_subtitle / selected_has_color / is_export_ready`（`:134-158`）
示例规则（`:57`）：`clip_count >= 2 and not has_transition` → 建议加转场
**确定性、无随机**（`:97`）

## 40. 内核自动降级（`editor_scheduler.py:512-535`）

```python
if avg_cpu > 85.0 or (0 < avg_fps < 15.0) or avg_latency > 500.0:
    PROFESSIONAL → LIGHTWEIGHT          # resolve_kernel:547-550
# 带冷却时间 _check_cooldown() :495-498 防抖
```

## 41. Agent 内心状态公式（`affect_model.py`）

> ⚠️ 与 §21 内容情绪**完全不同域**：这是 Agent 自己的"情绪计"。所有量均 `clamp01`（`:60-68`）。

| 公式 | 位置 | 含义 |
|---|---|---|
| `pain = S × I × C` | :140-146 | 乘法保真，任一为 0 即无痛 |
| `A = w1·S + w2·N + w3·E + w4·G + w5·M`（五权各 0.20，和=1） | :157-167 | 激活值；`AROUSAL_THRESHOLD = 0.60`（`:100`）分进取 / 保守 |
| `Disappointment = E × I × (1 − PE)` | :170-179 | 失望 |
| `Trust = α·P + β·Cons − γ·V − δ·B`，α=0.70 β=0.30 γ=0.40 δ=0.20 | :103-106, :182-195 | 信任 |
| `Impact = P × H × U × D` | :214-218 | 心理落量（四者皆大才"习得性谨慎"） |
| `M_{t+1} = M_t + α(E − M_t)`，α=0.30，M0=0.5 | :221-227 | 期望 EWMA |

**行为含义**：连续失败 → 痛感与失望累积 → 激活值跌到阈值下 → 转为保守模式（减少主动建议）。

---

# 第五篇 数据流与主链路

## 42. 剪辑主链（人工改 + Agent 改）

```
① 导入      _import_video:1313 → 探测/代理 _kick_proxy_for_path:5436
② 落时间线  _add_clip_to_timeline:9158 → 改 self._clips（持 _clips_lock）
③ 编辑操作  move_clip / _resize_clip / _cut_clip / _split_clip
            每次走 _apply_action:3653 入撤销栈（HistoryManager:40）
④ 预览      _render_timeline_frame:6289（多线程 FrameReaderThread:46 + EffectsWorkerThread:184）
⑤ 导出      _export_video:147 → editor_export.finalize_multitrack_export:220
            （叠上层 + 混音 + editor_burn 烧字幕/贴纸）
```

**Agent 侧同一条链**：`project_agent_chat:318` → `capability_dispatcher.invoke:169` → `EditorCapabilityHandlers:308` → 上述 `agent_*` 方法。

## 43. 生成主链（含闭环，11 个切片参与）

```
① 需求      有素材? agent_pipeline_router:93 → EDITING / GENERATION
② 任务入队  canvas_gen_jobs 提交（并发 3，可取消：取消必须丢弃结果 :452-453）
③ 选渠道    provider_caps.supports:195 海选 → resolve_order:229（V = q̂ − λ·price）
            provider_pool.pick:212（tier 降序 → 配额未扣完 → last_used 升序）
④ 选模式    execution_modes.score_modes:81（V 含 κ_sw 切换惩罚）→ project_feasible:136 → choose_mode:160
⑤ 分歧探针  divergence_probe.estimate:227（D 模式候选筛选，成本上限 2%）
⑥ 执行      成功 → quality_prior.record:107（EMA 更新 q̂ 与方差）
            失败 → provider_pool.report_failure:414（退避 60·2^(fails-1) 封顶 1800s）
                 → degradation.classify_error:66 → 判定级别（0~6）
⑦ 预算闭环  budget_pacer.record_spend:179（30s 一拍 PI 调 λ^τ）
            global_price.record_spend:343（60s 一拍 PI 调 λ^G，单步限幅 0.1）
⑧ 质检      守护规则层（道具/角色/表情/TTS）→ guard_pipeline.augment_inspection:243
⑨ 打分      five_dimension_scorer（visual .25 / narrative .25 / copy .20 / bgm .15 / duration .15）
⑩ 回写      score_book.record:133 → 下次同风格由 guard_pipeline.enhance_prompt:88 查高分组合
⑪ 抽检      sampling_review.should_sample:160（p 自适应；新版本/新题材强制 1.0）
            → prescreen:209 出风险等级 → 人工复核 → submit_human_label:311
            → 残差漂移 mean>0.30 冻结闭环 :330-362
```

## 44. Agent 主链

```
用户输入 / 画布工具调用
  → project_agent_chat:318
  → agent_loop.run:241（ReAct ≤12 轮 / ≤24 工具）
      ├ 每轮 compress_messages:328 压上下文（context_budget 定预算）
      ├ 工具调用 → parse_canvas_tools:79
      │    ├ 只读 → agent_runtime.dispatch_canvas_tools:196 并发（max 3）
      │    └ 写   → 串行 + agentPolicy 三档（plan / collaborative / autonomous）
      └ capability_dispatcher.invoke:169
           ├ agent_policy.decide:124（DENY / REQUIRE_APPROVAL）
           ├ handler 执行（盖 Agent 章）
           ├ agent_brain.activate（神经元 +0.7 扩散 / Hebbian ±Δ）
           └ memory_store.record（trace，失败 score 0.8 > 成功 0.5）
  → 结果回流为 user 消息 → 下一轮
  → agent_proactive.suggest_next_actions:95 追加"下一步"建议
```

## 45. 画布 ↔ 编辑器往返

```
编辑器 → 画布：agent_send_selected_to_canvas:8221 / _on_send_clip_to_canvas:4526
              → editor_canvas_link.stamp_clip:31（盖章）
              → 画布侧 bindShotlistFrame / fillStoryboardCell
画布 → 编辑器：projectZip.pushTimelineToEditor:300 或 /host/timeline-snapshot
              → agent_replace_timeline_clips:8083（整段持锁原子替换）
              → _on_copywriting_received:4364 / _on_material_dropped:4449（旁路入口）
事件流：       canvas_server SSE /host/agent/events:435（环形缓冲 maxlen=200 支持断线补发）
              → AgentPanel.subscribeAgentEvents:1884
              → 回执 sendAgentReply:1937 POST /host/agent/reply
```

---

# 第六篇 工程约束与铁律

## 46. 复杂度与算力铁律

> 源自《异构动态协作引擎规格书》第十三篇 §69，已在项目中作为设计红线。

1. **核心调度与控制器必须 O(1) ~ O(log n)**。全局路由打分、影子价格更新、资源仲裁**禁止大模型推理**。
2. **算力严格分层**：
   - O(1) 数值计算：路由收益、PI 更新、可行集投影、配额重分配（核心路径）
   - 允许小模型：DAG 解析分解、B 模块多级质量评分
   - 禁止进入核心链路：全模态大模型
3. **优化器只能重分配资源，无法突破物理下界**：端到端时延 ≥ DAG 关键路径各单元累加；Token 成本 ≥ 每单元至少一路推理的基础输入量。
4. **代理指标失真必然导致闭环反向优化**：机器评分只是低成本观测代理，必须永久保留「多指标加权 + 周期人工抽检校正 + 误差超限自动冻结闭环 + 人工强制否决通道」四件套。
5. **AI 打分永远不能作为真值**参与闭环更新；只有人工确认标签才允许校正评分权重与质量先验库。

## 47. 编码纪律（铁律清单）

| # | 纪律 | 违反后果 |
|---|---|---|
| 1 | 时间线真相源只认 `EditorModule._clips`，勿往 `AppState` / 孤儿 `ExportRenderer` 写 | 数据进黑洞 |
| 2 | `_clips` 跨线程 ⇒ ① 整段替换必须持锁 ② 序列化用 `_clips_snapshot()` ③ 锁是 RLock | 竞态 / 崩溃 |
| 3 | Agent 常量走 `app/core/agent_constants.py`（`STATUS_*` + `ERR_WAITING_APPROVAL`），**禁裸字符串** | 状态机错乱 |
| 4 | 能力元数据唯一来源 = `agent_capability_catalog.py`；新增能力唯一入口 = 目录表加一行 | `verify_catalog_consistency()` 报错 |
| 5 | 两套插件系统别被同名类迷惑；注册表 id 用 `extensions` | 接错线 |
| 6 | 两套独立版本号（主程序 / 画布）刻意不同步；改画布版三件套：`canvasVersion.ts` → `package.json` → CHANGELOG | 版本漂移 |
| 7 | 内联样式是主题盲区：每新增 `setStyleSheet` 内联控件必须回 `set_theme()` 补刷新 | 深/浅色下看不清 |
| 8 | 静默 except 判定线：UI 绘制 `pass` 可接受；状态机 / 资源路径 `pass` 不可接受（须 `logger.debug(..., exc_info=True)`）。例外 `except RuntimeError: pass` 有意保留 | 故障被吞 |
| 9 | 音画纠偏 ~280ms 是冻结区，**勿压回 80ms** | 音画不同步 |
| 10 | 沙箱 / 受限环境下 `import app` 链会触发 wmic；验证脚本用 subprocess 包一层 | 被安全策略拦截 |
| 11 | 清理临时文件**禁用 `_*` 等宽 glob**；必须显式列名单 + 先 `git ls-files` 区分项目自有 / 本次新建 | **误删项目文件** |
| 12 | 冻结区改动必须先「解冻 `<zone-id>`」，改完同步 4 处 | 守卫 exit 1 |

## 48. 守卫体系（三层门禁）

| 守卫 | 脚本 | 管什么 | 触发 |
|---|---|---|---|
| 冻结区 | `scripts/frozen_zone_guard.py:167` | 9 zone / 85 锁点的哈希 | 无参即校验；漂移 exit 1 |
| 稳定性 | `scripts/stability_gate.py:250` | bare-except / swallow-except / print-statement / undefined-name | 基线 `docs/knowledge/stability_gate_baseline.json:34` |
| 架构 | `scripts/arch_guard.py:366` | 分层黑白名单（`:22-46`） | 可挂 pre-commit |
| 一致性 | `_verify/run_all_checks.py` | 22 项一致性 / 冒烟 | 手动或 CI |
| 目录一致性 | `agent_capability_catalog.verify_catalog_consistency():254` | 目录 ↔ 注册双向对齐 | 启动自检 / 测试 |

**启动自检三项**（`capability_handlers.py:1549-1600`）：目录一致性 / action 映射一致性 / 脑同步。

---

# 附录A 术语词典

| 术语 | 定义 | 出处 |
|---|---|---|
| **真相源** | 唯一权威的状态所有者；本项目即 `EditorModule._clips` | §15 |
| **冻结区** | 哈希锁保护的代码区域，未解冻禁改 | §17 |
| **zone / 锁点** | 冻结区单元 / 被哈希的具体目标（symbol / file / marker） | §17 |
| **mixin 拆分** | 把巨型类按功能切成多个 mixin 文件，用 AST 精确搬运 | §13.1 |
| **ABCD 矩阵** | 剧情 / 情绪 / 视觉 / 爆款 四维融合的高光提取算法 | §22 |
| **edge-gap** | 卡片边缘间距（非中心距）作为磁吸判据 | §30.1 |
| **Bond / 咬合** | 两卡边贴边（≤2px）且投影重叠 ≥40px 的几何关系 | §30.2 |
| **三段式手感** | 30px 内不动 / 30~50px 让 28% / ≥50px 脆断 | §30.3 |
| **reflow / 让位** | 落位时整链推一格给新卡腾位 | §30.4 |
| **孤儿（锚定）** | 词锚定中指纹匹配不确定的台词，宁可标孤儿不错配 | §25 |
| **分歧度 Δ** | 本地与云端输出的差异量化，仅用于筛 D 模式 | §35.4 |
| **影子价格 λ** | 质量与成本之间的实时兑换率；λ 越大越省成本 | §35.2 |
| **可行集投影** | 硬约束只删不可行选项、不改打分 | §35.5 |
| **六级降级** | 双路→云端→质量→功能→部分交付→本地占位 | §35.9 |
| **冷启动不确定度** | 新版继承均值 + 放大 4 倍方差 | §35.10 |
| **抽检残差** | 人工真值与 AI 打分之差；均值 >0.30 冻结闭环 | §35.6 |
| **未接线** | 模块已实现并验证，但生产链路无调用点 | §0.2 |
| **占位实现** | 源码自述为模拟 / 演示的算法 | §29.4 |

# 附录B 模块速查索引

## B.1 按「我要改什么」定位

| 需求 | 入口文件 |
|---|---|
| 加一个 Agent 能力 | `app/core/agent_capability_catalog.py`（加一行）+ `capability_handlers.py`（写 handler） |
| 加一个工具按钮 | `app/modules/lego/editor_ui_builder_mixin.py`（建 UI）+ `editor_ux_commands.py`（绑指令） |
| 加一个时间线操作 | `app/modules/lego/editor_module.py` 的 Agent 接口层（8053–8430） |
| 加一个转场/特效插件 | `app/plugins/transition_*.py`（实现 `ITransitionPlugin`） |
| 加一个画布节点 | `vendor/shiguang-canvas/src/stores/node-factory.ts`（kind）+ 对应 `*Nodes.tsx` |
| 改磁吸手感 | `vendor/shiguang-canvas/src/magnetic/useMagneticDrag.ts`（**冻结区，需先解冻**） |
| 改选路 / 预算策略 | `app/core/ai/provider_pool.py` / `budget_pacer.py` / `execution_modes.py` |
| 加守护规则 | `app/core/ai/guard_pipeline.py` + 对应 `*_guard.py` |
| 改云端厂商 | `app/modules/lego/cloud_providers/providers.py` |
| 改导出预设 | `app/modules/lego/editor_module.py`（5736–6098 段） |

## B.2 模块规模 TOP 20（改动前先看体量）

| 排名 | 文件 | 行数 |
|---|---|---|
| 1 | `app/modules/lego/editor_module.py` | 9,717 |
| 2 | `vendor/shiguang-canvas/src/Stage3D.tsx` | 4,660 |
| 3 | `vendor/shiguang-canvas/src/riggedHumanoid.ts` | 3,706 |
| 4 | `app/core/canvas_server.py` | 3,273 |
| 5 | `vendor/shiguang-canvas/src/CanvasShell.tsx` | 3,199 |
| 6 | `app/modules/lego/canvas_aigc.py` | 2,905 |
| 7 | `app/modules/lego/settings_module.py` | 2,823 |
| 8 | `app/modules/lego/video_processor.py` | 2,732 |
| 9 | `vendor/shiguang-canvas/src/store.ts` | 2,452 |
| 10 | `app/modules/lego/editor_agent_panel_mixin.py` | 2,330 |
| 11 | `app/modules/lego/extensions_module.py` | 2,198 |
| 12 | `app/modules/lego/drama_understanding_engine.py` | 2,160 |
| 13 | `vendor/shiguang-canvas/src/bridge.ts` | 1,976 |
| 14 | `app/core/video_processing/mlt_engine_cpp.py` | 1,901 |
| 15 | `vendor/shiguang-canvas/src/App.tsx` | 1,896 |
| 16 | `app/modules/lego/modules.py` | 1,612 |
| 17 | `app/core/capability_handlers.py` | 1,600 |
| 18 | `app/modules/lego/main_window.py` | 1,512 |
| 19 | `app/core/preview_manager.py` | 1,492 |
| 20 | `vendor/shiguang-canvas/src/AgentPanel.tsx` | 1,469 |

## B.3 分层文件数速查

| 区域 | 文件数 | 行数 |
|---|---|---|
| `app/core`（含子目录） | 178 | 81,007 |
| ├ app/core 顶层 | 116 | — |
| ├ app/core/ai | 41 | — |
| ├ app/core/neural | 6 | — |
| └ app/core/video_processing | 11 | — |
| `app/modules`（含 lego） | 99 | — |
| ├ lego | 87 | — |
| `app/plugins` | 21 平铺 + ai_effects_plugin 包 | — |
| `vendor/shiguang-canvas/src` | 90+ | — |
| `scripts` | 35 | — |
| `_verify` | 63+ | — |

# 附录C 规模基线与版本

## C.1 版本

| 组件 | 当前版本 | 单一事实来源 | 同步要求 |
|---|---|---|---|
| 主程序 | **4.38.5** | `app/version.py:13` | 改代码须同步 `docs/CHANGELOG.md` |
| 画布 | **0.3.0**（代号「白模动作录制」） | `vendor/shiguang-canvas/src/canvasVersion.ts:22` | 三件套：本文件 → `package.json` → CHANGELOG |

**两套版本刻意不同步、各自递增**（`canvasVersion.ts:4-8` 注释；已上升为冻结不变量 `frozen_zones.json:347`）。

## C.2 近期里程碑（本说明书覆盖范围）

| 版本 | 内容 |
|---|---|
| V4.32.x | AI 四守护集齐（角色 / 表情 / 道具 / TTS）+ 守护深度优化 + 挂进生成管线 |
| V4.33.5 | 补管线三缺口（TTS 挂配音 / 质检节流 / 自动装配） |
| V4.34.0 | Agent UI 重设计第一步（治主题盲区 + 头部瘦身） |
| V4.35.0 | 生成链路三件套（能力路由 + 额度池 + 评分回写） |
| V4.37.x | 切片⑤ 执行模式、⑥ 分歧探针、⑨ 抽检 |
| V4.38.x | 切片⑦ 融合器、⑧ 全局价格、⑩ 模块调度、⑪ 仿真器、⑫ 引擎门面 |
| 画布 0.3.0 | 白模动作录制（刀4 帧采集编排） |

## C.3 本文的核查方式（可复现）

| 结论类别 | 取证手段 |
|---|---|
| 行号 / 符号 | `Read` 实际读取 + `wc -l` 实测 |
| 常量 / 公式 | 直接摘录源码表达式，非转述 |
| 接线状态 | `grep` 调用点行号；无调用点即标「未接线」 |
| 冻结区 | `frozen_zones.json` + `frozen_zones.hashes.json` 交叉 |
| 同名混淆 | 双处 `class` 定义行号并列 |

---

> **文档状态**：v1.0，对应工作区 2026-09-23 快照。如需任一章展开为逐行精读，或导出为纯 Markdown 无表格版本，另行说明。
> **维护约定**：架构 / 活路径 / 优先级变更统一写回 `docs/现行技术文档.md`；本文件属调研报告（`docs/_reports/`），随代码演进需重新取证。
