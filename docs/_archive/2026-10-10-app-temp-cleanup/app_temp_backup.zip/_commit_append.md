
## git 历史补提交（06:00 - 06:45）· 10 个语义提交落地

用户批准「把这 9 天的改动分次提交固化」后执行。**先体检再动手**，这一步拦下了三个雷。

### 提交前体检

- **远端 = 公开仓库** `https://github.com/1949King/shiguangjianying.git` ⇒ 必须按"会被 push"的标准查机密
- 敏感扫描：`app/data/active_provider.json`、`store/installed.json`、`items.json`、`plugin_config.json`、冻结区 json —— **全部干净，无密钥**
- 大文件：M+?? 里 **>2MB 的 0 个**
- `node_modules` 未写进根 `.gitignore`，但 `vendor/shiguang-canvas/.gitignore` 与 `AI-Canvas-tauri/.gitignore` 已各自挡住 ⇒ `??` 中 node_modules 命中 **0**，无需改忽略规则
- 发现 **4 个 0 字节怪文件**（`日期：2026-09-20`、`来源：Hypit`、`调研日期：2026-09-20`、`口径：…`）—— 应是写报告时 heredoc/重定向失误的产物，**未提交、未删除，留给处置**
- git 身份：`user.name=1949King`，`user.email=您的GitHub邮箱@xxx.com`（**占位符，没改**，属用户配置）

### 最终历史（全部本机，未 push）

| 提交 | 说明 | 文件数 |
|---|---|---|
| `06ac8ae0` chore(config) | 忽略规则 / CI / ruff / 冻结区规则 | 10 |
| `39e4cca6` chore(vendor) | 移除 openshot 三方参考树 | 7309 |
| `a7a93d1c` chore(clean) | 下线模块 + 旧编辑器合并 + 根临时产物 | 114 |
| `76285684` feat(core) | Agent 体系 + AI 四守护管线 | 72 |
| `114528ac` feat(editor) | 编辑模块 + Qt6 主窗口 | 42 |
| `44aff2f4` feat(plugins) | 转场插件 + 测试 + 版本 | 24 |
| `3b6c8913` feat(canvas) | 磁吸 / 新手模式 / Studio | 55 |
| `08f9759c` docs | 知识库归档 + 技术报告 | 102 |
| `0ac767cf` chore(verify) | _verify 校验脚本 | 64 |
| `5809fa32` chore(clean) | 补提散落删除（分类器漏的根目录项） | 54 |

**已用 `--numstat` 逐提交复核：无 node_modules / `__pycache__` / `dist` / `db` 混入。**

### 过程里的三次翻车（都记进教训了）

1. **v1 跨批污染**：v1 有 5 批因"路径被 .gitignore 忽略"而 `git add` 失败；更糟的是失败的批次把内容留在暂存区，下一批 `commit` 一次吞下 7513 项，导致标着 "feat(core)" 的提交实际装着 openshot 的 6964 个删除。⇒ `reset --mixed` 回滚重来。
2. **v2 用 `-f` 强行闯关**：成功提交了，但 `-f` 穿透了 `vendor/shiguang-canvas/.gitignore`，**6462 个 node_modules + 大量 pyc/dist/glb 进了 `6fd9f834`**（+236 万行）。⇒ 二次回滚。
3. **v3 慢 + v4/v5 代码 bug**：v3 逐文件调 `check-ignore`（7856 次子进程）17 分钟无输出被杀；v4 分类那行写成 `(groups[g] if g else None) and groups[g].append(p)`，空列表假值 ⇒ append 永不执行 ⇒ 全部分组为空；v5 又被沙箱**每轮 50 次删除**的闸门拦（脚本每批都要删临时清单文件）。⇒ v6 改为「精确文件清单 + 无 -f + 临时文件写系统 temp + 污染剔除闸门」，一次跑完。

### 收尾状态

- `git status` 最终只剩 **4 个 0 字节怪文件**（故意留下待处置）
- 本轮的临时脚本已挪到 `app/temp/`（该目录已被忽略），并在 `.git/info/exclude` 加了对应模式
- **副产物（要坦白）**：`app/modules/lego/*.bak_before_debug_removal` 那 4 个调试前备份（共 ~610KB，其中 editor_module 备份 446KB）被 editor 批次**带进了历史**。原本想排除，分类器按 `app/modules/**` 把它们一并划过去了。
- **`.git` 体积 2893.5 MB**（历史里含 openshot 的 322 万行删除 + 早期 initial commit 的内容），尚可优化
- 本文件(MEMORY.md)在 docs 批之后又被我编辑了一次，现在是 1 处待提交的小改动
