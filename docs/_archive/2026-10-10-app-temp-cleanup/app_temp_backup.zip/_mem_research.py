# -*- coding: utf-8 -*-
"""写记忆。"""
import io
import os

MEM = r"D:\拾光剪影\.workbuddy\memory\2026-09-26.md"
NOTE = """
## 开源借鉴与依赖升级路线调研（01:52 - 02:25）

用户问：「GitHub 上有哪些开源项目值得借鉴参考 / 功能最匹配？哪些功能、驱动、依赖可以升级？」
产出 `docs/_reports/2026-09-26-开源借鉴与依赖升级路线.md`。

### 方法：先读本机真实版本，再查外部最新进展（不靠印象）

### 结论：值得动的 5 件事（按 ROI）
1. **FFmpeg essentials → full build**（成本最低、收益直接）
2. **ComfyUI 改用 0.35.0**（当前配置会选到旧的 0.3.40）
3. **numpy 2.x 连锁解锁**（numba≥0.65 + librosa 1.0）— 需回归
4. **Agent 补 Self-Eval + probe-first**（借鉴 video-use / ffmpeg-skill）
5. 前端 vitest/vite major 跳跃 —— 已评估**不做**（判断正确）

### 🔴 最重要发现：numpy「钉死」的理由已失效

**依赖链真相**（实测）：
```
librosa 0.11.0  ← 项目 4 处使用（audio_emotion_analyzer:33,34 / local_asset_manager:263 / smart_editing_engine:597）
   └─ numba 0.64.0  ← 项目 **0 处直接 import**（纯传递依赖，pip show 显示 Required-by: librosa）
        └─ numpy <2.1  ← 这才是 numpy 被钉死在 1.26.4 的**唯一原因**
```
**约束已失效**：numba 0.67.0（2026-08-11）**支持 NumPy 2.5**，依赖声明只剩 `numpy>=1.22`；
而 **librosa 1.0.0（同一天）强制 `numpy>=2.1.0`** ⇒ 升级 librosa 反而**倒逼** numpy 升级。

**前置条件 10/11 已满足，只差 numpy**：
python 3.12.10 ✅ · scipy 1.17.1 ✅ · scikit-learn 1.9.0 ✅ · soundfile 0.14.0 ✅ ·
**soxr 1.1.0 ✅（已装）** · joblib/pooch/lazy-loader/msgpack ✅ ；numpy 1.26.4 ❌

**破坏性变更（必须回归）**：librosa 1.0 的 `amplitude_to_db`/db 行为变化**会影响 MFCC** ⇒
`audio_emotion_analyzer.py` 最需回归；另移除 audioread 后端、sparse matrix→array、
`constant_q`→`wavelet`、`random_state`→`rng`、`x_axis`→`axis`。

### FFmpeg：不是"要不要升"，是"换掉 essentials"
本机已是 **8.0.1**，但是 **gyan.dev essentials** build ⇒ 缺 `af_whisper`（FFmpeg 内 ASR）、
`scale_vulkan/h264_vulkan/av1_vulkan`、`libplacebo`、`opencl`。
已有：`nvenc/cuda/vaapi/libvmaf` + 滤镜 `colordetect/pad_cuda/scale_cuda/scale_d3d11/ebur128`。
**项目里早有 `install_ffmpeg_btbn.ps1`**（BtbN 通常是 full）⇒ 路子早就准备好，只是没落地。

### ComfyUI：两份版本差很多，而当前会选错
| 位置 | 版本 | int8 量化 | 自带解释器 |
|---|---|---|---|
| 秋叶包（桌面） | **0.3.40（旧）** | ❌ | ✅ |
| `D:\_comfy_compare\ComfyUI` | **0.35.0（新）** | ✅ 有 `comfy/quant_ops.py` | ❌ |

⚠️ **缺陷**：昨天修的 `_find_engine_dir()` 策略是「优先返回自带解释器者」⇒ **恰好选中旧的 0.3.40**。
**建议改法**：先筛「能拉起」，再在其中选「版本最高」。
可用的新特性：Dynamic VRAM（默认开）· int8 量化（v0.27+，需 Turing+，4060 是 Ada 可用）·
**Seed 节点（可复现，对齐项目"拒绝随机"偏好）** · LTX2/Krea2 视频模型 · Desktop 多实例/快照 ·
jobs API text preview。

### 借鉴项目
- **`browser-use/video-use`（24.5K★）**：`Transcribe → Pack → LLM Reasons → EDL → Render → **Self-Eval**`；
  核心是「**LLM 不『看』视频，而是『读』视频**」（`takes_packed.md` 作阅读界面）。
  ⚠️ **本项目 `app/skills/external/video-use/` 已经引入了它**！已有对应物：`timeline_source.py`（工程源码层）
  + `dialogue_anchor.py`（词锚定）+ `filler_silence_detect.py`。**缺的正是最后一环 Self-Eval。**
- **`ffmpeg-skill`（510+★）**：强制四段 `probe → edit → check → verify` + **28 工具全 MCP 化**。
  项目有对应能力，但**缺"先 probe 再决定无损/重编码"的强制工作流**，且能力未 MCP 化。

### 本轮三处自我纠正（都是"先怀疑、后实测、再纠正"）
1. 怀疑 venv 3.13 与 `.pyd` cp312 ABI 不匹配 ⇒ **实测 venv 是 3.12.10，C++ 引擎 `CPP_ENGINE_AVAILABLE=True` 正常**（3.13 是我跑脚本用的托管运行时）
2. 以为 numpy 钉死是多库联合约束 ⇒ 实为单链 librosa→numba→numpy，且**已失效**
3. 怀疑前端补丁没落盘（package.json 还是旧范围）⇒ **lock 解析为 12.11.6/19.3.0/5.0.15，与文档一致**

### 未调研（如实标注）
MLT 版本 · PyQt6 上游最新（本机 6.10.2 / WebEngine 6.10.0）· CUDA/NVENC 驱动侧 · @xyflow 13 是否存在 · 国内 provider 最新能力
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "开源借鉴与依赖升级路线" in b:
    print("已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("已写入 -> %d bytes" % os.path.getsize(MEM))
