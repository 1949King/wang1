# -*- coding: utf-8 -*-
"""盘点 3D 舞台导出链路 + 片头/封面相关实现"""
import io
import os
import re
import json

SRC = r"D:/拾光剪影/vendor/shiguang-canvas/src"
out = {}

targets = {
    "localLibrary.ts": r"片头|封面|开场",
    "Stage3D.tsx": r"导出|export (?:async )?function|renderPoseVideo|poseVideo|白模|renderer\.render",
    "stage3dPoseVideo.ts": r"export (?:async )?function|fetch\(|/host/",
}

for f, pat in targets.items():
    fp = os.path.join(SRC, f)
    if not os.path.isfile(fp):
        out[f] = "MISSING"
        continue
    lines = io.open(fp, encoding="utf-8", errors="replace").read().split("\n")
    hits = [(i + 1, ln.strip()[:120]) for i, ln in enumerate(lines) if re.search(pat, ln)]
    out[f] = {"total_lines": len(lines), "hits": hits[:40], "hit_count": len(hits)}

# 后端：3D 相关端点与导出
sp = r"D:/拾光剪影/app/core/canvas_server.py"
s = io.open(sp, encoding="utf-8", errors="replace").read()
out["canvas_server_stage3d"] = [(i + 1, ln.strip()[:140])
                                for i, ln in enumerate(s.split("\n"))
                                if re.search(r"stage3d|pose-video|pose_video|白模|intro", ln, re.I)][:30]

with open(r"D:/拾光剪影/app/temp/_stage3d.json", "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
print("OK")
