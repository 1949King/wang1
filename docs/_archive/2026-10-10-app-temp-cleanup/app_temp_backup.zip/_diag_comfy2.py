# -*- coding: utf-8 -*-
"""核实两份 ComfyUI 安装的可运行性（代码会找 python_embeded / venv）。"""
import io
import os

CANDS = [
    r"D:\_comfy_compare\ComfyUI",
    r"C:\Users\Administrator\Desktop\ComfyUI-aki-v1.7\ComfyUI",
]

for d in CANDS:
    print("=" * 74)
    print("① %s" % d)
    print("=" * 74)
    if not os.path.isdir(d):
        print("  ❌ 目录不存在")
        continue
    checks = [
        ("main.py", os.path.join(d, "main.py")),
        ("nodes.py", os.path.join(d, "nodes.py")),
        ("python_embeded/python.exe", os.path.join(d, "python_embeded", "python.exe")),
        ("venv/Scripts/python.exe", os.path.join(d, "venv", "Scripts", "python.exe")),
        (".venv/Scripts/python.exe", os.path.join(d, ".venv", "Scripts", "python.exe")),
        ("models/", os.path.join(d, "models")),
        ("custom_nodes/", os.path.join(d, "custom_nodes")),
    ]
    for label, p in checks:
        kind = "目录" if os.path.isdir(p) else ("文件" if os.path.isfile(p) else "—")
        mark = "✅" if kind != "—" else "❌"
        extra = ""
        if os.path.isdir(p) and label in ("models/", "custom_nodes/"):
            try:
                extra = " (%d 项)" % len(os.listdir(p))
            except OSError:
                pass
        print("  %s %-28s %s%s" % (mark, label, kind, extra))
    # 顶层同级目录（整合包通常在上一层放 python_embeded）
    parent = os.path.dirname(d)
    print("  --- 上一级 %s 的关键项：" % parent)
    try:
        for e in sorted(os.listdir(parent))[:14]:
            print("       %s" % e)
    except OSError:
        pass
    print()
