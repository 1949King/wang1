# -*- coding: utf-8 -*-
"""确认拟升级涉及的画布文件是否在冻结区"""
import io
import json
import re

P = r"D:/拾光剪影/docs/knowledge/frozen_zones.json"
d = json.loads(io.open(P, encoding="utf-8").read())

zones = d.get("zones") or d
targets = ["store.ts", "nodes.tsx", "node-factory.ts", "mediaExtraNodes.tsx",
           "storyNodes.tsx", "Stage3D.tsx", "canvas_bridge.py", "canvas_server.py",
           "character_management_module.py", "director_skill.py",
           "video_editing_skill.py", "canvas_aigc.py", "agent_capability_catalog.py"]
hits = {}
for z in (zones if isinstance(zones, list) else zones.values()):
    zid = z.get("id") or z.get("zone") or "?"
    files = z.get("files") or z.get("paths") or []
    if isinstance(files, dict):
        files = list(files.keys())
    for f in files:
        base = str(f).replace("\\", "/").rsplit("/", 1)[-1]
        for t in targets:
            if base == t:
                hits.setdefault(t, []).append(zid)

print(json.dumps(hits, ensure_ascii=False, indent=1))
print("zones:", len(zones) if isinstance(zones, list) else len(zones))
