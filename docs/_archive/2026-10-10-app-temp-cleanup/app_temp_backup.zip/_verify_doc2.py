# -*- coding: utf-8 -*-
"""检查文档内是否混入 shell 报错文本 / 非预期内容。"""
import io, re

P = r"D:\拾光剪影\docs\_reports\2026-09-23-拾光剪影-架构与算法规格说明书.md"
s = io.open(P, encoding="utf-8").read()
L = s.splitlines()

BAD = ["command not found", "syntax error", "No such file or directory",
       "bash.exe", "PortableGit", "shim", "dirname"]
print("=== 疑似 shell 报错文本 ===")
hit = False
for i, l in enumerate(L, 1):
    for b in BAD:
        if b in l:
            print("  L%-5d %s" % (i, l[:120]))
            hit = True
            break
if not hit:
    print("  （无）")
print()

print("=== 最长 5 行（异常长行 = 可能被拼接）===")
idx = sorted(range(len(L)), key=lambda i: -len(L[i]))[:5]
for i in sorted(idx):
    print("  L%-5d %d 字符 | %s" % (i + 1, len(L[i]), L[i][:80]))
print()

print("=== 章节连续性检查（应 21..41 单调）===")
nums = [int(m.group(1)) for l in L for m in [re.match(r"^## (\d+)\.", l)] if m]
print("  编号小节序列:", nums)
gap = [b for a, b in zip(nums, nums[1:]) if b != a + 1]
print("  不连续处:", gap if gap else "（连续）")
print()

print("=== 每篇行数分布 ===")
marks = [(i, l) for i, l in enumerate(L) if l.startswith("# ")]
for k, (i, l) in enumerate(marks):
    end = marks[k + 1][0] if k + 1 < len(marks) else len(L)
    print("  %-28s %4d 行" % (l[2:28], end - i))

tot = sum(os.path.getsize(P) for os in [__import__("os")]) if False else None
import os
print()
print("字节 %d / 行 %d / 字符 %d" % (os.path.getsize(P), len(L), len(s)))
