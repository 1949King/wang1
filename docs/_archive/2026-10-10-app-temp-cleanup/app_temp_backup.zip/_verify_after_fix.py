# -*- coding: utf-8 -*-
"""修复后验证：编译 / 契约等价性 / 冻结区 / 项目自带守卫 / 改动抽样。"""
import io
import os
import re
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable

MODIFIED = [
    "app/core/canvas_agent_runtime.py",
    "app/core/local_video_infer.py",
    "app/modules/lego/editor_agent_runtime_mixin.py",
    "app/core/project_agent_host.py",
    "app/core/ai/video_generation_client.py",
    "app/modules/lego/model_management.py",
    "app/core/preview_manager.py",
    "app/modules/lego/playback_shuttle.py",
    "app/main_qt6.py",
]

print("=" * 74)
print("① 编译校验（9 个改动文件）")
print("=" * 74)
bad = []
for rel in MODIFIED:
    p = os.path.join(ROOT, *rel.split("/"))
    body = io.open(p, encoding="utf-8-sig").read()
    try:
        compile(body, p, "exec")
        n = len(re.findall(r"忽略异常（原为 pass）", body))
        print("  ✅ %-46s 新增日志 %d 处" % (rel, n))
    except SyntaxError as e:
        bad.append((rel, e))
        print("  ❌ %-46s %s" % (rel, e))
print()

print("=" * 74)
print("② 改动抽样（证明改的是 pass → logger.debug，未动逻辑）")
print("=" * 74)
p = os.path.join(ROOT, "app", "core", "canvas_agent_runtime.py")
L = io.open(p, encoding="utf-8-sig").read().splitlines()
for i, l in enumerate(L, 1):
    if "忽略异常（原为 pass）" in l:
        for k in range(max(0, i - 4), min(len(L), i + 1)):
            mark = ">" if k == i - 1 else " "
            print("  %s L%-5d %s" % (mark, k + 1, L[k]))
        print()
        break

print("=" * 74)
print("③ 契约等价性守卫（改完必须仍全绿）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_glue_contract.py")],
                   cwd=ROOT, capture_output=True)
out = r.stdout.decode("utf-8", "replace")
tail = [l for l in out.splitlines() if "汇总" in l or l.strip().startswith("❌")
        or "合计" in l or "[needs_log" in l]
print("  exit=%d" % r.returncode)
for l in tail:
    print("  %s" % l)
print()

print("=" * 74)
print("④ 冻结区守卫（我没碰冻结区，必须仍全绿）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "frozen_zone_guard.py")],
                   cwd=ROOT, capture_output=True)
o, e = r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")
print("  exit=%d" % r.returncode)
for l in (o + e).splitlines()[-12:]:
    print("  %s" % l)
print()

print("=" * 74)
print("⑤ 项目自带稳定性门禁（确认没引入新违规）")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "stability_gate.py")],
                   cwd=ROOT, capture_output=True)
o, e = r.stdout.decode("utf-8", "replace"), r.stderr.decode("utf-8", "replace")
print("  exit=%d" % r.returncode)
for l in (o + e).splitlines()[:25]:
    print("  %s" % l)
print()

print("=" * 74)
print("⑥ 全局静默异常复测")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_glue_contract.py"), "--scan"],
                   cwd=ROOT, capture_output=True)
o = r.stdout.decode("utf-8", "replace")
for l in o.splitlines():
    if "合计" in l or "待补日志" in l or "[needs_log" in l:
        print("  %s" % l)
