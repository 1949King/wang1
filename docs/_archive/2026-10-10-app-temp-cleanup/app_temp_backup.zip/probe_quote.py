# -*- coding: utf-8 -*-
"""作品冲刺 Step0：真实渠道探测（只读，不花钱）。

跑三层报价（caps→pool→client）+ 渠道健康，回答「15s×3 段能不能云端生成」。
"""
import io
import os
import sys

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
sys.path.insert(0, ROOT)

from app.core.ai.video_generation_client import video_generation_client  # noqa: E402

# 15 秒作品 = 3 段 × 5 秒
q = video_generation_client.quote("auto", count=3, duration=5.0)
print("=== 15s 作品（3 段 × 5s）真实报价 ===")
for k in ("provider", "count", "cost_estimate", "currency", "price_per_clip",
          "account_id", "quota_remaining", "cloud_available", "dead_providers",
          "reason", "note"):
    print(f"  {k}: {q.get(k)}")

print()
print("=== 渠道清单 ===")
try:
    from app.core.ai.provider_caps import provider_caps  # noqa: E402
    for p in provider_caps.list_providers():
        print(f"  {p}")
except Exception as e:
    print(f"  provider_caps 清单失败: {e}")

print()
print("=== 额度池（账号视图） ===")
try:
    from app.core.ai.provider_pool import provider_pool  # noqa: E402
    pool_quote = provider_pool.quote("auto", count=3)
    for k, v in pool_quote.items():
        print(f"  {k}: {v}")
except Exception as e:
    print(f"  额度池查询失败: {e}")
