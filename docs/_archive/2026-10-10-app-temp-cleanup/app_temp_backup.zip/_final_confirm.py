# -*- coding: utf-8 -*-
"""双库收敛后的最终确认：官方双库校验 + 主仓四道守卫 + 分叉复测。"""
import hashlib
import io
import os
import re
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable
MAIN = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
SUB = os.path.join(ROOT, "vendor", "AI-Canvas-tauri", "src", "libtv")
SKIP = {"node_modules", "dist", "__pycache__"}


def files_under(base):
    out = {}
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css", ".json")):
                rel = os.path.relpath(os.path.join(dp, f), base).replace("\\", "/")
                out[rel] = os.path.join(dp, f)
    return out


def md5(p):
    return hashlib.md5(io.open(p, "rb").read()).hexdigest()


print("=" * 74)
print("① 双库分叉复测（收敛效果）")
print("=" * 74)
fa, fb = files_under(MAIN), files_under(SUB)
forked = [k for k in set(fa) & set(fb) if md5(fa[k]) != md5(fb[k])]
only_main = [k for k in fa if k not in fb]
print("  分叉: %d（收敛前 24）" % len(forked))
for k in sorted(forked):
    print("     %s" % k)
print("  仅主库有: %d（收敛前 19）" % len(only_main))
for k in sorted(only_main):
    print("     %s" % k)
print()

print("=" * 74)
print("② 官方双库校验脚本")
print("=" * 74)
p = os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")
if os.path.exists(p):
    r = subprocess.run([PY, p], cwd=ROOT, capture_output=True)
    out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
    print("  exit=%d" % r.returncode)
    for l in out.splitlines()[-18:]:
        print("  %s" % l)
else:
    print("  脚本不存在")
print()

print("=" * 74)
print("③ 主仓四道守卫")
print("=" * 74)
HOOKS = [("冻结区守护", "scripts/frozen_zone_guard.py", []),
         ("稳定性门禁", "scripts/stability_gate.py", []),
         ("粘合层契约", "_verify/check_glue_contract.py", []),
         ("架构守护", "scripts/arch_guard.py", ["--scan", "app"]),
         ("文件规模", "_verify/check_file_size.py", [])]
for name, rel, args in HOOKS:
    fp = os.path.join(ROOT, *rel.split("/"))
    if not os.path.exists(fp):
        print("  ⚠️  %-12s 脚本不存在" % name)
        continue
    r = subprocess.run([PY, fp] + args, cwd=ROOT, capture_output=True)
    out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
    first = out.splitlines()[0] if out else "(无输出)"
    print("  %s %-12s exit=%d  %s" % ("✅" if r.returncode == 0 else "❌", name,
                                      r.returncode, first[:88]))
print()

print("=" * 74)
print("④ 主仓工作区（本轮主仓改了哪些）")
print("=" * 74)
r = subprocess.run(["git", "-c", "core.quotePath=false", "status", "--porcelain", "-uall"],
                   cwd=ROOT, capture_output=True)
lines = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
print("  变更 %d 项:" % len(lines))
for l in lines:
    print("     %s" % l[:104])
