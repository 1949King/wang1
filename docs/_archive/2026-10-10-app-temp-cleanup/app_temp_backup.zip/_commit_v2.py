# -*- coding: utf-8 -*-
"""提交形象包 v2（大姐姐版）+ 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """feat(canvas): 形象包 v2 —— 从「小妹妹秘书」重构为「温柔知心大姐姐·拾岚」

用户批评（三处，全部成立）：
① 动作偏猛，与「温柔秘书」设定冲突
② 只推了「狐狸＝拾取」的动作同构，没检查狐狸这个符号自带的情绪色彩
   （机敏／警觉／野性）与「温柔」是否冲突
③ 没把「剪影」二字用起来 —— 剪影＝轮廓辨识度，而狐耳+蓬松大尾在小尺寸会糊

重构要点（刻意反着 v1 来）：
· 姿态：端坐不扭转、不前倾（v1 是单手伸臂去抓 + 身体扭转）
· 动作：右手轻扶眼镜（知性）+ 左手托一颗悬浮暖光点（v1 是向上接/抓光点）
· 狐耳：自然放松（v1 竖立＝警觉）
· 狐尾：盘落身侧、尾尖渐浅（v1 张扬翘起＝野性）
· 服装：丝缎改良立领 + 纱披肩 + 绣纹 + 腰系带流苏（v1 工装+厚底靴＝机能）
· 新增：细金丝圆框眼镜（知性）
· 背景设计：拱形窗+浅月+城市轮廓剪影 + 横贯的发光时间线光带（含节点光点）
  + 左屏蓝光 + 右暖橙台灯 + 热茶 + 纸笔（v1 背景较简单）
· 「剪影」落地：肩头与狐耳/尾缘的暖橙边缘光 ⇒ 深蓝底上形成剪影

角色更名：小拾 → 拾岚（"岚"＝山间薄雾；"小"字与"大姐姐"气质不符）
注册名：拾光·Q版兽耳娘形象包（小拾）→ 拾光·狐耳形象包（拾岚）

产出：4 条提示词全部改写为大姐姐版（主形象/表情三连/动态问候/画布协作场景）
+ assets/mascot/shilan-主形象卡-v2-大姐姐.png（v1 小妹妹版保留作设计过程记录）
双库同步：4 处 JSON 一致 + promptLibrary.ts 双侧字节一致；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 主仓待提交")
print("=" * 74)
rc, out, _ = git("-c", "core.quotePath=false", "status", "--porcelain", "-uall",
                 "--", "vendor/shiguang-canvas", "assets/mascot")
for l in [x for x in out.splitlines() if x.strip()]:
    print("   %s" % l[:104])
print()

print("=" * 74)
print("② 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psA.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "vendor/shiguang-canvas/src/promptLibrary.ts\n"
    "assets/mascot/shilan-主形象卡-v2-大姐姐.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgA.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("③ 提交副库")
print("=" * 74)
gt("add", "-A", "--", "src/libtv/promptLibrary.ts",
   "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M3.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "feat(libtv): 同步形象包 v2（拾岚·温柔大姐姐版）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致（promptLibrary.ts 字节一致）。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v2：从「小妹妹秘书」重构为「温柔知心大姐姐·拾岚」（01:23 - 01:45）

### 先结清一笔事实
用户一度说品牌是「时光剪影」。**实测：拾光剪影 363 处 / 时光剪影 0 处**
（含 `main_window.py:762` 窗口标题、关于页、隐私政策、用户服务协议、`QSettings` 组织名）
⇒ 用户确认「时光剪影」是**语音输入识别错误**，品牌就是**拾光剪影**。命名基础无误。

### 用户的三处批评（全部成立，我照单认）

| 批评 | 我的判断 |
|---|---|
| 狐狸贴不贴「拾光剪影」 | **动作上说得通，形象上有问题** —— 只推了动作同构，漏了气质同构 |
| 动作偏猛 vs 温柔秘书 | **判断准确**。猛的不是表情，是**姿态+服装+尾巴+竖耳四件套的组合** |
| （我自省出的第三条） | 没把「**剪影**」二字用起来 —— 剪影＝轮廓辨识度，狐耳+蓬松大尾在小尺寸会糊 |

### 我的设计错误（值得沉淀的教训）

**我在做「符号搬运」，没做「气质统一」。**
挑中"狐狸＝拾取"这个隐喻就往下走，**没停下检查"狐狸这个符号自带的情绪色彩
（机敏/警觉/狡黠/野性）跟'温柔秘书'冲不冲突"**。

⚠️ **可复用教训**：**选视觉符号前，必须先列出该符号在既有语汇里"自带的情绪色彩"，
再与目标气质逐项对照。** 只做"功能同构"（狐狸会拾取）不够，
还要做"气质同构"（狐狸让人想到警觉而非温柔）。

### v2 重构要点（刻意反着 v1）
- 姿态：端坐不扭转/不前倾 ← v1 单手伸臂去抓 + 身体扭转
- 动作：右手轻扶眼镜（知性）+ 左手托悬浮暖光点 ← v1 向上接/抓
- 狐耳：自然放松 ← v1 竖立（警觉）
- 狐尾：盘落身侧、尾尖渐浅 ← v1 张扬翘起（野性）
- 服装：丝缎改良立领 + 纱披肩 + 绣纹 + 腰系带流苏 ← v1 工装+厚底靴（机能）
- 新增：细金丝圆框眼镜（知性）
- 背景：拱形窗+浅月+城市剪影 + **横贯的发光时间线光带（含节点光点）** + 左屏蓝光 + 右暖橙台灯 + 热茶纸笔
- **「剪影」落地**：肩头/狐耳/尾缘的暖橙**边缘光** ⇒ 深蓝底上形成剪影（这次真的用上了品牌名的第二层）

角色更名：**小拾 → 拾岚**（"岚"＝山间薄雾；"小"与"大姐姐"不符）
注册名：拾光·Q版兽耳娘形象包（小拾）→ **拾光·狐耳形象包（拾岚）**

### 诚实标注的偏差（v2 图）
1. 狐耳未做到"一只微垂"（仍偏立），但表情与姿态放松，**整体不显警觉** —— 可接受
2. 头身比实测约 **4 头身**（要的是 3.5）—— 更贴"大姐姐"，代价是缩小到 48px 时辨识度下降
   （与"当图标"的要求有轻微张力）

### 双库
4 处 JSON 一致 + `promptLibrary.ts` 双侧**字节一致** ⇒ 双库校验仍 分叉 0 / 缺失 7。
（再次实证：改画布源码必须同步两侧，这是"双宿主双份维护"的真实成本。）
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v2" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
