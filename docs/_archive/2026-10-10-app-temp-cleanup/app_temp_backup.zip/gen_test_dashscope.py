# -*- coding: utf-8 -*-
"""真实生成测试：DashScope 万相 wan2.2-t2v-flash，1 段 5 秒 720p。"""
import io
import json
import sys
import time
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "app" / "core" / "ai"))

import dashscope_video as dsv

PROMPT = (
    "电影感镜头：清晨薄雾中的江南古镇石板巷，一位穿青色旗袍的年轻女子撑伞缓步走来，"
    "镜头缓慢推近，暖金色晨光穿过屋檐洒落，水面倒影微漾，写实风格，浅景深"
)

print("== 真实生成测试：wan2.2-t2v-flash / 5s / 1280x720 ==")
t0 = time.time()
try:
    paths = dsv.generate_videos(prompt=PROMPT, duration=5.0, count=1,
                                width=1280, height=720)
    dt = time.time() - t0
    print(f"成功 ✅ 耗时 {dt:.0f}s")
    for p in paths:
        size = Path(p).stat().st_size if Path(p).exists() else -1
        print(json.dumps({"path": p, "size_bytes": size}, ensure_ascii=False, indent=2))
except Exception as e:
    print(f"失败 ❌ 耗时 {time.time() - t0:.0f}s")
    print(f"{type(e).__name__}: {e}")
    sys.exit(1)
