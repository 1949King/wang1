# -*- coding: utf-8 -*-
"""盘点画布题材/角色相关资源与脚本节点"""
import io
import os
import json

ROOT = r"D:/拾光剪影/vendor/shiguang-canvas"
out = {}

# 1) prompt 包清单
pd = os.path.join(ROOT, "public", "prompts")
out["prompts"] = []
if os.path.isdir(pd):
    for e in sorted(os.listdir(pd)):
        p = os.path.join(pd, e)
        if os.path.isfile(p):
            out["prompts"].append([e, os.path.getsize(p)])
        else:
            for f in sorted(os.listdir(p)):
                fp = os.path.join(p, f)
                out["prompts"].append([e + "/" + f, os.path.getsize(fp) if os.path.isfile(fp) else -1])

# 2) shiguang-drama.json 概览
dp = os.path.join(pd, "shiguang-drama.json")
if os.path.isfile(dp):
    try:
        d = json.loads(io.open(dp, encoding="utf-8").read())
        items = d if isinstance(d, list) else d.get("items") or d.get("prompts") or []
        out["drama_count"] = len(items)
        out["drama_sample"] = []
        for it in items[:20]:
            if isinstance(it, dict):
                out["drama_sample"].append(
                    {k: it.get(k) for k in ("id", "name", "title", "category", "tags") if k in it})
    except Exception as ex:
        out["drama_err"] = str(ex)

# 3) 角色相关：store.ts 中的角色绑定 / 角色节点
st = os.path.join(ROOT, "src", "store.ts")
if os.path.isfile(st):
    s = io.open(st, encoding="utf-8", errors="replace").read()
    out["store_character_api"] = sorted(set(
        __import__("re").findall(r"(?:bind|sync|apply)\w*Character\w*", s)))

with open(r"D:/拾光剪影/app/temp/_canvas_assets.json", "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
print("OK")
