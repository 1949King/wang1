# -*- coding: utf-8 -*-
"""提交后校验：历史里是否还有污染（node_modules / pycache / dist / db）。"""
import os, subprocess, collections
ROOT = r"D:\拾光剪影"
TMP = os.path.join(os.environ.get("TEMP", "/tmp"))

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return r.stdout.decode("utf-8", "replace")

BAD = ("node_modules/", "__pycache__/", "/dist/", ".pyc", ".db-shm", ".db-wal",
       ".tsbuildinfo", ".glb")

log = git("log", "--format=%h|%s", "d67f80a..HEAD").strip().splitlines()
print("新增提交 %d 个\n" % len(log))
bad_hits = []
for line in log:
    if not line.strip():
        continue
    h, subj = line.split("|", 1)
    out = git("-c", "core.quotePath=false", "show", "--numstat", "--format=", h)
    add = dele = 0
    c = collections.Counter()
    paths = []
    for l in out.splitlines():
        parts = l.split("\t")
        if len(parts) < 3:
            continue
        a, d, p = parts[0], parts[1], "\t".join(parts[2:])
        if a != "-":
            add += int(a)
        if d != "-":
            dele += int(d)
        paths.append(p)
        c[p.split("/")[0] if "/" in p else "(root)"] += 1
        if any(b in p for b in BAD):
            bad_hits.append((h, subj, p))
    print("%s  %-52s %6d 文件  增 %8d / 删 %8d" % (h, subj[:52], len(paths), add, dele))
    print("        %s" % dict(c.most_common(6)))

print()
print("=" * 70)
if bad_hits:
    print("⚠️ 仍含污染路径 %d 个：" % len(bad_hits))
    for h, s, p in bad_hits[:15]:
        print("   %s %s" % (h, p[:90]))
else:
    print("✅ 全部 %d 个提交：无 node_modules / __pycache__ / dist / db 混入" % len(log))

print()
print("=== 仓库体积 ===")
for d in (".git",):
    tot = 0
    for dp, dns, fns in os.walk(os.path.join(ROOT, d)):
        for f in fns:
            try:
                tot += os.path.getsize(os.path.join(dp, f))
            except OSError:
                pass
    print("  %s  %.1f MB" % (d, tot / 1048576.0))
