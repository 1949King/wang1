# -*- coding: utf-8 -*-
"""判定文档是否混入了非本文件应有内容，并核对与源分片的关系。"""
import io, os

DOC = r"D:\拾光剪影\docs\_reports\2026-09-23-拾光剪影-架构与算法规格说明书.md"
PART2 = r"D:\拾光剪影\app\temp\_spec_part2.md"

doc = io.open(DOC, encoding="utf-8").read()
p2 = io.open(PART2, encoding="utf-8").read()

print("doc  字符 %d / 字节 %d" % (len(doc), os.path.getsize(DOC)))
print("part2 字符 %d / 字节 %d" % (len(p2), os.path.getsize(PART2)))
print()

# part2 的内容是否完整出现在 doc 中
p2_stripped = p2.strip()
print("part2 整体作为子串出现在 doc 中:", p2_stripped in doc)
print("part2 首 200 字出现在 doc:", p2_stripped[:200] in doc)
print("part2 末 200 字出现在 doc:", p2_stripped[-200:] in doc)
print()

# 检查非本文件主题的内容
probes = ["全项目算法清单", "2026-09-22", "算法清单"]
print("=== 异源内容探测 ===")
for p in probes:
    print("  %-16s 出现 %d 次" % (p, doc.count(p)))
print()

# 行尾风格
crlf = doc.count("\r\n")
lf = doc.count("\n")
print("行尾: CRLF=%d  LF总=%d  纯LF=%d" % (crlf, lf, lf - crlf))
print()

# 定位最长的 20 个连续块差异：按 500 字切片看是否有重复切片
from collections import Counter
chunks = [doc[i:i + 300] for i in range(0, len(doc) - 300, 150)]
c = Counter(chunks)
dup = [(n, t[:70]) for t, n in c.items() if n > 1]
dup.sort(reverse=True)
print("重复的 300 字切片（重叠采样）: %d 组" % len(dup))
for n, t in dup[:5]:
    print("  x%d %s" % (n, t.replace("\n", " ")))
