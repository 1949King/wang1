# -*- coding: utf-8 -*-
"""最终核验：根目录是否还有 0 字节怪文件 / 是否新增。"""
import os, io, subprocess

ROOT = r"D:\拾光剪影"

zero = []
for e in sorted(os.listdir(ROOT)):
    p = os.path.join(ROOT, e)
    if os.path.isfile(p) and os.path.getsize(p) == 0:
        zero.append(e)

print("根目录 0 字节文件: %d 个" % len(zero))
for e in zero:
    r = subprocess.run(["git", "ls-files", "--error-unmatch", "--", e],
                       cwd=ROOT, capture_output=True)
    print("   %-50s 已跟踪=%s" % (repr(e)[:50], r.returncode == 0))
print()

r = subprocess.run(["git", "-c", "core.quotePath=false", "status", "--porcelain", "-uall"],
                   cwd=ROOT, capture_output=True)
lines = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
print("git status 剩余 %d 项：" % len(lines))
for l in lines:
    print("   ", l[:110])
print()

print("=== 本次交付物核验 ===")
for rel in ["app/temp/_qt6_launch.py", "app/temp/qt6_launch.log",
            "app/temp/qt6_report.txt", "app/temp/_clean_junk.py",
            "docs/_reports/2026-09-23-拾光剪影-架构与算法规格说明书.md"]:
    p = os.path.join(ROOT, *rel.split("/"))
    print("  %-58s %s" % (rel, ("%d B" % os.path.getsize(p)) if os.path.exists(p) else "缺失"))
