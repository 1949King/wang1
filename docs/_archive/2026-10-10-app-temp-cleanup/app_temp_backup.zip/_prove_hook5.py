# -*- coding: utf-8 -*-
"""证明第 ⑤ 道卡点（双库一致性）真的能拦住漂移 —— 而不只是「存在」。

测试法：制造一次副库漂移 → 看校验是否变红 → 还原 → 看是否变绿。
（副库已有回滚能力，所以这个测试是安全的）
"""
import io
import os
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable
CHECK = os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")
TARGET = os.path.join(ROOT, "vendor", "AI-Canvas-tauri", "src", "libtv", "canvasVersion.ts")


def run_check():
    r = subprocess.run([PY, CHECK], cwd=ROOT, capture_output=True)
    out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
    return r.returncode, out


print("=" * 74)
print("① 基线状态（应为绿）")
print("=" * 74)
rc0, out0 = run_check()
first = out0.splitlines()[0] if out0 else ""
print("  exit=%d  %s" % (rc0, first))
print("  ⇒ %s" % ("✅ 绿" if rc0 == 0 else "❌ 红"))
print()

print("=" * 74)
print("② 制造漂移：在副库副本里改一行")
print("=" * 74)
orig = io.open(TARGET, encoding="utf-8").read()
io.open(TARGET, "a", encoding="utf-8").write("// drift-probe\n")
print("  已写入 %s" % os.path.relpath(TARGET, ROOT))
print()

rc1, out1 = run_check()
print("  复测 exit=%d" % rc1)
for l in out1.splitlines()[:12]:
    print("     %s" % l[:100])
caught = rc1 != 0
print("  ⇒ %s" % ("✅ 成功拦住漂移" if caught else "❌ 没拦住 —— 卡点无效！"))
print()

print("=" * 74)
print("③ 还原（用副库 git 回滚 —— 这正是 S3 建立的回滚能力的价值）")
print("=" * 74)
r = subprocess.run(["git", "checkout", "--", "src/libtv/canvasVersion.ts"],
                   cwd=os.path.join(ROOT, "vendor", "AI-Canvas-tauri"),
                   capture_output=True)
restored = io.open(TARGET, encoding="utf-8").read() == orig
print("  checkout exit=%d  内容已还原=%s" % (r.returncode, restored))
print()

rc2, out2 = run_check()
print("  复测 exit=%d  %s" % (rc2, (out2.splitlines()[0] if out2 else "")))
print("  ⇒ %s" % ("✅ 回到绿" if rc2 == 0 else "❌ 仍红"))
print()

print("=" * 74)
print("结论")
print("=" * 74)
print("  卡点有效性: 制造漂移→拦住 %s / 还原→恢复 %s" % (caught, rc2 == 0))
print("  第 ⑤ 道卡点 %s" % ("可用" if (caught and rc2 == 0) else "有问题，需修"))
