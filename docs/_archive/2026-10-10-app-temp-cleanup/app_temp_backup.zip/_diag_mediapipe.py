# -*- coding: utf-8 -*-
"""定位 mediapipe 在「按真实顺序导入」时失败的真正原因。"""
import subprocess

VENV = r"D:\拾光剪影\.venv312\Scripts\python.exe"
ROOT = r"D:\拾光剪影"

SEQS = [
    ("全量原顺序",
     "import PyQt6, moviepy, cv2, torch, transformers, faster_whisper, easyocr, PIL, numpy; import mediapipe; print('OK')"),
    ("去掉 PyQt6",
     "import moviepy, cv2, torch, transformers, faster_whisper, easyocr, PIL, numpy; import mediapipe; print('OK')"),
    ("去掉 moviepy",
     "import PyQt6, cv2, torch, transformers, faster_whisper, easyocr, PIL, numpy; import mediapipe; print('OK')"),
    ("cv2 + mediapipe",
     "import cv2; import mediapipe; print('OK')"),
    ("torch + cv2 + mediapipe",
     "import torch, cv2; import mediapipe; print('OK')"),
    ("easyocr + mediapipe",
     "import easyocr; import mediapipe; print('OK')"),
    ("transformers + mediapipe",
     "import transformers; import mediapipe; print('OK')"),
    ("faster_whisper + mediapipe",
     "import faster_whisper; import mediapipe; print('OK')"),
    ("moviepy + mediapipe",
     "import moviepy; import mediapipe; print('OK')"),
]

ERR_KEYS = ("Error", "error", "Traceback", "cannot", "cannot import", "No module")

for label, code in SEQS:
    try:
        r = subprocess.run([VENV, "-c", code], cwd=ROOT, capture_output=True, timeout=900)
    except subprocess.TimeoutExpired:
        print("  %-28s ⏱ 超时" % label)
        continue
    err = r.stderr.decode("utf-8", "replace").strip()
    hits = [l for l in err.splitlines() if any(k in l for k in ERR_KEYS)]
    if r.returncode == 0:
        verdict = "✅ 成功"
        detail = ""
    else:
        verdict = "❌ 失败"
        detail = (hits[-1] if hits else (err.splitlines()[-1] if err else "(无 stderr)"))
    print("  %-28s %s  %s" % (label, verdict, detail[:100]))

print()
print("说明：若只有「全量原顺序」失败，说明是**多包叠加**导致（多为 numpy/protobuf ABI 冲突），")
print("      而非某个单包的问题。")
