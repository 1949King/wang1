# -*- coding: utf-8 -*-
"""盘点画布的节点种类与故事/剧本相关实现"""
import re
import io
import os
import json

SRC = r"D:/拾光剪影/vendor/shiguang-canvas/src"
out = {}

p = os.path.join(SRC, "stores", "node-factory.ts")
t = io.open(p, encoding="utf-8", errors="replace").read()
out["node-factory_kinds"] = sorted(set(re.findall(r'kind:\s*"([A-Za-z0-9_]+)"', t)))
out["node-factory_labels"] = sorted(set(re.findall(r'label:\s*"([^"]{1,24})"', t)))

# 故事/剧本相关节点
for f in ("storyNodes.tsx", "registerBuiltinNodes.ts", "infiniteCoreNodes.ts",
          "mediaExtraNodes.tsx", "nodes.tsx"):
    fp = os.path.join(SRC, f)
    if not os.path.isfile(fp):
        continue
    s = io.open(fp, encoding="utf-8", errors="replace").read()
    out[f] = {
        "lines": s.count("\n") + 1,
        "exports": sorted(set(re.findall(r"export (?:default )?(?:function|const|class) ([A-Za-z0-9_]+)", s))),
        "kinds": sorted(set(re.findall(r'kind:\s*"([A-Za-z0-9_]+)"', s))),
        "types": sorted(set(re.findall(r'type:\s*"([A-Za-z0-9_-]+)"', s))),
    }

with open(r"D:/拾光剪影/app/temp/_canvas_nodes.json", "w", encoding="utf-8") as fh:
    json.dump(out, fh, ensure_ascii=False, indent=1)
print("OK")
