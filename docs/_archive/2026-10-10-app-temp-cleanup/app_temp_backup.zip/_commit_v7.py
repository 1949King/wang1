# -*- coding: utf-8 -*-
"""提交 v7 + 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """feat(canvas): 形象包 v7 —— 新增「传统涂装②职场秘书套装」（含丝袜·端庄版）

用户要求：带丝袜、符合传统印象的秘书套装。

处理原则：**元素全给，尺度守在企业职场端庄**（与项目既有「非性化」惯例一致）
· 保留用户点名要素：西装套裙 + 衬衫 + 丝巾 + 及膝一步裙 + **深色哑光半透丝袜** + 中跟船鞋
· 守住尺度：领口扣至第二颗（露颈不低胸）/ 裙长及膝 / 不开高衩 /
  明确排除网袜与亮面袜 / 姿态端正不俯身

关键：**西装最容易再次偏男性** ⇒ 带入 X 型收腰约束
（女式收腰剪裁 + 柔肩无垫肩 + 显式禁止"中性化男式西装剪裁"）

mascot-010 设计要点：
· 深蓝女式收腰西装（单排一粒扣、柔肩无垫肩、腰线明显）+ 米白真丝衬衫
· 品牌蓝(#3b82f6)细长丝巾打简洁结、垂落胸前
· 深蓝及膝一步裙（铅笔裙）；深色哑光半透丝袜；深蓝中跟船鞋
· 配饰：细金丝圆框眼镜、银色细表、**胸前工牌（品牌蓝挂绳）**、小胶片胸针、耳钉
· 发型：侧分优雅低盘发（含品牌蓝挑染）；狐耳放松；大狐尾盘落、尾尖渐白
· 动作：双手身前抱深蓝皮质文件夹 + 一手托悬浮暖光点；端正不扭转不俯身
· 背景：拱形落地窗 + 满月 + 夜色城市剪影 + 时间线光带 + 暖橙台灯 + 热茶 + 文件

实测核验：收腰X型成立（未偏男性）、领口端庄、裙长及膝、丝袜哑光、工牌职业感强。
小偏差：丝巾实际呈现为领带结形态（配西装协调，反而更职业）；鞋跟略高于 3-4cm。

产出图：assets/mascot/shilan-传统02-职场秘书套装-端庄版.png
双库同步：4 处 JSON 一致（10 条）；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psF.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "assets/mascot/shilan-传统02-职场秘书套装-端庄版.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgF.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("② 提交副库")
print("=" * 74)
gt("add", "-A", "--", "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M8.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "feat(libtv): 同步形象包 v7（职场秘书套装·含丝袜·端庄版）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v7：职场秘书套装（含丝袜·端庄版）（01:47 - 02:10）

用户要求：带丝袜、符合传统印象的秘书套装。

### 处理原则（可复用）
**元素全给，尺度守住** —— 不因为"丝袜"这个元素就收紧或回避，
而是把「职场端庄」这条线写进 prompt 的**显式约束**里：

| 用户点名要的 | 我加的保护性约束 |
|---|---|
| 西装套裙 / 衬衫 / 丝巾 / 及膝一步裙 / **丝袜** / 中跟船鞋 / 工牌 | 领口**扣至第二颗**（露颈不低胸）· 裙长**及膝** · **不开高衩** · **明确排除网袜与亮面袜** · 姿态**端正不俯身** · 非性化 |

这与项目既有惯例一致（`shiguang-avatar.json` 全部条目均明确标注「成年女性」）。

### ⚠️ 关键技法：西装最容易再次"偏男性"
西装 = 男装原生剪裁 ⇒ 必须显式带入三个约束，否则立刻回到中性：
1. **女式收腰剪裁**（腰线明显收出）
2. **柔肩无垫肩**
3. 显式负向约束：**禁止"中性化男式西装剪裁"**（本次实测有效：收腰 X 型成立）

### 实测核验
收腰 X 型成立（未偏男性）· 领口端庄 · 裙长及膝 · 丝袜哑光半透 · 工牌职业感强 ·
低盘发 + 狐耳放松 + 大狐尾盘落 · 双手身前抱文件夹（经典秘书动作）
小偏差：丝巾实际呈现为领带结形态（配西装协调，反而更职业）；鞋跟略高于 3-4cm

### 提示词包已到 10 条
001-004（东方礼服主形象/表情/动态/场景）· 005-008（现代涂装）·
009（传统①中式旗袍）· 010（传统②职场秘书套装）
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v7" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
