# -*- coding: utf-8 -*-
"""决定性测量：应用**真实导入链**的耗时归因（-X importtime）。

比逐个 `import X` 可靠：它测的是 app.main_qt6 实际拉起来的东西，
而不是「某个库自己导入要多久」。
"""
import os
import re
import subprocess
import sys

ROOT = r"D:\拾光剪影"
VENV = os.path.join(ROOT, ".venv312", "Scripts", "python.exe")
PY = VENV if os.path.exists(VENV) else sys.executable

env = dict(os.environ)
env["PYTHONUTF8"] = "1"
env["PYTHONUNBUFFERED"] = "1"

print("=" * 74)
print("真实导入链归因：python -X importtime -c \"import app.main_qt6\"")
print("=" * 74)
r = subprocess.run([PY, "-X", "importtime", "-c", "import app.main_qt6"],
                   cwd=ROOT, env=env, capture_output=True, timeout=900)
err = r.stderr.decode("utf-8", "replace")
print("  exit=%d" % r.returncode)
if "wmic" in err.lower() or "BLOCKED" in err:
    print("  ⚠️ 命中 wmic 拦截（不变量 #10），但 importtime 数据仍可用")
print()

rows = []
for l in err.splitlines():
    m = re.match(r"import time:\s+(\d+)\s+\|\s+(\d+)\s+\|\s+(\S+)", l)
    if m:
        rows.append((int(m.group(1)), int(m.group(2)), m.group(3)))
if not rows:
    print("  ❌ 未解析到 importtime 数据，原始尾部：")
    for l in err.splitlines()[-15:]:
        print("     %s" % l[:110])
    sys.exit(0)

self_t = [(s, n) for s, n, n_ in rows]
cum = sorted(rows, key=lambda x: -x[1])
print("  共 %d 个模块" % len(rows))
print("  总 self 时间 %.1fs" % (sum(s for s, _ in self_t) / 1e6))
print()
print("  TOP 20 按累计耗时（cumulative）：")
print("  %10s %10s  %s" % ("self(ms)", "cum(ms)", "模块"))
for s, c, n in cum[:20]:
    print("  %10.0f %10.0f  %s" % (s / 1000.0, c / 1000.0, n[:70]))
print()

print("  TOP 15 按自耗时（self，即「就是它自己慢」）：")
for s, c, n in sorted(rows, key=lambda x: -x[0])[:15]:
    print("  %10.0f %10.0f  %s" % (s / 1000.0, c / 1000.0, n[:70]))
print()

print("  按顶层包聚合（cumulative 之和，看谁是大头）：")
agg = {}
for s, c, n in rows:
    top = n.split(".")[0].strip()
    if top.startswith(("from", "import")):
        continue
    agg[top] = agg.get(top, 0) + c
for k, v in sorted(agg.items(), key=lambda x: -x[1])[:18]:
    if v > 200_000:
        print("  %10.1fs  %s" % (v / 1e6, k))
