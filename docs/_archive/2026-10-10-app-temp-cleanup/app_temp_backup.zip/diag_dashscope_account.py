# -*- coding: utf-8 -*-
"""鉴别诊断：key 是否对任何模型有权限（qwen-turbo 文本生成，token 级成本可忽略）。"""
import io
import json
import sys
import urllib.request
import urllib.error
from pathlib import Path

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / "app" / "core" / "ai"))
import dashscope_video as dsv

key = dsv.get_api_key()
url = "https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation"
body = {"model": "qwen-turbo", "input": {"prompt": "回复两个字：可用"}}
req = urllib.request.Request(
    url, data=json.dumps(body).encode("utf-8"), method="POST",
    headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"})
try:
    with urllib.request.urlopen(req, timeout=30) as resp:
        r = json.loads(resp.read().decode("utf-8"))
    out = (r.get("output") or {}).get("text", "")
    print("qwen-turbo 文本调用: 成功 ✅ 回复 =", out)
    print("→ 结论：账号本身可用，仅万相视频模型未开通")
except urllib.error.HTTPError as e:
    detail = e.read().decode("utf-8", errors="replace")[:300]
    print(f"qwen-turbo 文本调用: HTTP {e.code} ❌")
    print(detail)
    print("→ 结论：账号对所有模型均无权限（百炼服务未开通或 key 失效）")
