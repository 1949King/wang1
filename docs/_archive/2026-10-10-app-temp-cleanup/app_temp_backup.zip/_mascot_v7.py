# -*- coding: utf-8 -*-
"""形象包 v7：新增「传统涂装②职场秘书套装」（含丝袜，职场端庄版）。

用户要求：带丝袜、符合传统印象的秘书套装。
处理原则：**元素全给（含丝袜），尺度守在企业职场端庄** ——
  保留：收腰西装 + 衬衫 + 丝巾 + 及膝一步裙 + **深色哑光半透丝袜** + 中跟船鞋 + 工牌
  守住：领口扣至第二颗（露颈不低胸）/ 裙长及膝 / 不开高衩 / 不用网袜亮面袜 /
        姿态端正不俯身 / 非性化（与项目既有惯例一致）
关键：**西装最容易再次偏男性** ⇒ 带上 X 型收腰约束（女式剪裁、柔肩无垫肩、禁止中性男式剪裁）
"""
import io
import json
import os
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"
PACK_PATH = os.path.join(C, "public", "prompts", PACK)

ENTRY = {
    "id": "mascot-010",
    "title": "拾岚·传统涂装②职场秘书套装（含丝袜·端庄版）",
    "category": "portrait",
    "tags": ["传统涂装", "替换外观", "skin", "秘书套装", "西装套裙", "丝袜",
             "工牌", "职场端庄", "X型收腰", "成人比例", "竖版"],
    "prompt": (
        "二次元兽耳娘角色全身立绘，成年女性，知性温婉的职场秘书大姐姐气质，"
        "完全着装、非性化。"
        "【比例·必须严格遵守】7.5头身；头宽:肩宽≈1:2.2；腰线偏高，腿长占身高约55%；躯干修长。"
        "禁止Q版、禁止短身、禁止大头。"
        "【身体轮廓·关键】**女式收腰剪裁的X型轮廓：腰围清晰可见**（西装外套收腰、腰线明确）；"
        "**肩线柔和不挺括（无垫肩感）**；"
        "**颈部修长、衬衫领口微开露出颈部与锁骨线条但不低胸**。"
        "禁止直筒无腰的H型廓形、禁止挺括垫肩、禁止中性化男式西装剪裁。"
        "【面部·成年人脸型】鹅蛋/卵形脸，脸长:脸宽≈1.4:1；下颌线清晰、下巴略尖；"
        "眼睛细长、眼尾微上扬，眼裂宽度约占脸宽1/3（不要大圆眼），双眼皮明确，瞳色青蓝；"
        "神态温婉知性、眼神温润。"
        "【角色】一对狐狸兽耳（耳内侧浅色绒毛，耳姿自然放松、一只微垂）；"
        "一条蓬松狐尾自然盘落在身侧后方，尾尖由深蓝渐变为浅白蓝。"
        "深蓝黑长发梳成**优雅的侧分低盘发**（几缕碎发自然垂落鬓边），"
        "刘海一撮品牌蓝(#3b82f6)挑染。戴一副细金丝圆框眼镜，镜片有极淡的品牌蓝反光。"
        "【衣装·经典职场秘书套装】深蓝(#1c2638)**女式收腰西装外套**"
        "（单排一粒扣、柔肩无垫肩、腰线明显收出）；"
        "内搭**米白/浅蓝真丝衬衫**，翻领，**领口扣至第二颗，露出颈部与锁骨线条但端庄不低胸**；"
        "颈间系一条**品牌蓝(#3b82f6)细长丝巾**（打一个简洁的结、自然垂落胸前）；"
        "下配**深蓝及膝一步裙（铅笔裙）**，贴身剪裁、**裙长及膝**；"
        "腿部穿着**深色半透感丝袜（哑光质感，非网袜、非亮面）**；"
        "脚穿深蓝**中跟船鞋（约3-4厘米）**。"
        "配饰：细金丝圆框眼镜、银色细表、胸前一枚挂品牌蓝挂绳的小工牌、"
        "一枚小胶片/剪影形状银质胸针、小巧耳钉。"
        "**整体：职场端庄、剪裁合体；端庄不暴露、不开高衩、不低胸、裙长不短于膝。**"
        "【动作】端正站立、身体微侧，**双手在身前抱着一只深蓝皮质文件夹**，"
        "其中一手轻托起一颗悬浮的小小暖光点；肩线放松、颈部线条舒展，温婉平视观者；"
        "不插口袋、不叉腰、不扭转、不俯身、不卖萌。"
        "【背景】深夜办公室；身后一扇拱形落地窗，窗外是极简夜色城市轮廓剪影与一轮满月；"
        "身后墙面横贯一条柔和发光的时间线光带（带极小节点光点）；"
        "前景办公桌一角，桌上有一杯冒热气的茶、一盏暖橙台灯、一叠文件与一台合上的深蓝笔记本。"
        "光照：左侧屏幕蓝光为主光，右侧暖橙台灯为辅助光，"
        "在肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。"
        "【风格】精致二次元插画，赛璐珞平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
        "构图居中、全身入画并留出上下留白。竖版3:4。"
    ),
}

data = json.load(io.open(PACK_PATH, encoding="utf-8"))
ids = {e["id"] for e in data}
if ENTRY["id"] in ids:
    for e in data:
        if e["id"] == ENTRY["id"]:
            e["prompt"] = ENTRY["prompt"]
    print("⏭ mascot-010 已存在，更新 prompt")
else:
    data.append(ENTRY)
    print("✅ 已追加 mascot-010（职场秘书套装·含丝袜·端庄版）")

content = json.dumps(data, ensure_ascii=False, indent=2) + "\n"

print("=" * 74)
print("① 写入 4 处")
print("=" * 74)
for p in [os.path.join(C, "public", "prompts", PACK), os.path.join(C, "dist", "prompts", PACK),
          os.path.join(T, "public", "prompts", PACK), os.path.join(T, "dist", "prompts", PACK)]:
    if os.path.isdir(os.path.dirname(p)):
        io.open(p, "w", encoding="utf-8").write(content)
print("  ✅ 4 处已写入（%d 条 / %d 字节）" % (len(data), len(content)))
print()

print("=" * 74)
print("② 收图")
print("=" * 74)
SRC = os.path.join(ROOT, "generated-images",
                   "二次元兽耳娘角色全身立绘_成年女性_知性温婉的职场秘书大姐姐_2026-09-25T11-47-56.png")
DST = os.path.join(ROOT, "assets", "mascot", "shilan-传统02-职场秘书套装-端庄版.png")
if os.path.exists(SRC):
    shutil.copy2(SRC, DST)
    print("  ✅ %s (%.1f KB)" % (os.path.basename(DST), os.path.getsize(DST) / 1024.0))
else:
    print("  ❌ 源图不存在")
print()

print("=" * 74)
print("③ 核验")
print("=" * 74)
a = io.open(os.path.join(C, "src", "promptLibrary.ts"), "rb").read()
b = io.open(os.path.join(T, "src", "libtv", "promptLibrary.ts"), "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b else "❌"))
print("  JSON 合法: ✅ 条目 %d" % len(json.loads(content)))
print("  含丝袜的条目: %s" % [e["id"] for e in data if "丝袜" in e["prompt"]])
r = subprocess.run([sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
print("  双库校验 exit=%d  %s" % (r.returncode,
      r.stdout.decode("utf-8", "replace").strip().splitlines()[0]))
