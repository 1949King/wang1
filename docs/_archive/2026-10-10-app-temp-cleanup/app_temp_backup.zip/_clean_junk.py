# -*- coding: utf-8 -*-
"""清理根目录 10 个 0 字节怪文件（文档片段被误当文件名）。

按不变量 #11：显式列名单 + 删前确认未被 git 跟踪 + 逐个校验大小。
"""
import os, io, subprocess

ROOT = r"D:\拾光剪影"

TARGETS = [
    "主程序",
    "口径：本方案所有「现状」结论均取自本地实际代码，标",
    "口径：全部结论取自本地实际代码，每条带",
    "方法：6",
    "日期：2026-09-20",
    "日期：2026-09-23",
    "来源：Hypit",
    "版本基线：主程序",
    "版本：v1.0",
    "调研日期：2026-09-20",
]

print("=== 删前核验 ===")
ok = []
for name in TARGETS:
    p = os.path.join(ROOT, name)
    if not os.path.exists(p):
        print("  跳过 不存在            %s" % name)
        continue
    size = os.path.getsize(p)
    # 是否被 git 跟踪
    r = subprocess.run(["git", "ls-files", "--error-unmatch", "--", name],
                       cwd=ROOT, capture_output=True)
    tracked = (r.returncode == 0)
    full = os.path.join(ROOT, name)
    is_file = os.path.isfile(full)
    print("  %-42s %4d B  文件=%s  已跟踪=%s" % (name[:42], size, is_file, tracked))
    if size == 0 and is_file and not tracked:
        ok.append(name)
    else:
        print("     ^ 不满足删除条件，跳过")

print()
print("可安全删除: %d / %d" % (len(ok), len(TARGETS)))
print()

removed = 0
failed = []
for name in ok:
    try:
        os.remove(os.path.join(ROOT, name))
        removed += 1
    except Exception as e:
        failed.append((name, str(e)[:60]))

print("已删除 %d 个" % removed)
for n, e in failed:
    print("  失败 %s : %s" % (n, e))
print()

print("=== 删后复核 ===")
left = [n for n in TARGETS if os.path.exists(os.path.join(ROOT, n))]
print("仍存在: %s" % (left if left else "（无）"))

r = subprocess.run(["git", "-c", "core.quotePath=false", "status", "--porcelain", "-uall"],
                   cwd=ROOT, capture_output=True)
lines = [l for l in r.stdout.decode("utf-8", "replace").splitlines() if l.strip()]
print()
print("git status 剩余 %d 项：" % len(lines))
for l in lines:
    print("   ", l[:100])
