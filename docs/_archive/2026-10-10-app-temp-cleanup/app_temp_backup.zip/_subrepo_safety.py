# -*- coding: utf-8 -*-
"""给副库建立可回滚基线：把项目侧的画布副本与资源纳入子仓库跟踪。

背景（纠正技术债报告 S3 的表述）：
  副库 vendor/AI-Canvas-tauri 并非「完全没有 git」——它其实是第三方仓库
  (github.com/Tenney95/AI-Canvas-tauri) 的克隆，有 1 个上游提交。
  真正的问题是 **src/libtv/（89 文件，项目侧画布副本）从未 git add**，
  所以「改它无法回滚」。修法不是 git init，而是把该目录纳入跟踪。

安全约束：
  ⛔ 绝不 push —— origin 是第三方仓库，没有写权限。
  ✅ 只做本地 add + commit，获得 git diff / git checkout 回滚能力。
"""
import io
import os
import subprocess

T = r"D:\拾光剪影\vendor\AI-Canvas-tauri"

ADD_PATHS = [
    "src/libtv",
    "src/services/bridgeHost.ts",
    "src/components/shared/ViewModeSwitcher.tsx",
    "public/prompts",
    "public/models",
    "public/models-src",
]
IGNORE_LINES = [
    "",
    "# 诊断临时文件（项目侧生成，勿入库）",
    "tc2.txt",
    "typecheck_errors.txt",
]


def g(*a):
    r = subprocess.run(["git"] + list(a), cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


print("=" * 74)
print("① 补 .gitignore（排除诊断临时文件）")
print("=" * 74)
gi = os.path.join(T, ".gitignore")
body = io.open(gi, encoding="utf-8", errors="replace").read()
if "typecheck_errors.txt" in body:
    print("  已含，跳过")
else:
    io.open(gi, "a", encoding="utf-8").write("\n".join(IGNORE_LINES) + "\n")
    print("  已追加 %d 行" % len(IGNORE_LINES))
print()

print("=" * 74)
print("② 纳入跟踪")
print("=" * 74)
for p in ADD_PATHS:
    rc, out, err = g("add", "-A", "--", p)
    print("  %s %-46s %s" % ("✅" if rc == 0 else "❌", p, err[:60]))
print()

rc, out, _ = g("diff", "--cached", "--numstat")
staged = [l for l in out.splitlines() if l.strip()]
print("  暂存文件数: %d" % len(staged))
print()

print("=" * 74)
print("③ 提交（本地，不 push）")
print("=" * 74)
msg = ("chore: 纳入项目侧画布副本与资源，建立可回滚基线\n\n"
       "背景：src/libtv（89 文件，项目侧画布副本）与其配套资源此前从未 add，\n"
       "导致修改它时无 git 回滚能力（项目文档已记录该风险）。\n"
       "本次仅本地提交，提供 git diff / git checkout 能力。\n\n"
       "⚠️ 本仓库 origin 为第三方仓库 (Tenney95/AI-Canvas-tauri)，请勿 push。\n\n"
       "包含：src/libtv/ · src/services/bridgeHost.ts ·\n"
       "src/components/shared/ViewModeSwitcher.tsx ·\n"
       "public/prompts/ · public/models/ · public/models-src/\n"
       "忽略：tc2.txt · typecheck_errors.txt（诊断临时文件）")
mf = os.path.join(T, ".git", "COMMIT_MSG_TMP.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = g("commit", "-F", mf)
os.remove(mf)
print("  exit=%d" % rc)
print("  %s" % (out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("④ 验证回滚能力")
print("=" * 74)
print("  提交历史:")
for l in g("log", "--oneline", "-3")[1].splitlines():
    print("     %s" % l)
print()
rc, out, _ = g("status", "--porcelain")
left = [l for l in out.splitlines() if l.strip()]
print("  工作区剩余变更: %d 项" % len(left))
for l in left[:10]:
    print("     %s" % l[:100])
print()
print("  remote（提醒：勿 push）:")
for l in g("remote", "-v")[1].splitlines():
    print("     %s" % l)
print()
print("  回滚能力自测：git diff 可用 =",
      g("diff", "--stat", "HEAD")[0] == 0)
