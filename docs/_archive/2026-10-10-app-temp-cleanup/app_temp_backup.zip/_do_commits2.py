# -*- coding: utf-8 -*-
"""分批提交 v2：修正 v1 的「-f 缺失 / 误判失败 / 污染」三个问题。"""
import os, io, subprocess, collections

ROOT = r"D:\拾光剪影"

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    ents = []
    for e in out.split("\x00"):
        if e.strip():
            ents.append((e[:2].strip(), unquote(e[3:])))
    return ents

def staged():
    rc, out, _ = git("diff", "--cached", "--name-only")
    return [l for l in out.splitlines() if l.strip()]

# ---------- 收集删除 ----------
rc, out, _ = git("status", "--porcelain", "-uall", "-z")
D = []
for e in out.split("\x00"):
    if not e.strip():
        continue
    k, p = e[:2].strip(), unquote(e[3:])
    if k == "D":
        D.append(p)

VENDOR_PFX = ("openshot-qt/", "libopenshot/", "libopenshot-audio", "thirdparty/")
d_vendor = [p for p in D if p.startswith(VENDOR_PFX)]
d_proj = [p for p in D if not p.startswith(VENDOR_PFX)]

BATCHES = [
    ("chore(config): 更新忽略规则、CI 工作流与工程约定",
     [".gitignore", ".pre-commit-config.yaml", "ruff.toml", "AGENTS.md", "CONTEXT.md",
      ".github/PULL_REQUEST_TEMPLATE.md", ".github/workflows/quality-gate.yml",
      ".cursor/rules/frozen-zones.mdc", "scripts/_split_timeline_phase1.py",
      "plugin_config.json"],
     "更新 .gitignore / pre-commit / ruff / CI 模板与冻结区规则文件"),

    ("chore(vendor): 移除 openshot 第三方参考源码树",
     d_vendor,
     "openshot-qt / libopenshot / libopenshot-audio / thirdparty 整棵上游参考实现；\n"
     "早年拉进来做技术对照，非本项目自有代码，已不再需要"),

    ("chore(clean): 清理已下线模块、合并旧编辑器、移除根目录临时产物",
     d_proj,
     "① 7 个旧 video_editor/* 并入 editor_module.py\n"
     "② account_ops 随账号运营下线\n"
     "③ drama_finder_plugin 等无引用早期模块\n"
     "④ 根目录历史脚本与日志\n"
     "已做 AST 悬空 import 反查 = 0，无功能损失"),

    ("feat(core): Agent 能力体系与 AI 生成守护管线",
     ["app/core", "license"],
     "app/core 下 agent_* 常量/目录/循环/人格/主动建议、AI 四守护、\n"
     "provider_pool 额度池、score_book 评分回写、context_budget、\n"
     "project_snapshot、timeline_source；log_manager 修 NameError"),

    ("feat(editor): 编辑模块与 Qt6 主窗口",
     ["app/modules", "app/main_qt6.py", "app/verify_c8_qt6.py"],
     "editor_module 系列 mixin、AI 面板、keyframe 曲线编辑器、导航栏图标、Qt6 入口"),

    ("feat(plugins): 转场插件、测试用例与版本推进",
     ["app/plugins", "app/tests", "app/data", "app/version.py", "app/__init__.py", "tests"],
     "6 个转场插件、app/tests 用例更新、data 配置同步，版本推进至 4.35.0"),

    ("feat(canvas): shiguang-canvas 磁吸、新手模式与 Studio 页面",
     ["vendor/shiguang-canvas"],
     "magnetic 引擎/bonds/reflow/levels、novice 新手卡、Stage3D/ImageStudio/VideoStudio、\n"
     "comfyToCanvas、cameraRecorder、vitest 配置"),

    ("docs: 归档知识库与历史文档，补充技术报告",
     ["docs/_archive", "docs/_reports", "docs/knowledge",
      "docs/冷启动性能诊断报告.md", "docs/CHANGELOG.md", "docs/现行技术文档.md",
      ".workbuddy/memory/MEMORY.md", ".trae"],
     "docs/knowledge/* → docs/_archive/knowledge/；根目录与 .trae 历史文档进 _archive；\n"
     "补 docs/_reports 系列报告与冷启动性能诊断、项目 MEMORY.md、CHANGELOG"),

    ("chore(verify): 补 _verify 校验与守卫脚本",
     ["_verify"],
     "run_all_checks 总入口、scan_undefined_names（AST 作用域 NameError 扫描器）、\n"
     "各项 check_* 一致性守卫与 mjs 镜像测试"),
]

start = len(status())
print("提交前工作区变更：%d" % start)
print("=" * 72)

for idx, (subject, paths, body) in enumerate(BATCHES, 1):
    if not paths:
        print("[%d] 路径为空，跳过" % idx)
        continue
    git("reset")  # 先清空暂存区，杜绝跨批污染（v1 的教训）

    ps = os.path.join(ROOT, "app", "_ps_%d.txt" % idx)
    io.open(ps, "w", encoding="utf-8").write("\n".join(paths) + "\n")
    rc, out, err = git("add", "-A", "-f", "--pathspec-from-file=%s" % ps)
    os.remove(ps)

    if "fatal:" in err:
        print("[%d] ❌ add 失败：%s" % (idx, [l for l in err.splitlines() if "fatal:" in l][:2]))
        git("reset")
        continue

    st = staged()
    if not st:
        print("[%d] ⚠️ 无暂存内容，跳过：%s" % (idx, subject))
        continue

    c = collections.Counter(p.split("/")[0] if "/" in p else "(root)" for p in st)
    print("[%d] %s" % (idx, subject))
    print("     暂存 %d 项  顶层 %s" % (len(st), dict(c.most_common(6))))

    msg = subject + "\n\n" + body + "\n"
    mf = os.path.join(ROOT, "app", "_m_%d.txt" % idx)
    io.open(mf, "w", encoding="utf-8").write(msg)
    rc2, out2, err2 = git("commit", "-F", mf)
    os.remove(mf)
    if rc2 != 0:
        print("     ❌ commit 失败：%s" % err2.strip()[:300])
        git("reset")
        continue
    print("     ✅ 已提交   剩余 %d" % len(status()))
    print()

print("=" * 72)
print("提交前 %d → 提交后 %d" % (start, len(status())))
