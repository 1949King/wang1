# -*- coding: utf-8 -*-
"""侦察：粘合层的调用点与跨线载荷形状。"""
import os
import io
import re

ROOT = r"D:\拾光剪影"
SKIP = {".git", ".venv312", "node_modules", "__pycache__", "dist", "build", "openshot-qt"}

TARGETS = ["editor_canvas_link", "LINK_KEYS", "canvas_node_id", "canvas_kind",
           "timeline-snapshot", "MATERIAL_TO_TIMELINE", "stamp_clip",
           "outbox_fields_from_clip", "public_clip_row", "ingest"]


def scan(exts, label):
    print("=" * 74)
    print(label)
    print("=" * 74)
    hits = {t: [] for t in TARGETS}
    for dp, dns, fns in os.walk(ROOT):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if not f.endswith(exts):
                continue
            p = os.path.join(dp, f)
            rel = os.path.relpath(p, ROOT).replace("\\", "/")
            if "_archive" in rel or rel.startswith("app/temp"):
                continue
            try:
                body = io.open(p, encoding="utf-8-sig", errors="replace").read()
            except Exception:
                continue
            for t in TARGETS:
                n = len(re.findall(re.escape(t), body))
                if n:
                    hits[t].append((n, rel))
    for t in TARGETS:
        lst = sorted(hits[t], reverse=True)
        tot = sum(n for n, _ in lst)
        print("  %-26s %4d 处 / %d 文件" % (t, tot, len(lst)))
        for n, r in lst[:6]:
            print("        %3d  %s" % (n, r))
    print()


scan((".py",), "① Python 侧")

# 关键载荷构建点
print("=" * 74)
print("② 桥接端点与载荷构建（canvas_server.py 片段）")
print("=" * 74)
P = os.path.join(ROOT, "app", "core", "canvas_server.py")
body = io.open(P, encoding="utf-8-sig", errors="replace").read()
L = body.splitlines()
for i, l in enumerate(L, 1):
    if re.search(r'_route_(get|post)\(|def _handle_|timeline_snapshot|MATERIAL_TO_TIMELINE', l):
        print("  L%-5d %s" % (i, l.strip()[:110]))
