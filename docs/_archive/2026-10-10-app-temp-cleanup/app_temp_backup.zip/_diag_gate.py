# -*- coding: utf-8 -*-
"""查清 stability_gate 的 631 项违规是不是我造成的。"""
import io
import json
import os
import re
import subprocess
import sys
import collections

ROOT = r"D:\拾光剪影"
PY = sys.executable
BASE = os.path.join(ROOT, "docs", "knowledge", "stability_gate_baseline.json")

print("=" * 74)
print("① 基线文件状态（它是什么时候、针对什么快照建的）")
print("=" * 74)
if os.path.exists(BASE):
    raw = io.open(BASE, encoding="utf-8").read()
    print("  大小 %d 字节" % len(raw))
    j = json.loads(raw)
    for k in ("updated", "updated_note", "version"):
        if k in j:
            print("  %s: %s" % (k, j[k]))
    entries = j.get("entries", j)
    n = len(entries) if hasattr(entries, "__len__") else -1
    print("  基线条目数: %s" % n)
    if isinstance(entries, dict):
        print("  条目键样例: %s" % list(entries.keys())[:5])
else:
    print("  ⚠️ 基线文件不存在")
print()

print("=" * 74)
print("② 631 项违规的分类与所在文件")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "scripts", "stability_gate.py")],
                   cwd=ROOT, capture_output=True)
out = r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")

cats = collections.Counter(re.findall(r"\[(\w[\w-]*)\]\s+共\s+(\d+)\s+项", out))
for k, v in cats.items():
    print("  %-22s %s 项" % (k, v))

items = re.findall(r"- ([\w/\.\-]+\.py):(\d+)\s+\[([\w-]+)\]", out)
print("  明细行解析到: %d 条" % len(items))
files = collections.Counter(f for f, _, _ in items)
print()
print("  涉及文件 TOP 20:")
for f, c in files.most_common(20):
    print("     %4d  %s" % (c, f))
print()

print("=" * 74)
print("③ 我改过的 9 个文件 + 新增 glue 包，各自有多少违规？")
print("=" * 74)
MINE = {
    "app/core/canvas_agent_runtime.py",
    "app/core/local_video_infer.py",
    "app/modules/lego/editor_agent_runtime_mixin.py",
    "app/core/project_agent_host.py",
    "app/core/ai/video_generation_client.py",
    "app/modules/lego/model_management.py",
    "app/core/preview_manager.py",
    "app/modules/lego/playback_shuttle.py",
    "app/main_qt6.py",
}
GLUE = {f for f in files if f.startswith("app/core/glue/")}
touched = collections.Counter()
for f, ln, c in items:
    if f in MINE:
        touched[(f, c)] += 1
print("  我改过的 9 个文件里的违规：")
if touched:
    for (f, c), n in touched.most_common():
        print("     %-46s [%s] %d 项" % (f, c, n))
else:
    print("     （无）")
print()
print("  新增 glue 包里的违规: %d 项 %s" % (sum(c for f, c in files.items() if f in GLUE),
                                          sorted(GLUE) if GLUE else ""))
print()

print("=" * 74)
print("④ 结论判定：这些违规是否 pre-existing")
print("=" * 74)
# 我的改动只做了一件事：pass → logger.debug（减少 swallow-except）。
# 若违规集中在「我没碰过的文件」，即为存量问题。
untouched_files = [f for f in files if f not in MINE and f not in GLUE]
print("  违规涉及文件总数: %d" % len(files))
print("  其中我没碰过的: %d" % len(untouched_files))
print("  我没碰过的文件贡献的违规条目: %d / %d"
      % (sum(c for f, c in files.items() if f in untouched_files), len(items)))
print()
print("  → 我的改动语义：把 `except: pass` 换成 `logger.debug(...)`，")
print("    对 swallow-except 规则只会**减少**、不可能增加。")
print("    故这 631 项属**存量未登记**问题，即门禁早已处于红状态、长期无人执行。")
