"""语义级 bug 模式扫描（triage 一次性）：
P1 可变默认参数 def f(x=[]) / def f(x={})
P2 裸 except:
P3 except ...: pass 静默吞没（按不变量 #9 需人工分级：UI 绘制可接受 / 状态机不可接受）
"""
import ast
import sys
from pathlib import Path

roots = [Path("app")]
files = sorted(p for r in roots for p in r.rglob("*.py")
               if "__pycache__" not in p.parts and "temp" not in p.parts)

p1 = p2 = p3 = 0
for path in files:
    try:
        tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    except Exception:
        continue
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            for d in list(node.args.defaults) + [x for x in node.args.kw_defaults if x]:
                if isinstance(d, (ast.List, ast.Dict, ast.Set)):
                    print(f"P1 {path}:{node.lineno} 可变默认参数 def {node.name}(...={type(d).__name__})")
                    p1 += 1
        elif isinstance(node, ast.ExceptHandler):
            if node.type is None:
                print(f"P2 {path}:{node.lineno} 裸 except:")
                p2 += 1
            elif (len(node.body) == 1
                  and isinstance(node.body[0], ast.Pass)):
                t = ast.unparse(node.type) if node.type else "?"
                print(f"P3 {path}:{node.lineno} except {t}: pass")
                p3 += 1
print("=" * 70)
print(f"P1 可变默认参数 {p1} | P2 裸 except {p2} | P3 静默吞没 {p3}")
