# -*- coding: utf-8 -*-
"""直接从 docx 提取全文（只读分析）：按段落顺序输出，表格用 | 分隔。"""
import io
import re
import sys
import zipfile

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

PATH = r"C:/Users/Administrator/Documents/xwechat_files/wxid_ch66sa07stso22_8aeb/msg/file/2026-09/异构动态协作引擎_—_完整开发规格说明书.docx"
OUT = r"D:/拾光剪影/app/temp/spec_fulltext.txt"

z = zipfile.ZipFile(PATH)
xml = z.read("word/document.xml").decode("utf-8")

# 提取段落文本：每个 <w:p>...</w:p> 内所有 <w:t> 拼接；表格行做粗略处理
paras = []
for pm in re.finditer(r"<w:p\b.*?</w:p>", xml, re.S):
    p = pm.group(0)
    texts = re.findall(r"<w:t(?:\s[^>]*)?>(.*?)</w:t>", p, re.S)
    txt = "".join(texts)
    txt = re.sub(r"&lt;", "<", txt)
    txt = re.sub(r"&gt;", ">", txt)
    txt = re.sub(r"&amp;", "&", txt)
    paras.append(txt)

full = "\n".join(paras)
with open(OUT, "w", encoding="utf-8") as f:
    f.write(full)

non_empty = [p for p in paras if p.strip()]
print(f"总段落 {len(paras)}，非空 {len(non_empty)}，总字符 {len(full)}")
print("===== 全文 =====")
print(full)
