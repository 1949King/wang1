# -*- coding: utf-8 -*-
"""形象包 v4：新增 3 套「现代风格涂装」（同一拾岚的替换外观 / skin）。

概念：涂装 = 同一角色的替换外观，**不是新角色**。
因此 4 项锁死不变（比例 / 面部 / 狐耳狐尾 / 背景语汇），只换服装 + 动作细节。
"""
import io
import json
import os
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"

RATIO = ("【比例·必须严格遵守】7.5头身；头宽:肩宽≈1:2.2；腰线偏高，腿长占身高约55%；躯干修长。"
         "禁止Q版、禁止短身、禁止大头。"
         "【面部·成年人脸型】鹅蛋/卵形脸，脸长:脸宽≈1.4:1；下颌线清晰，下巴略尖；"
         "眼睛细长、眼尾微上扬，眼裂宽度约占脸宽1/3（不要大圆眼），双眼皮明确，瞳色青蓝；"
         "神态温婉含笑、眼神温润。"
         "【体态】颈部修长（颈长≈1/3头高）；肩线舒展；手臂修长、手指细长；端庄不暴露。")

CHAR = ("一对狐狸兽耳（耳内侧浅色绒毛，耳姿自然放松、一只微垂，不竖立警觉）；"
        "一条蓬松狐尾自然盘落在身侧后方，尾尖由深蓝渐变为浅白蓝。"
        "深蓝黑长卷发，刘海一撮品牌蓝(#3b82f6)挑染。戴一副细金丝圆框眼镜。")

BG = ("深夜室内，身后一扇拱形窗，窗外是极简夜色城市轮廓剪影与一轮浅月；"
      "身后墙面横贯一条柔和发光的时间线光带，带上散布几个极小的节点光点；"
      "前景工作台边缘，桌上有一杯冒热气的茶与一盏暖橙小灯。"
      "光照：左侧屏幕蓝光为主光，右侧暖橙灯为辅助光，在肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。")

STYLE = ("【风格】精致二次元插画，赛璐璐平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
         "构图居中、全身入画并留出上下留白。竖版3:4。")

MODERN = [
    {
        "id": "mascot-005",
        "title": "拾岚·现代涂装①知性通勤",
        "category": "portrait",
        "tags": ["现代涂装", "替换外观", "skin", "通勤", "风衣", "成人比例", "竖版"],
        "prompt": (
            "二次元兽耳娘角色全身立绘，成年女性，端庄优雅的温柔大姐姐气质，完全着装、非性化。"
            + RATIO + "【角色】" + CHAR
            + "【衣装·现代都市知性通勤装】深蓝(#1c2638)高领细针织打底，外搭一件剪裁利落的深蓝长款羊毛风衣"
              "（肩线挺括、腰带有系带），下配同色系直筒长裤与深蓝低跟短靴；"
              "颈间一条细长的青绿色(#2dd4bf)真丝围巾自然垂落；腕间一块简约银色细表；"
              "胸前别一枚小小的胶片/剪影形状银质胸针。材质为针织与羊毛的柔哑质感对比，端庄不暴露。"
            + "【动作】左手抱着一台合上的深蓝笔记本电脑贴在身侧，右手在胸前轻轻扶着眼镜镜框；"
              "站姿端正、重心稳，头微微侧向观者，不扭转、不卖萌。"
            + "【背景】" + BG + STYLE
        ),
    },
    {
        "id": "mascot-006",
        "title": "拾岚·现代涂装②居家舒适",
        "category": "portrait",
        "tags": ["现代涂装", "替换外观", "skin", "居家", "针织开衫", "温暖", "成人比例", "竖版"],
        "prompt": (
            "二次元兽耳娘角色全身立绘，成年女性，端庄温柔的大姐姐气质，完全着装、非性化。"
            + RATIO + "【角色】" + CHAR
            + "【衣装·现代居家舒适装】深蓝(#1c2638)宽松长款针织开衫（袖口翻折），"
              "内搭浅灰圆领长袖针织衫，下配深蓝宽松直筒家居长裤与浅色厚绒居家袜；"
              "颈间围着一条柔软的浅灰长围巾。整体是「舒适、干净、可以下楼取快递」的居家状态，"
              "完全着装、明确避开睡衣与性感居家服的语汇，端庄不暴露。"
            + "【动作】靠坐在一张软椅中（非沙发深陷），双手捧着一只冒热气的素色马克杯靠近胸口，"
              "肩膀放松、重心稳；眼神温润平视观者，嘴角有很轻的弧度。不去扶眼镜，"
              "姿态安静不扭扭捏捏、不卖萌。"
            + "【背景】深夜居家工作角；近景右侧一盏暖橙台灯（较亮、重点是灯与茶），"
              "背景左侧屏幕蓝光较弱；身后墙面横贯一条柔和发光的时间线光带，带上散布几个极小的节点光点；"
              "桌面散落几页纸与一支笔。在她肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。"
              "【风格】精致二次元插画，赛璐璐平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
              "温暖安静的氛围，构图居中、全身入画并留出上下留白。竖版3:4。"
        ),
    },
    {
        "id": "mascot-007",
        "title": "拾岚·现代涂装③机能创客",
        "category": "portrait",
        "tags": ["现代涂装", "替换外观", "skin", "机能", "创客", "节点卡", "成人比例", "竖版"],
        "prompt": (
            "二次元兽耳娘角色全身立绘，成年女性，干练而温柔的知性大姐姐气质，完全着装、非性化。"
            + RATIO + "【角色】" + CHAR
            + "（发型改为低马尾）"
            + "【衣装·现代都市机能创客风】深蓝(#1c2638)简约立领机能夹克"
              "（**剪裁干净、裤子为无侧袋的简约直筒款**，明确避开野外工装、战术装备与多口袋工装裤），"
              "内搭米白高领打底，下配深蓝修身直筒机能裤与干净的白色低帮运动鞋；"
              "颈间挂一副头戴式剪辑耳机；腕间一条深色编织表带。"
              "整体是「工作室里的设计师」而非「户外行动派」。"
            + "【动作】左手插在夹克口袋里，右手抬起、用指节轻点空气中一张悬浮的节点卡片"
              "（卡片发出柔和蓝光、卡片上有节点连线图）；站姿放松但端正，肩线舒展、重心稳，"
              "头微侧看向那张卡片，不扭身、不叉腰。"
            + "【背景】深夜工作室内，背景可见两块屏幕（左侧显示代码与波形，右侧显示画面预览）"
              "与一条发着蓝光的细长时间线光带（带播放头与节点光点）；右侧一盏暖橙小灯；"
              "在肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。"
              "【风格】精致二次元插画，赛璐璐平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
              "科技感但**不冷硬**（暖光比重足够），构图居中、全身入画并留出上下留白。竖版3:4。"
        ),
    },
]

PACK_PATH = os.path.join(C, "public", "prompts", PACK)
data = json.load(io.open(PACK_PATH, encoding="utf-8"))
have = {e["id"] for e in data}
added = [e for e in MODERN if e["id"] not in have]
data.extend(added)
content = json.dumps(data, ensure_ascii=False, indent=2) + "\n"

print("=" * 74)
print("① 追加 %d 条现代涂装（共 %d 条）" % (len(added), len(data)))
print("=" * 74)
for p in [os.path.join(C, "public", "prompts", PACK), os.path.join(C, "dist", "prompts", PACK),
          os.path.join(T, "public", "prompts", PACK), os.path.join(T, "dist", "prompts", PACK)]:
    if not os.path.isdir(os.path.dirname(p)):
        continue
    io.open(p, "w", encoding="utf-8").write(content)
    print("  ✅ %s (%d 字节)" % (os.path.relpath(p, ROOT).replace("\\", "/"), os.path.getsize(p)))
print()

print("=" * 74)
print("② 收 3 张图")
print("=" * 74)
IMGS = [
    ("二次元兽耳娘角色全身立绘_成年女性_端庄优雅的温柔大姐姐气质_2026-09-25T11-37-26.png",
     "shilan-涂装01-知性通勤.png"),
    ("二次元兽耳娘角色全身立绘_成年女性_端庄温柔的大姐姐气质_完_2026-09-25T11-37-52.png",
     "shilan-涂装02-居家舒适.png"),
    ("二次元兽耳娘角色全身立绘_成年女性_干练而温柔的知性大姐姐气_2026-09-25T11-38-16.png",
     "shilan-涂装03-机能创客.png"),
]
DSTD = os.path.join(ROOT, "assets", "mascot")
for src, dst in IMGS:
    sp = os.path.join(ROOT, "generated-images", src)
    dp = os.path.join(DSTD, dst)
    if os.path.exists(sp):
        shutil.copy2(sp, dp)
        print("  ✅ %s (%.1f KB)" % (dst, os.path.getsize(dp) / 1024.0))
    else:
        print("  ❌ 缺源图 %s" % src)
print()

print("=" * 74)
print("③ 核验")
print("=" * 74)
a = io.open(os.path.join(C, "src", "promptLibrary.ts"), "rb").read()
b = io.open(os.path.join(T, "src", "libtv", "promptLibrary.ts"), "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b else "❌"))
print("  JSON 合法: ✅ 条目 %d（%s）" % (len(json.loads(content)), ", ".join(e["id"] for e in data)))
r = subprocess.run([sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
print("  双库校验 exit=%d  %s" % (r.returncode, r.stdout.decode("utf-8", "replace").strip().splitlines()[0]))
