# -*- coding: utf-8 -*-
"""验证 pre-commit 四道卡点的真实行为。"""
import os
import subprocess
import sys

ROOT = r"D:\拾光剪影"
PY = sys.executable

HOOKS = [
    ("冻结区守护", ["scripts/frozen_zone_guard.py"]),
    ("稳定性门禁", ["scripts/stability_gate.py"]),
    ("粘合层契约", ["_verify/check_glue_contract.py"]),
    ("架构守护", ["scripts/arch_guard.py"]),
]

for name, argv in HOOKS:
    p = os.path.join(ROOT, *argv[0].split("/"))
    if not os.path.exists(p):
        print("  ⚠️  %-12s 脚本不存在: %s" % (name, argv[0]))
        continue
    r = subprocess.run([PY, p], cwd=ROOT, capture_output=True)
    out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
    first = out.splitlines()[0] if out else "(无输出)"
    verdict = "✅ 通过" if r.returncode == 0 else "❌ 失败"
    print("  %s %-12s exit=%d  %s" % (verdict, name, r.returncode, first[:90]))
    if r.returncode != 0:
        for l in out.splitlines()[1:6]:
            print("        %s" % l[:100])
print()

print("=" * 74)
print("说明：钩子里若有 ❌，代表该项目当前存量未达标 ——")
print("      门禁的意义是「拦住新增」，不是「今天全绿」。")
print("      存量请走棘轮：先 --update 收基线，再逐步下调。")
