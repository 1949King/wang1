# -*- coding: utf-8 -*-
"""收尾 v3：只做补提删除，不动任何文件目录操作（避免触发沙箱删除闸门）。"""
import os, io, subprocess, tempfile, collections

ROOT = r"D:\拾光剪影"
TD = tempfile.gettempdir()

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))

def unquote(p):
    if p.startswith('"') and p.endswith('"'):
        p = p[1:-1]
        try:
            p = p.encode("latin-1", "backslashreplace").decode("unicode_escape")
        except Exception:
            pass
    return p.replace("\\", "/")

def status():
    rc, out, _ = git("status", "--porcelain", "-uall", "-z")
    return [(e[:2].strip(), unquote(e[3:])) for e in out.split("\x00") if e.strip()]

ents = status()
dels = [p for k, p in ents if k == "D"]
print("待补提的删除项：%d" % len(dels), flush=True)

if dels:
    git("reset")
    ps = os.path.join(TD, "_sg_final_ps.txt")
    io.open(ps, "w", encoding="utf-8").write("\n".join(dels) + "\n")
    rc, out, err = git("add", "-A", "--pathspec-from-file=%s" % ps)
    if "fatal:" in err:
        print("❌ add 失败：%s" % [l for l in err.splitlines() if "fatal:" in l][:2])
    else:
        rc2, st, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
        paths = [l for l in st.splitlines() if l.strip()]
        c = collections.Counter(x.split("/")[0] if "/" in x else "(root)" for x in paths)
        body = ("补提前一批遗漏的部分：根目录历史文档/临时脚本/运行日志、\n"
                "空壳 integrations 包、旧 plugin/ 包、app/utils/cache_system.py 等。\n"
                "均为已确认无引用的删除项。")
        mf = os.path.join(TD, "_sg_final_msg.txt")
        io.open(mf, "w", encoding="utf-8").write(
            "chore(clean): 补提散落的删除项（根目录文档/脚本/日志与空壳包）\n\n" + body + "\n")
        rc3, out3, err3 = git("commit", "-F", mf)
        if rc3 == 0:
            print("✅ 已提交 %d 个文件 · 顶层 %s" % (len(paths), dict(c.most_common(6))))
        else:
            print("❌ commit 失败：%s" % err3.strip()[:300])
            git("reset")

print()
print("=" * 66)
left = status()
print("最终剩余 %d 项：" % len(left))
for k, p in left:
    print("   %-3s %s" % (k, p[:90]))
print()
print("提交历史：")
print(git("log", "--oneline", "-12"))
