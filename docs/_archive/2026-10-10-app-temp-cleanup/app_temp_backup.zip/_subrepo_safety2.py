# -*- coding: utf-8 -*-
"""副库回滚基线（最小必要集）：只提交 src/libtv/。

上一次尝试把 ViewModeSwitcher.tsx 一起纳入，触发副库自带 eslint（react-refresh 规则）
而失败。按「不跳钩子」的规矩，改为最小必要集：
  · 只纳入 src/libtv/（89 文件）—— 这才是「改了无法回滚」的真实风险区
  · 其余项目侧附件（models/prompts）暂不纳入，避免牵连 lint
"""
import io
import os
import subprocess

M = r"D:\拾光剪影"
T = os.path.join(M, "vendor", "AI-Canvas-tauri")


def gm(*a):
    return subprocess.run(["git"] + list(a), cwd=M, capture_output=True) \
        .stdout.decode("utf-8", "replace").strip()


NAME = gm("config", "user.name") or "1949King"
MAIL = gm("config", "user.email") or "1949King@users.noreply.github.com"


def gt(*a):
    r = subprocess.run(["git", "-c", "user.name=" + NAME, "-c", "user.email=" + MAIL] + list(a),
                       cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


print("=" * 74)
print("① 清空暂存区，只重加 src/libtv")
print("=" * 74)
print("  reset exit=%d" % gt("reset")[0])
rc, out, err = gt("add", "-A", "--", "src/libtv")
print("  add src/libtv exit=%d" % rc)
rc, out, _ = gt("diff", "--cached", "--name-only")
staged = [l for l in out.splitlines() if l.strip()]
print("  暂存 %d 个文件（全部应在 src/libtv/ 下）" % len(staged))
outside = [p for p in staged if not p.startswith("src/libtv/")]
print("  src/libtv 之外的暂存项: %s" % (outside if outside else "无"))
print()

print("=" * 74)
print("② 提交")
print("=" * 74)
msg = ("chore: 纳入项目侧画布副本 src/libtv，建立可回滚基线\n\n"
       "背景：src/libtv（项目侧画布副本）此前从未 git add，\n"
       "导致修改它时没有 git 回滚能力（项目文档已记录该风险）。\n"
       "本次仅本地提交，换取 git diff / git checkout 能力。\n\n"
       "WARNING: 本仓库 origin 为第三方仓库 (Tenney95/AI-Canvas-tauri)，请勿 push。\n"
       "未纳入本次提交：public/ 资源与 ViewModeSwitcher.tsx\n"
       "（后者触发 react-refresh lint，留待单独处理）")
mf = os.path.join(T, ".git", "_MSG.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = gt("commit", "-F", mf)
os.remove(mf)
print("  commit exit=%d" % rc)
if rc != 0:
    print("  stdout: %s" % out[:400])
    print("  stderr: %s" % err[:400])
else:
    print("  %s" % out.splitlines()[0])
print()

print("=" * 74)
print("③ 结果")
print("=" * 74)
print("  提交历史:")
for l in gt("log", "--oneline", "-3")[1].splitlines():
    print("     %s" % l)
print()
rc, out, _ = gt("ls-files", "src/libtv")
tracked = [l for l in out.splitlines() if l.strip()]
print("  src/libtv 已跟踪文件数: %d" % len(tracked))
print()
rc, out, _ = gt("status", "--porcelain")
left = [l for l in out.splitlines() if l.strip()]
print("  工作区剩余变更: %d 项（前 12）" % len(left))
for l in left[:12]:
    print("     %s" % l[:100])
print()

print("=" * 74)
print("④ 回滚能力实证（改一个文件 → diff → checkout 还原）")
print("=" * 74)
tgt = os.path.join(T, "src", "libtv", "canvasVersion.ts")
orig = io.open(tgt, encoding="utf-8").read()
io.open(tgt, "a", encoding="utf-8").write("// rollback-probe\n")
rc, out, _ = gt("diff", "--stat", "--", "src/libtv/canvasVersion.ts")
print("  git diff 可见: %s" % bool(out.strip()))
rc, out, err = gt("checkout", "--", "src/libtv/canvasVersion.ts")
ok = io.open(tgt, encoding="utf-8").read() == orig
print("  git checkout 还原成功: %s" % ok)
