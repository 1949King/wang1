# -*- coding: utf-8 -*-
"""侦察静默异常的可机械修复性：逐个看上下文 + logger 可用性。"""
import os
import io
import re

ROOT = r"D:\拾光剪影"
TARGETS = [
    "app/core/canvas_agent_runtime.py",
    "app/core/local_video_infer.py",
    "app/modules/lego/editor_agent_runtime_mixin.py",
    "app/core/project_agent_host.py",
    "app/core/ai/video_generation_client.py",
    "app/modules/lego/model_management.py",
    "app/core/preview_manager.py",
    "app/modules/lego/playback_shuttle.py",
    "app/main_qt6.py",
    "app/modules/lego/clip_transform.py",
    "app/core/canvas_runtime.py",
]

PAT = re.compile(r"([ \t]*)except([^:\n]*):\s*\n([ \t]*)pass\b")

for rel in TARGETS:
    p = os.path.join(ROOT, *rel.split("/"))
    if not os.path.exists(p):
        print("!! 缺失 %s" % rel)
        continue
    body = io.open(p, encoding="utf-8-sig", errors="replace").read()
    L = body.splitlines()
    hits = list(PAT.finditer(body))

    # logger 可用性
    has_import = bool(re.search(r"^import logging", body, re.M))
    has_logger = bool(re.search(r"^logger\s*=\s*logging\.getLogger", body, re.M))
    has_module_logger = bool(re.search(r"from .*log_manager import .*logger", body))
    has_self_logger = bool(re.search(r"self\.logger", body))
    has_lazy_logger = "logger" in body

    print("=" * 74)
    print("%s  (%d 行, %d 处 except:pass)" % (rel, len(L), len(hits)))
    print("  logger: import logging=%s  logger=getLogger=%s  from log_manager=%s  self.logger=%s  文中出现logger=%s"
          % (has_import, has_logger, has_module_logger, has_self_logger, has_lazy_logger))
    for m in hits[:6]:
        ln = body[:m.start()].count("\n") + 1
        indent = m.group(1)
        exc = m.group(2).strip()
        # 取前 3 行上下文
        ctx = L[max(0, ln - 4):ln - 1]
        print("    L%-5d indent=%-4s except%s:" % (ln, repr(indent), exc))
        for c in ctx:
            print("           | %s" % c.strip()[:96])
    if len(hits) > 6:
        print("    ... 另 %d 处" % (len(hits) - 6))
    print()
