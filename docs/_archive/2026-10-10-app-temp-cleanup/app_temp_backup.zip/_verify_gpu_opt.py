# -*- coding: utf-8 -*-
"""验证 GPU/依赖探测优化：① 编译 ② 行为等价性 ③ 冷启动实测对比。"""
import io
import os
import subprocess
import sys
import time

ROOT = r"D:\拾光剪影"
VENV = os.path.join(ROOT, ".venv312", "Scripts", "python.exe")
PY = VENV if os.path.exists(VENV) else sys.executable

print("=" * 74)
print("① 编译校验")
print("=" * 74)
p = os.path.join(ROOT, "app", "main_qt6.py")
body = io.open(p, encoding="utf-8-sig").read()
try:
    compile(body, p, "exec")
    print("  ✅ app/main_qt6.py 编译通过（%d 行）" % len(body.splitlines()))
except SyntaxError as e:
    print("  ❌ %s" % e)
    sys.exit(1)
print()

print("=" * 74)
print("② 行为等价性：find_spec（新）vs __import__（旧）对 16 个包的判定必须一致")
print("=" * 74)
names = ["PyQt6", "moviepy", "cv2", "torch", "transformers", "faster_whisper",
         "easyocr", "PIL", "numpy",           # required 9
         "mediapipe", "dashscope", "anthropic", "zhipuai", "gtts", "pynvml",
         "pypinyin"]                          # optional 7
code = r'''
import importlib.util, json, sys, time
names = %r
out = {}
t0 = time.time()
for n in names:
    try:
        r = importlib.util.find_spec(n) is not None
    except Exception:
        r = False
    out[n] = r
t_spec = time.time() - t0
t0 = time.time()
old = {}
for n in names:
    try:
        __import__(n); old[n] = True
    except Exception:
        old[n] = False
t_imp = time.time() - t0
same = {k: (out[k] == old[k]) for k in names}
print(json.dumps({"find_spec": out, "import": old, "same": same,
                  "t_spec": t_spec, "t_import": t_imp}, ensure_ascii=False))
''' % (names,)
r = subprocess.run([PY, "-c", code], cwd=ROOT, capture_output=True, timeout=900)
try:
    import json
    d = json.loads(r.stdout.decode("utf-8", "replace").strip().splitlines()[-1])
    allsame = all(d["same"].values())
    print("  %-18s %-10s %-10s %s" % ("包", "find_spec", "__import__", "一致"))
    for n in names:
        print("  %-18s %-10s %-10s %s" % (n, d["find_spec"][n], d["import"][n],
                                          "✅" if d["same"][n] else "❌ 不一致"))
    print()
    print("  判定完全一致: %s" % ("✅ 是" if allsame else "❌ 否 —— 不能采纳"))
    print("  耗时对比：find_spec 全部 16 个 = %.2fs ／ __import__ = %.2fs（省 %.1fs，%.0f×）"
          % (d["t_spec"], d["t_import"], d["t_import"] - d["t_spec"],
             d["t_import"] / max(d["t_spec"], 1e-6)))
except Exception as e:
    print("  ❌ 解析失败: %s" % e)
    print("  stdout: %s" % r.stdout.decode("utf-8", "replace")[:500])
    print("  stderr: %s" % r.stderr.decode("utf-8", "replace")[:500])
print()

print("=" * 74)
print("③ GPU 探测耗时对比（pynvml 快路径 vs torch 回退）")
print("=" * 74)
gpu_code = r'''
import time, json
res = {}
t0 = time.time()
try:
    import pynvml
    pynvml.nvmlInit()
    n = pynvml.nvmlDeviceGetCount()
    name = ""
    if n:
        h = pynvml.nvmlDeviceGetHandleByIndex(0)
        raw = pynvml.nvmlDeviceGetName(h)
        name = raw.decode("utf-8","replace") if isinstance(raw, bytes) else str(raw)
    pynvml.nvmlShutdown()
    res["pynvml"] = {"ok": True, "count": n, "name": name, "t": round(time.time()-t0, 3)}
except Exception as e:
    res["pynvml"] = {"ok": False, "err": str(e)[:80], "t": round(time.time()-t0, 3)}
t0 = time.time()
try:
    import torch
    ok = torch.cuda.is_available()
    res["torch"] = {"ok": bool(ok), "name": torch.cuda.get_device_name(0) if ok else "",
                    "t": round(time.time()-t0, 3)}
except Exception as e:
    res["torch"] = {"ok": False, "err": str(e)[:80], "t": round(time.time()-t0, 3)}
print(json.dumps(res, ensure_ascii=False))
'''
r = subprocess.run([PY, "-c", gpu_code], cwd=ROOT, capture_output=True, timeout=900)
try:
    import json
    d = json.loads(r.stdout.decode("utf-8", "replace").strip().splitlines()[-1])
    pv, tt = d["pynvml"], d["torch"]
    print("  pynvml : ok=%s count=%s name=%s  耗时 %.2fs"
          % (pv.get("ok"), pv.get("count"), pv.get("name"), pv.get("t", -1)))
    print("  torch  : ok=%s name=%s  耗时 %.2fs"
          % (tt.get("ok"), tt.get("name"), tt.get("t", -1)))
    if pv.get("ok") and pv.get("name"):
        print("  ⇒ 设备名一致: %s" % ("✅" if pv["name"] == tt.get("name") else
                                      "⚠️ pynvml=%r vs torch=%r" % (pv["name"], tt.get("name"))))
    print("  ⇒ 节省 %.2fs" % (tt.get("t", 0) - pv.get("t", 0)))
except Exception as e:
    print("  ❌ 解析失败: %s" % e)
    print("  stdout: %s" % r.stdout.decode("utf-8", "replace")[:400])
