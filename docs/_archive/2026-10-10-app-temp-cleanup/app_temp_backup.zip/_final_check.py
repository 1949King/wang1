# -*- coding: utf-8 -*-
import os, subprocess, collections
ROOT = r"D:\拾光剪影"

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return r.stdout.decode("utf-8", "replace").strip()

print("=== 提交历史（本次新增的排前面）===")
print(git("log", "--oneline", "-12"))
print()

print("=== 每个提交的真实文件数 + 顶层分布 ===")
log = git("log", "--format=%h|%s|%ci", "d67f80a..HEAD")
for line in log.splitlines():
    if not line.strip():
        continue
    h, subj, ci = line.split("|", 2)
    out = subprocess.run(["git", "-c", "core.quotePath=false", "show", "--stat",
                          "--format=", h], cwd=ROOT,
                         capture_output=True).stdout.decode("utf-8", "replace")
    paths = []
    for l in out.splitlines():
        l = l.strip()
        if not l or "|" not in l:
            continue
        p = l.split("|")[0].strip().replace("\\", "/")
        paths.append(p)
    c = collections.Counter(x.split("/")[0] if "/" in x else "(root)" for x in paths)
    print("  %s  %s" % (h, subj[:56]))
    print("       %s · %d 个文件 · %s" % (ci[:16], len(paths), dict(c.most_common(5))))
print()

print("=== 剩余未处理项 ===")
out = subprocess.run(["git", "-c", "core.quotePath=false", "status", "--porcelain", "-uall"],
                     cwd=ROOT, capture_output=True).stdout.decode("utf-8", "replace")
for l in out.splitlines():
    print("  ", l)
print("  合计 %d" % len([x for x in out.splitlines() if x.strip()]))
