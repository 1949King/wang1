# -*- coding: utf-8 -*-
"""提交 v3 + 沉淀「去幼态」解剖参数清单。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """fix(canvas): 形象包 v3 —— 修正解剖参数去幼态（4头身→6.5头身）

用户反馈 v2「还是有一点幼态感」，并提供了 4 张参考图（含一张完整角色设定卡与
一张成熟拟人娘）。逐条比对后定位到**6 处解剖参数**，其中前两条是决定性的：

① 头身比 4 → 6.5~7.5（最根本：4头身读作"少年"，6.5+ 才读作"成年"）
② 眼裂宽占脸 1/2 → 1/3，且眼型改细长、眼尾微上扬
③ 圆脸短下巴 → 卵形脸、下颌线清晰、下巴略尖
④ 短颈窄肩 → 修长颈（≈1/3头高）+ 肩线舒展
⑤ 头大身短 → 腰线高、腿长占身高 55%
⑥ 手小指短 → 手修长、手指细长

根本错误：v2 同时要求「Q版」与「大姐姐」——两者互斥（Q版画法天生幼态化）。

本次改动：
· 4 条提示词全部加入强制比例段（7.5头身/眼裂1/3/卵形脸/修长颈/腿长55%）
· 主形象明确「无高开衩」（v3 图右侧开衩偏高，与端庄有轻微张力，已写入约束）
· 产出 assets/mascot/shilan-主形象卡-v3-成年比例.png

参考图提取到的有效信息：
· 图2（角色设定卡）：7头身、修长颈肩、卵形脸、窄长眼、克制表情 —— 比例规范的样板
· 图4（DeepSeek 拟人娘）：深蓝紫 + 华丽礼裙 + 成熟身材 ⇒ 与项目品牌深蓝同色系，方向站得住

双库同步：4 处 JSON 一致；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psB.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "assets/mascot/shilan-主形象卡-v3-成年比例.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgB.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("② 提交副库")
print("=" * 74)
gt("add", "-A", "--", "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M4.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "fix(libtv): 同步形象包 v3（解剖参数去幼态）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v3：去幼态 —— 幼态感的 6 个解剖参数（可复用诊断清单）

用户反馈 v2「还是有一点幼态感，是身体比例不对吗」，并提供 4 张参考图
（含一张完整**角色设定卡**三视图+表情卡，与一张 **DeepSeek 拟人娘**）。

### ⚠️ 可复用的诊断清单：幼态感来自这 6 处解剖参数（按权重）

| # | 幼态信号 | 幼态值 | 成年值 | 权重 |
|---|---|---|---|---|
| 1 | **头身比** | 2–4 头身（幼儿/少年） | **6.5–8 头身**（青年/成年） | ★★★ 最根本 |
| 2 | **眼裂宽占脸宽** | ≈1/2（娃娃眼） | **≈1/3，且眼型细长、眼尾微上扬** | ★★★ |
| 3 | 脸型/下颌 | 圆脸、下颌圆润、下巴短 | **卵形脸、下颌线清晰、下巴略尖、脸长:脸宽≈1.4:1** | ★★ |
| 4 | 颈长/肩宽 | 短颈、窄肩 | **颈长≈1/3 头高、肩线舒展** | ★★ |
| 5 | 躯干与腿 | 头大身短 | **腰线高、腿长占身高 55%** | ★★ |
| 6 | 手 | 小而短 | **手修长、手指细长**（成人手≈身高 1/9~1/10） | ★ |

### 🚫 根本矛盾（我做错的地方）
**v2 同时要求了「Q版」与「温柔大姐姐」—— 这两个词互斥。**
Q 版（2–4 头身）这套画法**天生就是幼态化**的：大头、大眼、圆脸、短身。
**想要"大姐姐"，必须放弃 Q 版，改用 6.5–8 头身的成年画法。**

### 参考图提取的有效信息（用户提供的 4 张）
- **图2（角色设定卡三视图 + 6 表情 + 靴子细节标注）**：7 头身、修长颈肩、卵形脸、
  窄长眼、克制表情（"温柔笑/坚定"而非"萌"）⇒ **比例规范的样板**，
  也是"跨图一致性"该有的交付形态（三视图 + 表情卡 + 部件特写）
- **图4（DeepSeek/GPT 拟人娘，2.7万赞）**：深蓝紫 + 华丽礼裙 + 成熟身材 + 冷艳气场
  ⇒ **与项目品牌深蓝（#3b82f6）天然同色系，方向站得住** —— 证明我的配色方向没错，
  错的是把比例做塌了
- 图1/图3：偏清纯少女（比 2/4 更幼），对"蓝白配色 + 光效"有参考价值

### v3 结果
4→6.5 头身、眼裂 1/3、卵形脸尖下巴、修长颈肩、细长手、狐耳放松微垂、狐尾盘落
⇒ **幼态感基本消除**（脱离"少年"区，进入"成年"区）

### 遗留（已在提示词里加约束，供下轮验证）
- v3 图右侧**开衩偏高**（模型自行添加）⇒ 提示词已加"无高开衩，开衩不高于膝"
- 头身比 6.5（目标是 7.5）⇒ 若要完全达标可再加权
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v3" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
