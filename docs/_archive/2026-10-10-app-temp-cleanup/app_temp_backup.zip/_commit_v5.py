# -*- coding: utf-8 -*-
"""提交 v5（女性化修正）+ 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
TD = tempfile.gettempdir()
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")


def git(*a, cwd=ROOT):
    r = subprocess.run(["git"] + list(a), cwd=cwd, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


def gt(*a):
    n = git("config", "user.name")[1].strip() or "1949King"
    m = git("config", "user.email")[1].strip() or "x@y.z"
    return git("-c", "user.name=" + n, "-c", "user.email=" + m, *a, cwd=T)


MSG = """fix(canvas): 形象包 v5 —— 修「偏男性」，新增身体轮廓段 + 女性化修正示范图

用户指出「这几张偏男性风格」。诊断：**矫正过度**。
为去幼态，我用的是「去女性化」手段（去曲线/去腰线/挺括肩线），
而不是「成年女性化」手段 ⇒ 从「幼态少女」直接跳到「中性/偏男性」。

5 个信号 → 修正：
① 剪裁轮廓  H型直筒      → X型（收腰）/ A型（垂坠展开）
② 腰线      3套全无      → 明确收腰（自然腰位或稍高）
③ 肩线      挺括垫肩感   → 柔肩/连肩/落肩
④ 领型/颈线 高领遮住     → 露出颈部与锁骨（端庄不开深）
⑤ 下装      长裤         → 裙装（及膝）
⑥ 色彩      全低饱和深蓝 → 深蓝为主 + 浅色/柔色块面

本次改动：
· 新增【身体轮廓·关键】常量段，注入 005/006/007 三条现代涂装
  （含负向约束：禁止直筒无腰H型廓形、禁止挺括垫肩、禁止全深色无层次）
· 005 通勤：高领→V领；风衣挺括肩→柔肩薄外套；直筒裤→收腰及膝A字裙 + 细腰带
· 006 居家：开衫放宽→腰线自然可见；围巾不裹下巴、露出颈线；加浅灰米白色块
· 007 机能：立领夹克→柔肩收腰短外套；去低马尾（偏低干练中性）→柔和披落/半束；
  加V领露颈线；配色块平衡
· 新增 mascot-008「现代涂装④优雅女装（女性化修正版）」—— 已出图验证有效：
  X型收腰 + 柔肩 + V领露颈 + 及膝裙 + 米白/浅蓝纵向色块 + 长发披落

产出图：assets/mascot/shilan-涂装04-优雅女装-女性化修正.png
双库同步：4 处 JSON 一致（8 条）；双库校验仍 分叉 0

WARNING: 仅本地提交，未 push。"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_psD.txt")
io.open(ps, "w", encoding="utf-8").write(
    "vendor/shiguang-canvas/public/prompts/shiguang-mascot.json\n"
    "assets/mascot/shilan-涂装04-优雅女装-女性化修正.png\n")
git("add", "-A", "--pathspec-from-file=" + ps)
mf = os.path.join(TD, "_msgD.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

print("=" * 74)
print("② 提交副库")
print("=" * 74)
gt("add", "-A", "--", "public/prompts/shiguang-mascot.json")
mf2 = os.path.join(T, ".git", "_M6.txt")
io.open(mf2, "w", encoding="utf-8").write(
    "fix(libtv): 同步形象包 v5（身体轮廓段 + 女性化修正）\n\n"
    "与主库 vendor/shiguang-canvas 保持一致。\n\n"
    "WARNING: origin 为第三方仓库，请勿 push。")
rc, out, err = gt("commit", "-F", mf2)
os.remove(mf2)
print("  exit=%d  %s" % (rc, (out.splitlines()[0] if out else err[:200])))
print()

NOTE = """
## 形象包 v5：修「偏男性」—— 矫正过度的诊断与修正（01:41 - 02:00）

用户问：「你会不会觉得这几张偏男性风格，这合适吗？」→ **判断准确，我认。**

### 根因：**矫正过度**（这是本轮最有价值的设计教训）

```
v2 幼态            我的解法                  结果
大头大眼圆脸   →   拉长比例、缩小眼、     →   从「幼态少女」直接跳到
无曲线无腰线        拉长脸 + **去曲线去腰线**     「中性 / 偏男性」
                    ↑ 问题在这：手段错了
```

**我用来「去幼态」的手段，本身是「去女性化」的** —— 而正确目标应是「成年**女性化**」。
「拉长比例」是对的，「去掉曲线与腰线」是错的。

### ⚠️ 可复用清单：女性化 vs 男性化的 6 个信号

| # | 信号 | 偏男性/中性 | 女性化 |
|---|---|---|---|
| 1 | **剪裁轮廓** | H 型（直筒，直上直下） | **X 型（收腰）/ A 型（垂坠展开）** |
| 2 | **腰线** | 无腰线或被宽松遮蔽 | **明确收腰**（自然腰位或稍高） |
| 3 | **肩线** | 挺括/垫肩感（加宽上半身） | **柔肩/连肩/落肩** |
| 4 | **领型与颈线** | 高领/立领遮住颈部 | **露出颈部与锁骨**（端庄不开深） |
| 5 | **下装** | 长裤 | **裙装（及膝）** |
| 6 | **色彩** | 全低饱和深色（稳重＝偏中性） | 深色为主 + **浅色/柔色块面**平衡 |

**辅助信号**：发型（低马尾＝干练中性；长发披落/半束＝柔）、姿态（插兜/叉腰＝中性；手轻搭腰侧＝优雅）、
材质（硬挺＝中性；真丝/雪纺垂坠＝柔）

### 关键反直觉发现
**v3 的东方礼服并不偏男性** —— 因为「丝缎垂坠 + 纱质披肩 + 流苏 + 绣纹」这些材质语言本身就是柔的。
问题**只出在 3 套现代装的硬挺直线剪裁**上。
⇒ **材质与廓形对性别气质的影响，大于颜色与图案。**

### 修正落地
- 新增【身体轮廓·关键】常量段，注入 005/006/007（含 3 条负向约束：
  禁止直筒无腰H型廓形 / 禁止挺括垫肩 / 禁止全深色无层次）
- 007 特别去掉**低马尾**（低马尾读作干练中性）
- 新增 mascot-008「优雅女装（女性化修正版）」，已出图验证：
  X型收腰 + 柔肩 + V领露颈 + 及膝裙 + 米白/浅蓝纵向色块 + 长发披落
  ⇒ 明显读作女性/优雅，修正成功

### 三张修正对照（供以后复用）
| 维度 | 涂装01（中性） | 涂装04（女性化修正） |
|---|---|---|
| 轮廓 | H型直筒 | **X型：收腰 + 微A字裙摆** |
| 腰线 | 无 | **腰带收出（金属扣可见）** |
| 肩线 | 挺括垫肩感 | **连肩/落肩柔和** |
| 领型 | 高领遮住 | **V领露颈部锁骨** |
| 下装 | 直筒长裤 | **及膝连衣裙** |
| 色彩 | 全深蓝 | 深蓝 + **米白/浅蓝纵向色块** |
"""
b = io.open(MEM, encoding="utf-8").read() if os.path.exists(MEM) else "# 2026-09-26 工作记录\n"
if "形象包 v5" in b:
    print("  记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(b.rstrip("\n") + "\n" + NOTE)
    print("  记忆已写入 -> %d bytes" % os.path.getsize(MEM))
