# -*- coding: utf-8 -*-
"""量化 src/libtv 在副库 eslint 规则下的错误规模，决定处理方式。"""
import io
import json
import os
import subprocess

T = r"D:\拾光剪影\vendor\AI-Canvas-tauri"
NODE = r"C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3\node.exe"

print("=" * 74)
print("① 副库 eslint 相关配置")
print("=" * 74)
pkg = json.load(io.open(os.path.join(T, "package.json"), encoding="utf-8"))
print("  scripts: %s" % json.dumps(pkg.get("scripts", {}), ensure_ascii=False)[:300])
cfg = os.path.join(T, "eslint.config.js")
print("  eslint.config.js 大小: %d B" % os.path.getsize(cfg))
body = io.open(cfg, encoding="utf-8", errors="replace").read()
L = body.splitlines()
print("  行数 %d；ignores / rules 关键行：" % len(L))
for i, l in enumerate(L, 1):
    if "ignores" in l or "no-explicit-any" in l or "files:" in l:
        print("     L%-3d %s" % (i, l.strip()[:100]))
print()

print("=" * 74)
print("② 跑 eslint 统计 src/libtv 的错误数")
print("=" * 74)
eslint_bin = os.path.join(T, "node_modules", "eslint", "bin", "eslint.js")
if not os.path.exists(eslint_bin):
    print("  ⚠️ 未找到 node_modules/eslint/bin/eslint.js")
else:
    r = subprocess.run([NODE, eslint_bin, "src/libtv", "--format", "json"],
                       cwd=T, capture_output=True, timeout=600)
    try:
        data = json.loads(r.stdout.decode("utf-8", "replace"))
    except Exception as e:
        print("  解析失败: %s" % e)
        print("  stderr: %s" % r.stderr.decode("utf-8", "replace")[:400])
        data = None
    if data:
        total_err = total_warn = 0
        by_rule = {}
        by_file = {}
        for f in data:
            for m in f.get("messages", []):
                if m.get("severity") == 2:
                    total_err += 1
                elif m.get("severity") == 1:
                    total_warn += 1
                if m.get("severity") == 2:
                    rule = m.get("ruleId") or "(fatal)"
                    by_rule[rule] = by_rule.get(rule, 0) + 1
                    fn = os.path.relpath(f["filePath"], T).replace("\\", "/")
                    by_file[fn] = by_file.get(fn, 0) + 1
        print("  error=%d  warning=%d" % (total_err, total_warn))
        print()
        print("  按规则:")
        for k, v in sorted(by_rule.items(), key=lambda x: -x[1]):
            print("     %-34s %d" % (k, v))
        print()
        print("  按文件 TOP 10:")
        for k, v in sorted(by_file.items(), key=lambda x: -x[1])[:10]:
            print("     %3d  %s" % (v, k))
