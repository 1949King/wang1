# -*- coding: utf-8 -*-
"""提交主仓（第⑤道卡点 + 文档）+ 写记忆。"""
import io
import os
import subprocess
import tempfile

ROOT = r"D:\拾光剪影"
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-25.md")
TD = tempfile.gettempdir()


def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


PATHS = [".pre-commit-config.yaml", "docs/现行技术文档.md"]
MSG = """fix(guards): 补上双库一致性卡点（S1 的核心交付）+ 修 autocrlf 假分叉

## 1. 补上第 ⑤ 道卡点：双库一致性
S1 的交付不是「合并一次」，而是「装卡点防复漂」——
项目上次把双库合并到分叉 0 后又漂回 24 个文件，就是缺这个卡点。

关键实现细节：必须 always_run: true。
副库 vendor/AI-Canvas-tauri/ 在主仓被 gitignore，它的改动永远不会出现在
主仓暂存清单里 ⇒ 靠 files: 过滤的钩子永不触发、形同虚设。

## 2. 修「守卫常红但归因不明」的真因：autocrlf 改写行尾
收敛后双库校验仍报 canvasVersion.ts 分叉，但两文件逐行相同、解码 md5 一致。
实测：主库 LF / 副库工作区 CRLF（副库 core.autocrlf=true 在 checkout 时改写），
而 git status 因比较前归一化显示「干净」⇒ 守卫常红、git 说没事、看不出为什么。

修法：① 副库 core.autocrlf=false ② .gitattributes 对 src/libtv/** 设 -text
     ③ 重建工作区（⚠️ git checkout -f 无效——stat 缓存判定"干净"会跳过重写，
        必须先删除文件再 checkout）

## 3. 卡点有效性实证（不只看它「存在」）
制造漂移 → exit=1 拦住；还原 → exit=0 恢复。字节级分叉 1 → 0。

## 4. 副库 lint 边界（ae7d100）
src/libtv 是移植进来的画布源码，实测 228 条宿主规则冲突，且集中在
CanvasShell.tsx / Stage3D.tsx / store.ts —— 这些文件在主库是冻结区，
为满足宿主 lint 去改会变重构并加重漂移。按「移植代码沿用来处纪律」加豁免；
并给副库 pre-commit 的 eslint 加 --no-warn-ignored（否则被忽略文件的 warning
会被 --max-warnings=0 升级成失败、堵死提交）。

WARNING: 仅本地提交，未 push。
"""

print("=" * 74)
print("① 提交主仓")
print("=" * 74)
ps = os.path.join(TD, "_ps5.txt")
io.open(ps, "w", encoding="utf-8").write("\n".join(PATHS) + "\n")
git("add", "-A", "--pathspec-from-file=" + ps)
rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
print("  暂存: %s" % [l for l in out.splitlines() if l.strip()])
mf = os.path.join(TD, "_msg5.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  commit exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

NOTE = """
## 对账 + 补缺口（23:18 - 23:45）· 主仓补提交 + 副库 ae7d100

用户问：「所以有解决刚才那些文案提到的问题吗？」

### 自查发现一个关键缺口（必须坦白）

**S1 的核心交付是「装卡点防复漂」，但我上一轮没把双库校验接进 pre-commit。**
⇒ 漂移本身收敛了（24→0），但**不装卡点必然复漂**（上次就是这么复漂的）。
已补：`.pre-commit-config.yaml` 第 ⑤ 道卡点 `canvas-dual-repo`。

关键实现细节：**必须 `always_run: true`** —— 副库在主仓被 gitignore，
其改动永远不出现在主仓暂存清单里，靠 `files:` 过滤会永不触发、卡点形同虚设。

### 卡点有效性实证（不只看它「存在」）

制造漂移 → exit=1 拦住；还原 → exit=0 恢复 ⇒ **拦得住、放得过**。

### 顺带修掉「守卫常红但归因不明」的真因（新发现）

收敛后双库校验仍报 `canvasVersion.ts` 分叉，**但两文件逐行相同、解码后 md5 一致**。实测：

| 位置 | 行尾 |
|---|---|
| 主库 | 31 × LF |
| 副库工作区 | 31 × CRLF |
| 副库索引/HEAD | 31 × LF（正确） |

副库 `core.autocrlf=true` ⇒ checkout 把 LF 写成 CRLF；而 `git status` **比较前归一化**
⇒ 显示「干净」⇒ **守卫常红、git 说没事、看不出为什么**。

> 这与技术债报告里的 `stability_gate` 因草稿噪声长期红、`arch_guard` 无参空转
> **属同一类病**：守卫报红但归因不明 → 于是没人看 → 等于没有守卫。

修法三步（顺序不能反）：① 副库 `core.autocrlf=false` ② `.gitattributes` 设 `src/libtv/** -text`
③ 重建工作区。
⚠️ 坑：**`git checkout -f` 无效** —— stat 缓存判定"干净"会跳过重写，必须**先删文件再 checkout**。

### 本轮对账结论（诚实版）

**已解决**：S1 双库漂移（24→0）+ **卡点已装** · S3 副库回滚能力 · A1 静默异常 98→30 处
（含冻结区 9 处须先解冻）· 报告外的两项新增（粘合层契约层、三世界观冲突策略）。

**未做**（仍是 P1/P2）：S2 拆 editor_module（9,717 行）· A2 未接线模块 5 处 ·
A3 测试真实通过率未知 · A4 内联样式 938 处 · B1 同名类 52 组 · B2 重复体系 4 组 ·
B3 悬空引用 · B4 .git 2,898MB。

**部分**：C 级 print（稳定性门禁已含规则、基线内 29 项）。
"""

existing = io.open(MEM, encoding="utf-8").read()
if "对账 + 补缺口" in existing:
    print("ALREADY_PRESENT")
else:
    io.open(MEM, "w", encoding="utf-8").write(existing.rstrip("\n") + "\n" + NOTE)
    print("② 记忆已写入 -> %d bytes" % os.path.getsize(MEM))
