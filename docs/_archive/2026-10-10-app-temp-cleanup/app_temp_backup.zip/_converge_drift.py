# -*- coding: utf-8 -*-
"""双库漂移收敛：以主库(shiguang-canvas)为真源，同步分叉文件到副库(libtv)。

安全闭环（缺一不可）：
  ① 同步前测 tsc 错误数（基线）
  ② 只同步「两边都存在且内容不同」的文件（新增/缺失的一律不动，避免扩大面）
  ③ 同步后重测 tsc，错误数不得增加；增加则 git checkout 回滚
  ④ 全部通过才提交

用法：python _converge_drift.py [--apply]
"""
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
MAIN = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
SUB = os.path.join(ROOT, "vendor", "AI-Canvas-tauri", "src", "libtv")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
NODE = r"C:\Users\Administrator\.workbuddy\binaries\node\versions\22.22.2-3\node.exe"
APPLY = "--apply" in sys.argv

SKIP_DIRS = {"node_modules", "dist", "__pycache__"}


def files_under(base):
    out = {}
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in SKIP_DIRS]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css", ".json")):
                rel = os.path.relpath(os.path.join(dp, f), base).replace("\\", "/")
                out[rel] = os.path.join(dp, f)
    return out


def md5(p):
    return hashlib.md5(io.open(p, "rb").read()).hexdigest()


def run_tsc():
    """跑副库 tsc，返回 (错误数, 原始输出尾部)。"""
    bin_tsc = os.path.join(T, "node_modules", "typescript", "bin", "tsc")
    if not os.path.exists(bin_tsc):
        bin_tsc = os.path.join(T, "node_modules", "typescript", "bin", "tsc.js")
    if not os.path.exists(bin_tsc):
        return -1, "tsc 不存在"
    r = subprocess.run([NODE, bin_tsc, "-b"], cwd=T, capture_output=True, timeout=1200)
    out = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace"))
    n = len(re.findall(r"error TS\d+", out))
    return n, "\n".join(out.splitlines()[-5:])


print("=" * 74)
print("① 分叉清单（两边都有但内容不同）")
print("=" * 74)
fa, fb = files_under(MAIN), files_under(SUB)
forked, only_main, only_sub = [], [], []
for k in sorted(set(fa) | set(fb)):
    if k in fa and k in fb:
        if md5(fa[k]) != md5(fb[k]):
            la = io.open(fa[k], encoding="utf-8", errors="replace").read().count("\n")
            lb = io.open(fb[k], encoding="utf-8", errors="replace").read().count("\n")
            forked.append((abs(la - lb), k, la, lb))
    elif k in fa:
        only_main.append(k)
    else:
        only_sub.append(k)
print("  分叉 %d · 仅主库有 %d · 仅副库有 %d" % (len(forked), len(only_main), len(only_sub)))
print()
for d, k, la, lb in sorted(forked, reverse=True):
    print("    差%5d行  %-46s 主库%5d / 副库%5d" % (d, k, la, lb))
print()

if not APPLY:
    print("DRY-RUN：加 --apply 执行同步（会先测 tsc 基线，异常自动回滚）")
    sys.exit(0)

print("=" * 74)
print("② tsc 基线（同步前）")
print("=" * 74)
n0, tail0 = run_tsc()
print("  错误数: %s" % n0)
print("  %s" % tail0.replace("\n", "\n  "))
print()

print("=" * 74)
print("③ 同步（主库 → 副库）")
print("=" * 74)
copied = []
for d, k, la, lb in sorted(forked, reverse=True):
    shutil.copy2(fa[k], fb[k])
    copied.append(k)
    print("  ✎ %s" % k)
print("  已同步 %d 个文件" % len(copied))
print()

print("=" * 74)
print("④ tsc 复测（同步后）")
print("=" * 74)
n1, tail1 = run_tsc()
print("  错误数: %s（基线 %s）" % (n1, n0))
print("  %s" % tail1.replace("\n", "\n  "))
print()


def gt(*a):
    r = subprocess.run(["git", "-c", "user.name=" + (NAME or "1949King"),
                        "-c", "user.email=" + (MAIL or "x@y.z")] + list(a),
                       cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


NAME = subprocess.run(["git", "config", "user.name"], cwd=ROOT,
                      capture_output=True).stdout.decode().strip()
MAIL = subprocess.run(["git", "config", "user.email"], cwd=ROOT,
                      capture_output=True).stdout.decode().strip()

if n1 > n0:
    print("=" * 74)
    print("⑤ ❌ tsc 变差（%s → %s），回滚" % (n0, n1))
    print("=" * 74)
    for k in copied:
        gt("checkout", "--", "src/libtv/" + k)
    n2, _ = run_tsc()
    print("  已回滚 %d 个文件；复测错误数 %s（应回到 %s）" % (len(copied), n2, n0))
    sys.exit(1)

print("=" * 74)
print("⑤ ✅ tsc 未变差，提交")
print("=" * 74)
gt("add", "-A", "--", "src/libtv")
msg = ("chore(sync): 以主库 shiguang-canvas 为真源，收敛画布副本漂移\n\n"
       "主库真源：vendor/shiguang-canvas/src\n"
       "副库副本：src/libtv\n\n"
       "本次同步 %d 个分叉文件。验收：tsc 错误数 %s → %s（未增加）。\n\n"
       "WARNING: 本仓库 origin 为第三方仓库，请勿 push。" % (len(copied), n0, n1))
mf = os.path.join(T, ".git", "_MSG.txt")
io.open(mf, "w", encoding="utf-8").write(msg)
rc, out, err = gt("commit", "-F", mf)
os.remove(mf)
print("  commit exit=%d" % rc)
print("  %s" % (out.splitlines()[0] if out else err[:200]))
print()
print("  提交历史:")
for l in gt("log", "--oneline", "-3")[1].splitlines():
    print("     %s" % l)
