# -*- coding: utf-8 -*-
"""ComfyUI 处置前的现状复核（只读，不删任何东西）"""
import os
import json
import shutil

RESULT = {}


def du(path):
    total = 0
    n = 0
    for root, dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
                n += 1
            except OSError:
                pass
    return total, n


def gb(b):
    return round(b / 1024 ** 3, 2)


def has_any(path, names):
    hit = []
    for n in names:
        p = os.path.join(path, n)
        if os.path.exists(p):
            hit.append(n)
    return hit


# 1) 找桌面上所有 ComfyUI 相关条目
desk = r"C:\Users\Administrator\Desktop"
RESULT["desktop"] = []
try:
    for e in sorted(os.listdir(desk)):
        low = e.lower()
        if any(k in low for k in ("comfy", "aki", "绘世", "秋叶", "python")) or "comfy" in low:
            p = os.path.join(desk, e)
            if os.path.isfile(p):
                RESULT["desktop"].append([e, "file", gb(os.path.getsize(p))])
            else:
                RESULT["desktop"].append([e, "dir", "?"])
except Exception as ex:
    RESULT["desktop_err"] = str(ex)

# 2) 全局候选根目录探测
candidates = [
    os.path.join(desk, "ComfyUI-aki-v1.7"),
    os.path.join(desk, "ComfyUI-aki-v1.7-1"),
    r"D:\ComfyUI-aki-v1.7",
    r"D:\_comfy_compare",
    r"D:\_comfy_compare\ComfyUI",
]
RESULT["candidates"] = {}
for c in candidates:
    entry = {"exists": os.path.exists(c)}
    if entry["exists"] and os.path.isdir(c):
        b, n = du(c)
        entry["size_gb"] = gb(b)
        entry["files"] = n
        entry["top"] = sorted(os.listdir(c))[:40]
        entry["interpreter"] = has_any(
            c, ["python_embeded", "python", "venv", ".venv", "py311", "py312"]
        )
        for sub in ("ComfyUI",):
            sp = os.path.join(c, sub)
            if os.path.isdir(sp):
                entry["ComfyUI_sub"] = sorted(os.listdir(sp))[:40]
                entry["ComfyUI_interpreter"] = has_any(
                    sp, ["python_embeded", "python", "venv", ".venv"]
                )
                for f in ("comfyui_version.py", "pyproject.toml", "requirements.txt",
                          "extra_model_paths.yaml", "extra_model_paths.yaml.example"):
                    fp = os.path.join(sp, f)
                    if os.path.isfile(fp):
                        entry.setdefault("ComfyUI_files", []).append(f)
                        if f == "comfyui_version.py":
                            try:
                                entry["version_raw"] = open(
                                    fp, encoding="utf-8", errors="replace").read()[:200]
                            except Exception as ex:
                                entry["version_err"] = str(ex)
                mp = os.path.join(sp, "models")
                if os.path.isdir(mp):
                    mb, mn = du(mp)
                    entry["models_gb"] = gb(mb)
                    entry["models_files"] = mn
                    entry["models_dirs"] = sorted(os.listdir(mp))
                cn = os.path.join(sp, "custom_nodes")
                if os.path.isdir(cn):
                    cb, cnn = du(cn)
                    entry["custom_nodes_gb"] = gb(cb)
                    entry["custom_nodes_files"] = cnn
                    entry["custom_nodes"] = sorted(os.listdir(cn))[:30]
                for d in ("output", "input", "temp"):
                    dp = os.path.join(sp, d)
                    if os.path.isdir(dp):
                        items = os.listdir(dp)
                        entry.setdefault("io_dirs", {})[d] = items[:15]
                        entry.setdefault("io_counts", {})[d] = len(items)
        entry["extra_model_paths_at_root"] = os.path.isfile(
            os.path.join(c, "extra_model_paths.yaml"))
    RESULT["candidates"][c] = entry

# 3) 磁盘余量
RESULT["disk"] = {}
for drive in ("C:\\", "D:\\"):
    try:
        u = shutil.disk_usage(drive)
        RESULT["disk"][drive] = {"free_gb": gb(u.free), "total_gb": gb(u.total)}
    except Exception as ex:
        RESULT["disk"][drive] = str(ex)

with open(r"D:\拾光剪影\app\temp\_comfy_recheck.json", "w", encoding="utf-8") as fh:
    json.dump(RESULT, fh, ensure_ascii=False, indent=2)

print("OK")
