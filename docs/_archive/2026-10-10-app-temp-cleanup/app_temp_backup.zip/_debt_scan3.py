# -*- coding: utf-8 -*-
"""澄清：前端测试文件分布在哪个库；生产代码 print 的真实分布。"""
import os
import io
import re
import collections

ROOT = r"D:\拾光剪影"
SKIP = {"node_modules", "dist", "__pycache__", ".git", ".venv312", "build"}


def under(base):
    out = []
    if not os.path.isdir(base):
        return out
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if f.endswith((".test.ts", ".test.tsx")):
                out.append(os.path.relpath(os.path.join(dp, f), ROOT).replace("\\", "/"))
    return out


a = under(os.path.join(ROOT, "vendor", "shiguang-canvas"))
b = under(os.path.join(ROOT, "vendor", "AI-Canvas-tauri"))
print("前端测试文件分布：")
print("  shiguang-canvas   : %d 个   <-- 画布真源" % len(a))
for p in a:
    print("      ", p.replace("vendor/shiguang-canvas/", ""))
print("  AI-Canvas-tauri   : %d 个   <-- 副库/参考仓" % len(b))
print("  合计              : %d 个" % (len(a) + len(b)))
print()

print("=== 生产代码 print( 精确定位（排除 tests / temp / scripts / installer） ===")
prod = collections.Counter()
files = []
for dp, dns, fns in os.walk(os.path.join(ROOT, "app")):
    dns[:] = [d for d in dns if d not in SKIP and d not in ("temp", "logs", "tests")]
    for f in fns:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        rel = os.path.relpath(p, ROOT).replace("\\", "/")
        try:
            body = io.open(p, encoding="utf-8-sig", errors="replace").read()
        except Exception:
            continue
        n = len(re.findall(r"^\s*print\(", body, re.M))
        if n:
            files.append((n, rel))
            prod[rel.split("/")[1] if rel.count("/") > 1 else rel] += n
files.sort(reverse=True)
print("  生产侧（app/ 排除 tests+temp）print 合计: %d 处 / %d 文件"
      % (sum(n for n, _ in files), len(files)))
print("  按二级目录:")
for k, v in prod.most_common(10):
    print("     %-28s %d" % (k, v))
print("  单文件 TOP 12:")
for n, p in files[:12]:
    print("     %4d  %s" % (n, p))
print()

print("=== >2000 行文件（项目守卫阈值）===")
big = []
for base in ("app", "vendor/shiguang-canvas/src", "scripts", "_verify", "tests"):
    root = os.path.join(ROOT, *base.split("/"))
    if not os.path.isdir(root):
        continue
    for dp, dns, fns in os.walk(root):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if not f.endswith((".py", ".ts", ".tsx")):
                continue
            p = os.path.join(dp, f)
            try:
                n = sum(1 for _ in io.open(p, encoding="utf-8-sig", errors="replace"))
            except Exception:
                continue
            if n > 2000:
                big.append((n, os.path.relpath(p, ROOT).replace("\\", "/")))
big.sort(reverse=True)
print("  共 %d 个" % len(big))
for n, p in big:
    print("     %6d  %s" % (n, p))
