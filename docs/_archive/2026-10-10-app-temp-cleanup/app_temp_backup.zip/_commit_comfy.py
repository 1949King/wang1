# -*- coding: utf-8 -*-
"""提交 ComfyUI 引擎检测修复 + 写记忆。"""
import io
import os
import subprocess
import sys
import tempfile

ROOT = r"D:\拾光剪影"
MEM = os.path.join(ROOT, ".workbuddy", "memory", "2026-09-26.md")
TD = tempfile.gettempdir()


def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace"),
            r.stderr.decode("utf-8", "replace"))


MSG = """fix(comfy): 修画布「引擎未安装」误报 —— 检测候选与解释器布局两处

## 现象
画布顶栏显示「引擎未安装」，但本机装了两份完整 ComfyUI。

## 根因（两层，第二层是隐性坑）
① 检测层：_find_engine_dir() 只查 4 个固定位置
   （SHIGUANG_COMFY_HOME → 项目/thirdparty/ComfyUI → 项目/comfyui → app/core/ai/comfyui），
   未覆盖实际安装位置 ⇒ 误报。
② 拉起层：_find_engine_python() 只认 <引擎>/python_embeded 与 <引擎>/venv；
   而**秋叶整合包的解释器在引擎上一级**（ComfyUI-aki-v1.7/python/python.exe）
   ⇒ 命中不了 ⇒ 静默回退拾光剪影 venv（无 ComfyUI 依赖）⇒ 目录指对了也拉不起来。

## 修复
+ _common_install_candidates()：补「桌面下 ComfyUI*/ComfyUI」与「项目同级目录」
  （只做一次 listdir，不递归全盘）
+ _own_python_candidates() / _has_own_python()：统一「引擎自带解释器」判定口径，
  覆盖 官方 python_embeded / 源码版 venv / 整合包 ../python 三类布局
~ _find_engine_dir()：候选中优先返回自带解释器的那一个；选中项记 INFO 日志
~ _find_engine_python()：复用 _own_python_candidates()，与上半边口径一致

## 实测（本机）
修复前：engine_dir=None · has_engine=false ⇒ 显示「引擎未安装」
修复后：engine_dir=...\\ComfyUI-aki-v1.7\\ComfyUI
        engine_python=...\\ComfyUI-aki-v1.7\\python\\python.exe（存在）
        has_engine=true ⇒ 提示变为「目录已就绪，导入时自动拉起」
自动选中秋叶整合包（唯一自带解释器者）；D:\\_comfy_compare\\ComfyUI 正确排后。

## 兜底
若装在别处：设 SHIGUANG_COMFY_HOME 指向引擎目录即可，优先级最高，无需改代码。

WARNING: 仅本地提交，未 push。
"""

print("=" * 74)
print("① 编译 + 冻结区")
print("=" * 74)
p = os.path.join(ROOT, "app", "core", "ai", "comfy_provider.py")
b = io.open(p, encoding="utf-8-sig").read()
try:
    compile(b, p, "exec")
    print("  ✅ comfy_provider.py 编译通过（%d 行）" % len(b.splitlines()))
except SyntaxError as e:
    print("  ❌ %s" % e)
    sys.exit(1)
r = subprocess.run([sys.executable, os.path.join(ROOT, "scripts", "frozen_zone_guard.py")],
                   cwd=ROOT, capture_output=True)
print("  冻结区: %s" % (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()[-58:])
print()

print("=" * 74)
print("② 提交")
print("=" * 74)
PATHS = ["app/core/ai/comfy_provider.py", "docs/现行技术文档.md"]
ps = os.path.join(TD, "_ps7.txt")
io.open(ps, "w", encoding="utf-8").write("\n".join(PATHS) + "\n")
git("add", "-A", "--pathspec-from-file=" + ps)
rc, out, _ = git("-c", "core.quotePath=false", "diff", "--cached", "--name-only")
print("  暂存: %s" % [l for l in out.splitlines() if l.strip()])
mf = os.path.join(TD, "_msg7.txt")
io.open(mf, "w", encoding="utf-8").write(MSG)
rc, out, err = git("commit", "-F", mf)
print("  commit exit=%d  %s" % (rc, out.splitlines()[0] if out else err[:200]))
print()

NOTE = """
## 画布「引擎未安装」误报修复（00:13 - 00:35）· 主仓补提交

用户问：「画布模块显示引擎没有安装是怎么回事」

### 结论：不是没装，是「装了但检测不到」—— 误报（两层问题）

提示出处：画布顶栏常驻指示点 `CanvasShell.tsx:819` → `missing: "引擎未安装"`
（是 **ComfyUI 引擎**状态，不是画布本身）。

**本机实际装了两份完整 ComfyUI**：
- `C:\\Users\\Administrator\\Desktop\\ComfyUI-aki-v1.7\\ComfyUI`（**秋叶整合包**，main.py+nodes.py+models(23)+custom_nodes(23)）
- `D:\\_comfy_compare\\ComfyUI`（源码版，main.py+nodes.py+models(26)+custom_nodes(2)）

**① 检测层**：`_find_engine_dir()` 只查 4 个固定位置（env → 项目/thirdparty/ComfyUI →
项目/comfyui → app/core/ai/comfyui），全未命中 ⇒ 误报

**② 拉起层（隐性坑）**：`_find_engine_python()` 只认 `<引擎>/python_embeded` 与 `<引擎>/venv`，
而**秋叶包的解释器在引擎的上一级**（`ComfyUI-aki-v1.7/python/python.exe`，已核实存在 python311.dll 等）
⇒ 命中不了 ⇒ 静默回退拾光剪影 venv（**无 ComfyUI 依赖**）⇒ **目录指对了也拉不起来**

### 修复（`app/core/ai/comfy_provider.py`，非冻结区）
- `_common_install_candidates()`：补「桌面下 `ComfyUI*/ComfyUI`」+「项目同级目录」（只一次 listdir，不全盘递归）
- `_own_python_candidates()` / `_has_own_python()`：统一「自带解释器」判定，
  覆盖 官方 `python_embeded` / 源码版 `venv` / **整合包 `../python`** 三类布局
- `_find_engine_dir()`：候选中**优先返回自带解释器者**（只有它能拉起来）；选中项记 INFO
- `_find_engine_python()`：复用同一候选函数，两侧口径一致

### 实测
```
修复前  engine_dir=None                     has_engine=false  ⇒「引擎未安装」
修复后  engine_dir=...\\ComfyUI-aki-v1.7\\ComfyUI
        engine_python=...\\ComfyUI-aki-v1.7\\python\\python.exe（存在，is_aki_layout=true）
        has_engine=true                    ⇒「目录已就绪，导入工作流时会自动拉起」
```
自动选中秋叶整合包（本机唯一自带解释器者）；`D:\\_comfy_compare\\ComfyUI` 正确排其后。

### 兜底（零改动路径，也告诉了用户）
装在别处就设 `SHIGUANG_COMFY_HOME` 指向引擎目录 —— 该路径优先级最高。

### 方法学收获
这是本轮第三次「先猜错、实测才对」：此前两次是冷启动归因（错猜 transformers、错猜模块导入）。
**规律：凡是"某个东西慢/坏了"的判断，必须实测到具体函数与具体行，不能靠分类学猜测。**
"""
if not os.path.exists(MEM):
    io.open(MEM, "w", encoding="utf-8").write("# 2026-09-26 工作记录\n")
existing = io.open(MEM, encoding="utf-8").read()
if "引擎未安装" in existing:
    print("③ 记忆已存在，跳过")
else:
    io.open(MEM, "w", encoding="utf-8").write(existing.rstrip("\n") + "\n" + NOTE)
    print("③ 记忆已写入 -> %d bytes" % os.path.getsize(MEM))
