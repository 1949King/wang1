# -*- coding: utf-8 -*-
"""按子目录拆解 秋叶包 体积 + 确认 rar 大小"""
import os
import json

ROOT = r"C:\Users\Administrator\Desktop\ComfyUI-aki-v1.7"
OUT = r"D:\拾光剪影\app\temp\_comfy_sizes.json"


def du(path):
    total = 0
    n = 0
    for root, dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
                n += 1
            except OSError:
                pass
    return total, n


def gb(b):
    return round(b / 1024 ** 3, 2)


res = {}
for e in sorted(os.listdir(ROOT)):
    p = os.path.join(ROOT, e)
    try:
        if os.path.isfile(p):
            res[e] = {"type": "file", "gb": gb(os.path.getsize(p))}
        else:
            b, n = du(p)
            res[e] = {"type": "dir", "gb": gb(b), "files": n}
    except Exception as ex:
        res[e] = {"err": str(ex)}

# 秋叶包 ComfyUI 的 git 状态：能否原地 git pull 升级
gitdir = os.path.join(ROOT, "ComfyUI", ".git")
res["__has_comfyui_git"] = os.path.isdir(gitdir)

with open(OUT, "w", encoding="utf-8") as fh:
    json.dump(res, fh, ensure_ascii=False, indent=2)

print("OK")
