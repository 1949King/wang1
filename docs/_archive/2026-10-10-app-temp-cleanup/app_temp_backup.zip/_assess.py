# -*- coding: utf-8 -*-
import os, subprocess
ROOT = r"D:\拾光剪影"

def git(*a):
    r = subprocess.run(["git"] + list(a), cwd=ROOT, capture_output=True)
    return r.stdout.decode("utf-8", "replace").strip()

print("=== 当前提交 ===")
print(git("log", "--oneline", "-8"))
print()
print("=== 每个提交动了什么（按顶层统计）===")
log = git("log", "--format=%h|%s", "d67f80a..HEAD")
for line in log.splitlines():
    if not line.strip():
        continue
    h, subj = line.split("|", 1)
    rc = subprocess.run(["git", "show", "--stat", "--format=", "-z", h],
                        cwd=ROOT, capture_output=True).stdout.decode("utf-8", "replace")
    paths = [p.split("\x00")[0] if "\x00" in p else p for p in rc.split("\x00") if p.strip()]
    # stat 输出每行形如 " 路径 | 改动数 +++"
    import collections
    c = collections.Counter()
    for p in paths:
        q = p.strip()
        if "|" in q:
            q = q.split("|")[0].strip()
        q = q.replace("\\", "/")
        top = q.split("/")[0] if "/" in q else "(root)"
        c[top] += 1
    print("  %s  %s" % (h, subj[:50]))
    print("      合计 %d 项，顶层分布: %s" % (sum(c.values()), dict(c.most_common(6))))
print()
print("=== openshot 删除究竟落在哪个提交 ===")
print(git("log", "--oneline", "-Snonexistent", "--", "openshot-qt") or "")
for h in [l.split("|")[0] for l in log.splitlines() if l.strip()]:
    out = subprocess.run(["git", "show", "--stat", "--format=", h, "--", "openshot-qt"],
                         cwd=ROOT, capture_output=True).stdout.decode("utf-8", "replace").strip()
    if out:
        print("  %s 含 openshot-qt 变更 (%d 行 stat)" % (h, len(out.splitlines())))
