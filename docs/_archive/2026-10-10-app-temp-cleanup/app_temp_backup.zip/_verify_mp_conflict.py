# -*- coding: utf-8 -*-
"""核实：PyQt6 先导入 ⇒ mediapipe DLL 初始化失败。若成立，应用内姿态功能是哑的。"""
import io
import os
import re
import subprocess

VENV = r"D:\拾光剪影\.venv312\Scripts\python.exe"
ROOT = r"D:\拾光剪影"

print("=" * 74)
print("① 精确二分：PyQt6 的哪个部分触发冲突")
print("=" * 74)
CASES = [
    ("裸 mediapipe", "import mediapipe; print('OK')"),
    ("PyQt6（仅包） + mediapipe", "import PyQt6; import mediapipe; print('OK')"),
    ("PyQt6.QtCore + mediapipe", "from PyQt6.QtCore import QObject; import mediapipe; print('OK')"),
    ("PyQt6.QtGui + mediapipe", "from PyQt6.QtGui import QImage; import mediapipe; print('OK')"),
    ("PyQt6.QtWidgets + mediapipe", "from PyQt6.QtWidgets import QApplication; import mediapipe; print('OK')"),
    ("mediapipe 先 + PyQt6 后", "import mediapipe; from PyQt6.QtWidgets import QApplication; print('OK')"),
]
for label, code in CASES:
    r = subprocess.run([VENV, "-c", code], cwd=ROOT, capture_output=True, timeout=600)
    err = r.stderr.decode("utf-8", "replace").strip()
    line = ""
    if r.returncode != 0:
        hit = [l for l in err.splitlines() if "DLL" in l or "Error" in l]
        line = (hit[-1] if hit else err.splitlines()[-1])[:95]
    print("  %-34s %s  %s" % (label, "✅" if r.returncode == 0 else "❌", line))

print()
print("=" * 74)
print("② 应用里哪些地方用 mediapipe、失败时怎么处理")
print("=" * 74)
hits = []
for dp, dns, fns in os.walk(os.path.join(ROOT, "app")):
    dns[:] = [d for d in dns if d not in ("__pycache__", "temp", "logs")]
    for f in fns:
        if not f.endswith(".py"):
            continue
        p = os.path.join(dp, f)
        rel = os.path.relpath(p, ROOT).replace("\\", "/")
        b = io.open(p, encoding="utf-8-sig", errors="replace").read()
        if "mediapipe" not in b and "mp.solutions" not in b:
            continue
        for m in re.finditer(r"^([ \t]*)(import mediapipe|from mediapipe[\w\.]*\s+import|mp\.solutions)", b, re.M):
            ln = b[:m.start()].count("\n") + 1
            lvl = "顶层" if len(m.group(1)) == 0 else "函数内"
            hits.append((rel, ln, lvl, m.group(2)[:40]))
print("  mediapipe 相关引用点: %d" % len(hits))
for rel, ln, lvl, s in hits:
    print("     %-52s L%-5d %-6s %s" % (rel, ln, lvl, s))
print()

print("=" * 74)
print("③ 姿态服务里的导入保护（看是否有诚实降级）")
print("=" * 74)
for rel in ("app/core/ai/pose_extract_service.py", "app/core/ai/pose_worker.py"):
    p = os.path.join(ROOT, *rel.split("/"))
    if not os.path.exists(p):
        continue
    L = io.open(p, encoding="utf-8-sig", errors="replace").read().splitlines()
    print("  --- %s" % rel)
    for i, l in enumerate(L, 1):
        if re.search(r"import mediapipe|MP_AVAILABLE|mediapipe\s*=\s*None|except ImportError|logger\.(warning|error|info).*mediapipe", l):
            print("     L%-5d %s" % (i, l.strip()[:100]))
    print()
