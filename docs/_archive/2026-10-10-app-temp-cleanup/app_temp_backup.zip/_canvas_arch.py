# -*- coding: utf-8 -*-
"""画布架构侦察：宿主引擎选择、渲染栈、生成引擎、构建与发布链路。"""
import io
import json
import os
import re
import subprocess

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
CAN = os.path.join(ROOT, "vendor", "shiguang-canvas")

print("=" * 74)
print("① 宿主引擎选择逻辑（canvas_runtime.py，冻结区=stage3d-core）")
print("=" * 74)
p = os.path.join(ROOT, "app", "core", "canvas_runtime.py")
L = io.open(p, encoding="utf-8-sig", errors="replace").read().splitlines()
print("  行数 %d" % len(L))
for i, l in enumerate(L, 1):
    if re.search(r"def get_canvas_engine|ENGINE|engine\s*==|engine\s*=|3010|3011|18765|vendor_canvas_dir|vendor_dist_dir|tauri|_MEIPASS|subprocess|Popen|_SPAHandler|静态", l):
        print("  L%-4d %s" % (i, l.strip()[:108]))
print()

print("=" * 74)
print("② 副库 Tauri 侧是否已构建（宿主 B 能不能用）")
print("=" * 74)
for rel in ("src-tauri/target/release", "src-tauri/tauri.conf.json",
            "src-tauri/Cargo.toml", "src-tauri/src/main.rs", "package.json"):
    fp = os.path.join(T, *rel.split("/"))
    if os.path.isdir(fp):
        n = sum(len(f) for _, _, f in os.walk(fp))
        print("  %-32s 目录（%d 文件）" % (rel, n))
    elif os.path.isfile(fp):
        print("  %-32s 文件 %.1f KB" % (rel, os.path.getsize(fp) / 1024.0))
    else:
        print("  %-32s ❌ 不存在" % rel)
exe = os.path.join(T, "src-tauri", "target", "release")
if os.path.isdir(exe):
    hits = [f for f in os.listdir(exe) if f.lower().endswith(".exe")]
    print("  → release 目录里的 exe: %s" % (hits if hits else "（无）"))
print()

print("=" * 74)
print("③ 画布渲染栈依赖（真源 package.json）")
print("=" * 74)
pkg = json.load(io.open(os.path.join(CAN, "package.json"), encoding="utf-8"))
print("  版本: %s" % pkg.get("version"))
print("  dependencies:")
for k, v in sorted(pkg.get("dependencies", {}).items()):
    print("     %-28s %s" % (k, v))
print("  devDependencies（关键）:")
for k in ("vite", "typescript", "vitest", "three", "@vitejs/plugin-react"):
    if k in pkg.get("devDependencies", {}):
        print("     %-28s %s" % (k, pkg["devDependencies"][k]))
print()

print("=" * 74)
print("④ 构建产物与构建脚本")
print("=" * 74)
dist = os.path.join(CAN, "dist")
if os.path.isdir(dist):
    n = tot = 0
    biggest = []
    for dp, dns, fns in os.walk(dist):
        for f in fns:
            fp = os.path.join(dp, f)
            try:
                s = os.path.getsize(fp)
            except OSError:
                continue
            n += 1
            tot += s
            biggest.append((s, os.path.relpath(fp, dist).replace("\\", "/")))
    print("  dist: %d 文件 / %.1f MB" % (n, tot / 1048576.0))
    biggest.sort(reverse=True)
    print("  最大 6 个产物:")
    for s, f in biggest[:6]:
        print("     %8.2f MB  %s" % (s / 1048576.0, f[:70]))
    js = [f for s, f in biggest if f.endswith(".js")]
    print("  JS chunk 数: %d" % len(js))
else:
    print("  ❌ dist 不存在（WebEngine 将加载不到画布）")
print()

print("=" * 74)
print("⑤ 生成引擎：画布能用的生成后端（本机实装）")
print("=" * 74)
print("  ComfyUI（本地引擎）：见上一轮修复，engine_valid=true")
for name, port in (("ComfyUI", 8188), ("Ollama", 11434), ("canvas bridge", 18765)):
    import socket
    s = socket.socket(); s.settimeout(0.5)
    try:
        s.connect(("127.0.0.1", port)); alive = "✅ 在跑"
    except Exception:
        alive = "❌ 未运行"
    finally:
        s.close()
    print("  %-16s %-6d %s" % (name, port, alive))
print()

print("=" * 74)
print("⑥ 画布代码规模与守卫基线")
print("=" * 74)
for base in (CAN + "/src", T + "/src/libtv"):
    if not os.path.isdir(base):
        continue
    files = []
    for dp, dns, fns in os.walk(base):
        dns[:] = [d for d in dns if d not in ("node_modules", "dist", "__pycache__")]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css")):
                fp = os.path.join(dp, f)
                files.append((sum(1 for _ in io.open(fp, encoding="utf-8", errors="replace")), f))
    files.sort(reverse=True)
    tot = sum(n for n, _ in files)
    over = [x for x in files if x[0] > 2000]
    print("  %-42s %3d 文件 / %6d 行 · >2000行 %d 个" % (
        os.path.relpath(base, ROOT).replace("\\", "/"), len(files), tot, len(over)))
