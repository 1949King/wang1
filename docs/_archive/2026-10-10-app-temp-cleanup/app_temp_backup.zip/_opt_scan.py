# -*- coding: utf-8 -*-
"""新机会扫描：找技术债报告里**没有登记过**的优化点。"""
import collections
import io
import os
import re
import subprocess
import sys
import time

ROOT = r"D:\拾光剪影"
SKIP = {".git", ".venv312", "node_modules", "__pycache__", "dist", "build",
        ".wheelhouse", ".vite", ".pytest_cache", "openshot-qt", "libopenshot",
        "_archive", "temp", "logs"}


def pyfiles(base="app"):
    out = []
    for dp, dns, fns in os.walk(os.path.join(ROOT, base)):
        dns[:] = [d for d in dns if d not in SKIP]
        for f in fns:
            if f.endswith(".py"):
                out.append(os.path.join(dp, f))
    return out


def read(p):
    try:
        return io.open(p, encoding="utf-8-sig", errors="replace").read()
    except Exception:
        return ""


print("=" * 74)
print("Ⓐ 运行时产物堆积（报告未登记）")
print("=" * 74)
for d in ("app/logs", "logs", "error_reports", "autosave", "data", "app/data",
          "cache", "app/cache", "新建文件夹", "temp_ai_editor", "build", "dist"):
    p = os.path.join(ROOT, *d.split("/"))
    if not os.path.isdir(p):
        continue
    n = 0
    tot = 0
    for dp, dns, fns in os.walk(p):
        for f in fns:
            try:
                tot += os.path.getsize(os.path.join(dp, f))
                n += 1
            except OSError:
                pass
    if n:
        print("  %-18s %5d 文件 / %8.1f MB" % (d, n, tot / 1048576.0))
print()

print("=" * 74)
print("Ⓑ 测试空白：高风险模块有无对应测试")
print("=" * 74)
RISK = ["app/modules/lego/editor_module.py", "app/core/canvas_server.py",
        "app/core/capability_handlers.py", "app/core/ai/video_generation_client.py",
        "app/core/ai_video_generation_pipeline.py", "app/core/canvas_aigc.py",
        "app/core/project_agent_host.py", "app/modules/lego/drama_understanding_engine.py",
        "app/core/preview_manager.py", "app/core/editor_scheduler.py",
        "app/modules/lego/character_management_module.py", "app/core/glue/policies.py"]
test_names = set()
for base in ("app/tests", "tests", "_verify"):
    for dp, dns, fns in os.walk(os.path.join(ROOT, *base.split("/"))):
        for f in fns:
            if f.endswith(".py"):
                test_names.add(f)
for rel in RISK:
    stem = os.path.basename(rel)[:-3]
    hits = [t for t in test_names if stem in t]
    n = sum(1 for _ in io.open(os.path.join(ROOT, *rel.split("/")),
                               encoding="utf-8-sig", errors="replace"))
    print("  %-46s %5d 行 · 同名测试 %d 个 %s"
          % (rel, n, len(hits), hits[:2] if hits else "❌ 无"))
print()

print("=" * 74)
print("Ⓒ 重复实现：同类小工具散落多少份")
print("=" * 74)
UTIL_PATTERNS = {
    "_to_float / 数值转换": r"def _?(to_float|safe_float|as_float|_f|_num)\b",
    "find_ffmpeg / ffmpeg 定位": r"def .*find.*ffmpeg\b|ffmpeg\.exe",
    "is_available / 可用性探测": r"def is_\w+_available\b",
    "get_logger / logger 获取": r"logging\.getLogger\(",
    "retry / 重试循环": r"def .*retry|for _?attempt in range",
    "atomic_write / 原子写": r"os\.replace\(|\.tmp['\"]",
    "md5/sha1 哈希": r"hashlib\.(md5|sha1)\(",
}
files = pyfiles()
for label, pat in UTIL_PATTERNS.items():
    rx = re.compile(pat)
    hit = [(os.path.relpath(p, ROOT).replace("\\", "/"), len(rx.findall(read(p))))
           for p in files]
    hit = [(f, n) for f, n in hit if n]
    tot = sum(n for _, n in hit)
    print("  %-26s %4d 处 / %3d 文件" % (label, tot, len(hit)))
print()

print("=" * 74)
print("Ⓓ 硬编码环境耦合（报告未登记）")
print("=" * 74)
PATS = {
    "Windows 绝对路径 (C:\\ / D:\\)": r"[CD]:\\\\?(?:Users|拾光|ffmpeg|Python)",
    "localhost/127.0.0.1 硬编码": r"127\.0\.0\.1|localhost",
    "端口数字字面量": r"\b(18765|3010|3011|17371|11434)\b",
    "硬编码 provider 名": r"['\"](dashscope|seedance|cogvideo|deepseek|openai)['\"]",
    "sleep 阻塞": r"time\.sleep\(\s*[0-9.]+",
}
for label, pat in PATS.items():
    rx = re.compile(pat)
    hit = [(os.path.relpath(p, ROOT).replace("\\", "/"), len(rx.findall(read(p))))
           for p in files]
    hit = [(f, n) for f, n in hit if n]
    hit.sort(key=lambda x: -x[1])
    print("  %-28s %4d 处 / %3d 文件   TOP: %s"
          % (label, sum(n for _, n in hit), len(hit),
             ", ".join("%s(%d)" % (os.path.basename(f), n) for f, n in hit[:3])))
print()

print("=" * 74)
print("Ⓔ 前端 dist 是否落后于源码（画布走 dist 静态服务）")
print("=" * 74)
CAN = os.path.join(ROOT, "vendor", "shiguang-canvas")
dist = os.path.join(CAN, "dist")
src = os.path.join(CAN, "src")
if os.path.isdir(dist):
    newest_src = 0
    newest_src_f = ""
    for dp, dns, fns in os.walk(src):
        dns[:] = [d for d in dns if d not in ("node_modules",)]
        for f in fns:
            if f.endswith((".ts", ".tsx", ".css")):
                m = os.path.getmtime(os.path.join(dp, f))
                if m > newest_src:
                    newest_src, newest_src_f = m, f
    newest_dist = 0
    for dp, dns, fns in os.walk(dist):
        for f in fns:
            m = os.path.getmtime(os.path.join(dp, f))
            newest_dist = max(newest_dist, m)
    print("  最新源码改动: %s  (%s)" % (time.strftime("%Y-%m-%d %H:%M", time.localtime(newest_src)), newest_src_f))
    print("  最新 dist 产物: %s" % time.strftime("%Y-%m-%d %H:%M", time.localtime(newest_dist)))
    behind = newest_src > newest_dist
    print("  ⇒ dist %s源码" % ("❌ 落后于" if behind else "✅ 不早于"))
    if behind and newest_src - newest_dist > 3600:
        print("     落后 %.1f 小时 ⇒ 画布改动未构建进 dist，WebEngine 加载的仍是旧版"
              % ((newest_src - newest_dist) / 3600))
print()

print("=" * 74)
print("Ⓕ 集中度：改动风险最高的文件（体量 × 依赖被引用数）")
print("=" * 74)
big = []
for p in files:
    n = sum(1 for _ in io.open(p, encoding="utf-8-sig", errors="replace"))
    if n > 1500:
        big.append((n, os.path.relpath(p, ROOT).replace("\\", "/")))
big.sort(reverse=True)
for n, rel in big[:12]:
    stem = os.path.basename(rel)[:-3]
    refs = 0
    for p in files:
        if os.path.relpath(p, ROOT).replace("\\", "/") == rel:
            continue
        b = read(p)
        refs += len(re.findall(r"\b" + re.escape(stem) + r"\b", b))
    print("  %6d 行 · 被引用 %3d 次  %s" % (n, refs, rel))
