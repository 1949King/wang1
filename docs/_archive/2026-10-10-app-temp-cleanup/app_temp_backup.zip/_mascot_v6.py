# -*- coding: utf-8 -*-
"""形象包 v6：新增「传统涂装①中式旗袍」（用户要求：先来一个传统一点的）。

用户判断：「这衣服风格也不符合知心的秘书大姐姐的形象」——
  我认。风衣/机能夹克那套是「都市职业装」，它服务的是「干练」而不是「知心」。
  **知心 = 含蓄温婉**，而这恰是中式传统服饰最擅长的语言。

关键：**旗袍天生是 X 型收腰轮廓** ⇒ 一步同时解决
  ①「偏男性」（H型直筒→X型收腰）
  ②「不知心」（职业装→含蓄中式）
"""
import io
import json
import os
import shutil
import subprocess
import sys

ROOT = r"D:\拾光剪影"
C = os.path.join(ROOT, "vendor", "shiguang-canvas")
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
PACK = "shiguang-mascot.json"
PACK_PATH = os.path.join(C, "public", "prompts", PACK)

TRADITIONAL = {
    "id": "mascot-009",
    "title": "拾岚·传统涂装①中式旗袍（知心版）",
    "category": "portrait",
    "tags": ["传统涂装", "替换外观", "skin", "旗袍", "中式", "知心", "含蓄",
             "X型收腰", "成人比例", "竖版"],
    "prompt": (
        "二次元兽耳娘角色全身立绘，成年女性，温婉含蓄而知心的传统中式大姐姐气质，"
        "完全着装、非性化。"
        "【比例·必须严格遵守】7.5头身；头宽:肩宽≈1:2.2；腰线偏高，腿长占身高约55%；躯干修长。"
        "禁止Q版、禁止短身、禁止大头。"
        "【身体轮廓·关键】**旗袍天然收腰的X型轮廓：腰围清晰可见**（立领+贴身收腰剪裁）；"
        "**肩线柔和不挺括**；**颈部修长、因立领而显得端庄，但不遮住下颌线**。"
        "禁止直筒无腰的H型廓形。"
        "【面部·成年人脸型】鹅蛋/卵形脸，脸长:脸宽≈1.4:1；下颌线清晰、下巴略尖；"
        "眼睛细长、眼尾微上扬，眼裂宽度约占脸宽1/3（不要大圆眼），双眼皮明确，瞳色青蓝；"
        "神态温婉、眼神含蓄温润。"
        "【角色】一对狐狸兽耳（耳内侧浅色绒毛，耳姿自然放松、一只微垂，不竖立警觉），"
        "**耳朵从发髻两侧自然伸出**；一条蓬松狐尾自然盘落在身侧后方，尾尖由深蓝渐变为浅白蓝。"
        "深蓝黑长发梳成**中式低发髻**（插一支素银发篦，几缕碎发自然垂落鬓边），"
        "刘海一撮品牌蓝(#3b82f6)挑染。戴一副细金丝圆框眼镜，镜片有极淡的品牌蓝反光。"
        "【衣装·传统中式改良长身旗袍】深蓝(#1c2638)**锦缎改良及踝长身旗袍**；"
        "**立领包裹颈部但露出下颌线**；斜襟从领口至右腋排下一列"
        "**手工盘扣（品牌蓝丝线缠制）**；**贴身收腰剪裁，腰线明确**；"
        "**侧开衩至膝（不开高）**；绸缎光泽 + **织锦暗纹：品牌蓝(#3b82f6)与青绿(#2dd4bf)的"
        "云纹/水波纹/回纹**；九分窄袖，袖口绣银线。"
        "外搭一条**半透明深蓝纱质长披帛**从肩后垂下、自然垂落，边缘细绣。"
        "深蓝缎面绣鞋（低跟）。配饰：银质长耳坠（小颗品牌蓝晶石）、细金丝圆框眼镜、"
        "胸前一枚小胶片/剪影形状银质胸针。端庄不暴露、不开高衩。"
        "【动作】优雅端立、身体微侧，**双手在身前轻叠**，其中一手托起一颗悬浮的小小暖光点；"
        "肩线放松、颈部线条舒展，温婉平视观者；不插口袋、不叉腰、不扭转、不卖萌。"
        "【背景·传统中式室内】身后一扇**中式格栅木窗（冰裂纹格心）**，"
        "窗外是极简夜色城市轮廓剪影与一轮满月；"
        "身后墙面横贯一条柔和发光的时间线光带，带上散布几个极小的光点；"
        "前景**木案**边缘，案上一杯冒热气的茶、一盏**宫灯形暖橙小灯**、一卷半展的绢帛。"
        "光照：左侧屏幕蓝光为主光，右侧宫灯暖橙为辅助光，"
        "在肩头、狐耳与狐尾边缘形成柔和的剪影边缘光。"
        "【风格】精致二次元插画，赛璐珞平涂叠加柔和渐变，描边干净，柔和体积光与光尘粒子，"
        "构图居中、全身入画并留出上下留白。竖版3:4。"
    ),
}

data = json.load(io.open(PACK_PATH, encoding="utf-8"))
by_id = {e["id"]: e for e in data}
if TRADITIONAL["id"] in by_id:
    print("⏭ mascot-009 已存在，更新其 prompt")
    by_id[TRADITIONAL["id"]]["prompt"] = TRADITIONAL["prompt"]
else:
    data.append(TRADITIONAL)
    print("✅ 已追加 mascot-009（传统涂装①中式旗袍）")

content = json.dumps(data, ensure_ascii=False, indent=2) + "\n"

print("=" * 74)
print("① 写入 4 处")
print("=" * 74)
for p in [os.path.join(C, "public", "prompts", PACK), os.path.join(C, "dist", "prompts", PACK),
          os.path.join(T, "public", "prompts", PACK), os.path.join(T, "dist", "prompts", PACK)]:
    if os.path.isdir(os.path.dirname(p)):
        io.open(p, "w", encoding="utf-8").write(content)
print("  ✅ 4 处已写入（%d 条 / %d 字节）" % (len(data), len(content)))
print()

print("=" * 74)
print("② 收图")
print("=" * 74)
SRC = os.path.join(ROOT, "generated-images",
                   "二次元兽耳娘角色全身立绘_成年女性_温婉含蓄而知心的传统中式_2026-09-25T11-45-18.png")
DST = os.path.join(ROOT, "assets", "mascot", "shilan-传统01-中式旗袍-知心版.png")
if os.path.exists(SRC):
    shutil.copy2(SRC, DST)
    print("  ✅ %s (%.1f KB)" % (os.path.basename(DST), os.path.getsize(DST) / 1024.0))
else:
    print("  ❌ 源图不存在")
print()

print("=" * 74)
print("③ 核验")
print("=" * 74)
a = io.open(os.path.join(C, "src", "promptLibrary.ts"), "rb").read()
b = io.open(os.path.join(T, "src", "libtv", "promptLibrary.ts"), "rb").read()
print("  两侧 promptLibrary.ts 字节一致: %s" % ("✅" if a == b else "❌"))
print("  JSON 合法: ✅ 条目 %d" % len(json.loads(content)))
r = subprocess.run([sys.executable, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
print("  双库校验 exit=%d  %s" % (r.returncode,
      r.stdout.decode("utf-8", "replace").strip().splitlines()[0]))
