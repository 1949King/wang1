# -*- coding: utf-8 -*-
"""列出 app/ 下的子目录及各自的 gitignore 状态，判断哪些该从门禁扫描中排除。"""
import os
import subprocess

ROOT = r"D:\拾光剪影"
APPDIR = os.path.join(ROOT, "app")

subs = []
for e in sorted(os.listdir(APPDIR)):
    p = os.path.join(APPDIR, e)
    if not os.path.isdir(p):
        continue
    rel = "app/" + e
    r = subprocess.run(["git", "check-ignore", "-q", rel + "/x"], cwd=ROOT,
                       capture_output=True)
    n_py = 0
    for dp, dns, fns in os.walk(p):
        dns[:] = [d for d in dns if d != "__pycache__"]
        n_py += sum(1 for f in fns if f.endswith(".py"))
    subs.append((rel, r.returncode == 0, n_py))

print("%-34s %-10s %s" % ("app 子目录", "被gitignore", ".py 数"))
print("-" * 60)
for rel, ign, n in subs:
    flag = "是 ⚠️" if ign else "否"
    print("%-34s %-10s %d" % (rel, flag, n))
print()
print("被 gitignore 且有 .py 的子目录（应从门禁扫描排除）:")
for rel, ign, n in subs:
    if ign and n:
        print("   %-30s %d 个 .py" % (rel, n))
