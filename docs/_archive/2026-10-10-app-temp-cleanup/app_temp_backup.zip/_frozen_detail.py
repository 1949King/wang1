# -*- coding: utf-8 -*-
"""查看冻结区条目的锁定粒度（整文件 vs 符号）"""
import io
import json

P = r"D:/拾光剪影/docs/knowledge/frozen_zones.json"
d = json.loads(io.open(P, encoding="utf-8").read())
zones = d.get("zones") or d

want = {"stage3d-core", "canvas-magnetic-intent"}
keys = ["character_management_module.py", "canvas_bridge.py", "store.ts",
        "nodes.tsx", "node-factory.ts", "mediaExtraNodes.tsx", "Stage3D.tsx"]

out = {}
for z in (zones if isinstance(zones, list) else zones.values()):
    zid = z.get("id") or z.get("zone")
    if zid not in want:
        continue
    out[zid] = {"keys": list(z.keys())}
    files = z.get("files") or z.get("paths") or {}
    if isinstance(files, list):
        out[zid]["files_type"] = "list"
        out[zid]["files"] = [f for f in files
                             if any(str(f).endswith(k) or k in str(f) for k in keys)]
    elif isinstance(files, dict):
        out[zid]["files_type"] = "dict"
        for fk, fv in files.items():
            if any(k in str(fk) for k in keys):
                out[zid][str(fk)] = fv
    # 其他可能的键
    for k in ("symbols", "locks", "locked_symbols", "description", "note"):
        if k in z:
            out[zid][k] = z[k] if not isinstance(z[k], (list, dict)) else f"<{type(z[k]).__name__} len={len(z[k])}>"

print(json.dumps(out, ensure_ascii=False, indent=1)[:5000])
