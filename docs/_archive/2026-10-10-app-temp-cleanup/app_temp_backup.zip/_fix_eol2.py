# -*- coding: utf-8 -*-
"""强制把副库工作区重建为索引内容（LF），并复跑「卡点拦漂移」实证。

为什么 checkout -f 无效：git status 因 stat 缓存判定「干净」⇒ 跳过重写。
解法：先删除工作区文件（变 missing），再 checkout 从索引重建。
"""
import io
import os
import subprocess
import sys

ROOT = r"D:\拾光剪影"
T = os.path.join(ROOT, "vendor", "AI-Canvas-tauri")
MAIN = os.path.join(ROOT, "vendor", "shiguang-canvas", "src")
PY = sys.executable


def gt(*a):
    name = subprocess.run(["git", "config", "user.name"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "1949King"
    mail = subprocess.run(["git", "config", "user.email"], cwd=ROOT,
                          capture_output=True).stdout.decode().strip() or "x@y.z"
    r = subprocess.run(["git", "-c", "user.name=" + name, "-c", "user.email=" + mail] + list(a),
                       cwd=T, capture_output=True)
    return (r.returncode, r.stdout.decode("utf-8", "replace").strip(),
            r.stderr.decode("utf-8", "replace").strip())


def compare_all():
    n, bad = 0, []
    for dp, dns, fns in os.walk(MAIN):
        dns[:] = [d for d in dns if d not in ("node_modules", "dist", "__pycache__")]
        for f in fns:
            if not f.endswith((".ts", ".tsx", ".css", ".json")):
                continue
            ap = os.path.join(dp, f)
            rel = os.path.relpath(ap, MAIN).replace("\\", "/")
            bp = os.path.join(T, "src", "libtv", *rel.split("/"))
            if not os.path.exists(bp):
                continue
            if io.open(ap, "rb").read() != io.open(bp, "rb").read():
                n += 1
                bad.append(rel)
    return n, bad


print("=" * 74)
print("① 找出仍在分叉的文件并强制重建")
print("=" * 74)
n0, bad0 = compare_all()
print("  分叉: %d %s" % (n0, bad0))
for rel in bad0:
    p = os.path.join(T, "src", "libtv", *rel.split("/"))
    os.remove(p)
    rc, out, err = gt("checkout", "--", "src/libtv/" + rel)
    ok = os.path.exists(p)
    same = ok and io.open(p, "rb").read() == io.open(
        os.path.join(MAIN, *rel.split("/")), "rb").read()
    print("     %-28s 重建=%s 与主库字节相同=%s" % (rel, ok, same))
print()

n1, bad1 = compare_all()
print("  复测分叉: %d（修复前 %d）" % (n1, n0))
print()

print("=" * 74)
print("② 主仓双库校验")
print("=" * 74)
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
o = (r.stdout.decode("utf-8", "replace") + r.stderr.decode("utf-8", "replace")).strip()
print("  exit=%d" % r.returncode)
for l in o.splitlines()[:6]:
    print("     %s" % l[:100])
print()

print("=" * 74)
print("③ 卡点实证：制造漂移 → 是否拦住 → 还原 → 是否恢复")
print("=" * 74)
tgt = os.path.join(T, "src", "libtv", "canvasVersion.ts")
orig = io.open(tgt, "rb").read()
io.open(tgt, "ab").write(b"// drift-probe\n")
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
caught = r.returncode != 0
print("  制造漂移后 exit=%d ⇒ %s" % (r.returncode, "✅ 拦住" if caught else "❌ 没拦住"))

os.remove(tgt)
gt("checkout", "--", "src/libtv/canvasVersion.ts")
restored = io.open(tgt, "rb").read() == orig
r = subprocess.run([PY, os.path.join(ROOT, "_verify", "check_canvas_dual_repo.py")],
                   cwd=ROOT, capture_output=True)
green = r.returncode == 0
print("  还原后 内容一致=%s exit=%d ⇒ %s" % (restored, r.returncode, "✅ 恢复绿" if green else "❌ 仍红"))
print()
print("  卡点结论: %s" % ("✅ 有效（拦得住、放得过）" if caught and green
                          else "❌ 需继续修"))
